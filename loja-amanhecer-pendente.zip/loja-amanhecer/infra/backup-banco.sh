#!/usr/bin/env bash
# Backup diário do banco. Agendar no cron: 0 3 * * * /opt/loja/infra/backup-banco.sh
set -euo pipefail
DESTINO=/opt/loja/backups
mkdir -p "$DESTINO"
docker compose -f /opt/loja/docker-compose.yml exec -T banco \
  pg_dump -U "${POSTGRES_USER:-loja}" -Fc "${POSTGRES_DB:-loja_amanhecer}" > "$DESTINO/loja-$(date +%F).dump"
find "$DESTINO" -name 'loja-*.dump' -mtime +30 -delete
