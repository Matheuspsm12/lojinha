# Histórico de versões

## 0.9.9 — Correções de uma revisão de segurança (aguardando aprovação)

### Corrigido
- Trocar ou redefinir a senha agora derruba os tokens antigos **também na loja**, não só no painel: o token carrega o carimbo de segurança da conta e ele é conferido a cada requisição autenticada. Antes, um token da loja roubado continuava valendo até expirar sozinho (até 12h) mesmo depois do cliente trocar a senha — a documentação já dizia que isso valia para toda a sessão, mas só estava implementado para o painel.
- A API agora avisa no log, ao subir, quando `Seguranca:ChaveCriptografia` não está configurada — nesse caso a credencial do Mercado Pago é cifrada com uma chave derivada de `Jwt:Chave`, em vez de uma chave própria. O comportamento não mudou (continua funcionando), só ficou visível pra quem administra o servidor perceber e corrigir antes de ir para produção.
- Baixa e devolução de estoque no fechamento do pedido agora são um `UPDATE` direto no banco (antes, liam o estoque em memória e gravavam de volta). Dois pedidos do mesmo produto bem no mesmo instante podiam "atropelar" um ao outro e o estoque ficar errado; pedir mais do que o estoque pronto continua permitido de propósito (vira prazo de produção para a diferença — coberto pelo teste `Pronta_entrega_sem_estoque_suficiente_usa_prazo_producao`), então a correção não bloqueia isso, só deixa a conta atômica.
- Relatório "Mapa de calor dos produtos" (adicionado na versão anterior): a consulta de vendas por produto usava um agrupamento que o Entity Framework pode não traduzir para SQL (`g.First()` depois de `GroupBy` direto no banco). Corrigido para agrupar em memória, como o resto do arquivo já fazia — sem isso, o endpoint provavelmente quebraria na primeira chamada.

### Mantido
- Verificação de assinatura do webhook do Mercado Pago (`MercadoPago:ChaveWebhook`) fica para depois — o risco já é baixo porque o servidor nunca confia no corpo do aviso, sempre confere a situação real na API do Mercado Pago antes de aprovar qualquer coisa.

## 0.9.8 — WhatsApp flutuante e mapa de calor dos produtos (aguardando aprovação)

### Adicionado
- Botão flutuante do WhatsApp, sempre visível no canto inferior direito da loja (em cima da navegação do celular, sem tampar nada). Some se a loja ficar sem WhatsApp cadastrado.
- Contagem de cliques por produto: cada visita à página de um produto soma 1, em `GET /api/produtos/{slug}`. Guardado na mesma tabela de configurações (chave `analytics.cliques_produto.{id}`), com incremento atômico (SQL `ON CONFLICT`) para não perder contagem em acessos simultâneos. Sem tabela nova, sem migração.
- `GET /api/admin/relatorios/desempenho-produtos`: cliques x vendas lado a lado, por produto.
- Painel → Relatórios ganhou a seção "Mapa de calor dos produtos": tabela com cliques e vendidos coloridos por intensidade (quanto mais escuro/vermelho, mais movimento), mais a conversão (vendidos ÷ cliques). Dá pra exportar em CSV/Excel.

### Mantido
- Todo o resto de Relatórios (faturamento, mais vendidos, por categoria, por vendedor) sem alteração.

## 0.9.7 — Nome, WhatsApp, e-mail e Instagram configuráveis pelo painel (aguardando aprovação)

### Adicionado
- Tela "Configurações" no painel (menu ao lado de Aparência): nome da loja, WhatsApp, e-mail de contato e Instagram, tudo num só formulário.
- `GET/PUT /api/admin/loja`: só a conta administradora lê e altera esses quatro campos.
- `GET /api/loja/info`: público, devolve nome, WhatsApp e Instagram para o cabeçalho e o rodapé da loja.
- Instagram em branco esconde o botão no rodapé, tanto no protótipo quanto na API.
- Validação simples: nome e WhatsApp não podem ficar vazios; Instagram, se preenchido, precisa começar com `http://` ou `https://`.

### Mantido
- `loja.nome`, `loja.whatsapp` e `loja.email` continuam na mesma tabela de configurações (chave/valor) que já existia; só ganharam uma tela para editar e uma rota pública para consultar. Nenhuma migração nova.

## 0.9.6 — Botão do Instagram e WhatsApp atualizado (aguardando aprovação)

### Adicionado
- Botão do Instagram no rodapé, ao lado do "Falar no WhatsApp", com o link direto para `instagram.com/lojinha_dovale`.

### Alterado
- Número de WhatsApp da loja atualizado no protótipo e no valor padrão usado quando a loja é instalada do zero (`loja.whatsapp`, no painel).
- Nome padrão da loja nos e-mails (remetente e mensagens de mudança de status do pedido) e na configuração inicial (`loja.nome`) atualizado de "Loja Amanhecer" para "Lojinha Do Vale", para não ficar divergente do resto da loja.

### Mantido
- Loja e painel já instalados não são alterados por essa mudança: o nome e o WhatsApp editados pelo painel continuam como estão; o novo padrão vale só para instalações novas ou para quem redefinir esses campos.

## 0.9.5 — Login com Google (aguardando aprovação)

### Adicionado
- Botão "Continuar com o Google" (OAuth 2.0 / Google Identity Services): `POST /api/auth/google` recebe o token do Google, confere a assinatura com a biblioteca oficial `Google.Apis.Auth` (sem chamada de rede) e devolve o token de acesso da própria loja, igual ao login por e-mail e senha.
- Cadastro automático no primeiro acesso: se o e-mail do Google ainda não tem conta, ela é criada na hora (sem senha — essa conta só entra pelo Google), já como Cliente.
- Nome, e-mail e identificador único do Google (`sub`) são conferidos a partir do token; o identificador fica ligado à conta (login externo do Identity), então os próximos acessos não dependem do e-mail continuar o mesmo.
- Se o e-mail já tinha conta com senha, o próximo login pelo Google liga a conta do Google a essa mesma conta, em vez de duplicar.
- `Autenticacao__Google__ClientId` (não é segredo): sem essa configuração, o endpoint recusa o login e a API avisa no log ao subir.
- Botão "Continuar com o Google" também no protótipo, na tela de Entrar/Criar conta, acima do login por e-mail e senha. Simula o mesmo comportamento da API (cadastro automático no primeiro clique, login direto depois), já que o protótipo não chama o servidor de verdade.

### Mantido
- Login e cadastro por e-mail e senha sem alteração; o token de acesso devolvido é o mesmo dos dois formatos de login, então o resto da loja não precisa saber qual foi usado.

## 0.9.4 — Nova marca: Lojinha Do Vale (aguardando aprovação)

### Alterado
- Selo "Vale do Amanhecer" trocado pelo novo selo enviado pelo cliente, "Lojinha Do Vale": cabeçalho da loja, ícone do navegador (favicon), ícone de instalação no celular (apple-touch-icon) e protótipo.
- Arte recortada no círculo, com o fundo removido e bordas transparentes, gerada em 32, 48, 64, 96, 192 e 512 px, em WebP e PNG, mais o `favicon.ico`.
- No cabeçalho, passar o mouse na marca mostra uma versão ampliada flutuando logo abaixo; some ao tirar o mouse. Só em telas com mouse de verdade — no celular fica desativado, para não "grudar" depois de um toque.
- Nome da loja no cabeçalho e nas mensagens trocado de "Loja Amanhecer" para "Lojinha Do Vale".

### Mantido
- Banner da página inicial (arte "Lojinha do Vale — Artigos Doutrinários O.S.O.E.C.") sem alteração — já estava correto.
- Tamanho e alinhamento do cabeçalho, cores, menu e demais funcionalidades sem alteração.

## 0.9.3 — Giro da foto da categoria (aguardando aprovação)

### Adicionado
- Na página inicial, passar o mouse sobre uma categoria gira a foto uma volta completa, em movimento suave; ao tirar o mouse, ela desfaz o giro e volta à posição inicial.
- Gira apenas a imagem dentro do círculo: a borda dourada, o nome e o restante do card não giram.
- O giro também acontece ao chegar na categoria pelo teclado.
- No celular não há giro, para não atrapalhar o toque, e quem usa "reduzir movimento" no sistema não vê animação nenhuma.
- Feito só com CSS, sem script: o clique continua abrindo a página da categoria normalmente.

### Mantido
- Medalhões da página de categorias, layout, imagens, categorias e integrações sem alteração.

## 0.9.2 — Categorias ligadas ao cadastro de produtos (aguardando aprovação)

### Adicionado
- `GET /api/admin/categorias/opcoes`: lista pronta para o campo de categoria do produto, com categorias e subcategorias ativas, na ordem, com o caminho montado e a contagem de produtos.
- O campo de categoria do formulário passou a ser montado dessa lista: categoria ou subcategoria criada ou renomeada aparece na hora, sem fechar o painel, agrupada por categoria principal.
- Ativar e desativar categorias e subcategorias pelo painel, com aviso de quantos produtos ficam fora da loja.
- Excluir categoria pelo painel, com a mesma regra da API: recusa quando há produtos ou subcategorias.
- Menu, medalhões, filtros, busca e páginas da loja passaram a respeitar as categorias ativas.

### Corrigido
- Produto criado pelo formulário do protótipo ficava sem identificador, o que impedia abrir a edição dele em seguida.

### Regras
- Categoria desativada não pode ser escolhida em produto novo nem em troca de categoria, mas continua vinculada ao produto que já estava nela — ao editar, aparece marcada como desativada.

### Mantido
- Visual, produtos, categorias existentes, pedidos, pagamentos, fotos, frete, integrações e banco de dados sem alteração. Nenhuma migração foi necessária.

## 0.9.1 — Gestão das fotos do produto (aguardando aprovação)

### Adicionado
- Galeria no formulário do produto mostrando todas as fotos cadastradas, com a capa destacada.
- Botão de excluir em cada foto, com confirmação antes de apagar; a confirmação avisa quando a foto é a capa.
- Substituição de uma foto por outra, mantendo a posição dela na galeria.
- Escolha manual da capa; excluindo a capa, a próxima foto assume automaticamente.
- Produto sem nenhuma foto passa a mostrar a imagem padrão da loja na vitrine, no card e na página do produto.
- Exclusão e substituição apagam do armazenamento todas as versões geradas e o arquivo original, sem deixar arquivo abandonado.
- Armazenamento compatível com **S3** (Cloudflare R2, Amazon S3, MinIO, Backblaze), ligado por `Armazenamento:Provedor = s3`, com as mesmas operações do disco local, inclusive a exclusão.
- Registro de quem excluiu ou substituiu cada foto, com e-mail, data e IP, em `registros_acesso` e no log.
- Excluir, substituir, reordenar e escolher a capa passaram a exigir a conta administradora.
- 9 testes novos (91 no total): exclusão que não afeta produto nem outras fotos, capa promovida, substituição mantendo a posição, arquivos apagados do armazenamento, permissões e registro da auditoria.

### Mantido
- Visual, produtos, categorias, pedidos, pagamentos, frete, integrações e banco de dados sem alteração. Nenhuma migração foi necessária.

## 0.9.0 — Nova vitrine da página inicial (aguardando aprovação)

### Alterado
- A faixa de abertura da loja passou a trazer a arte da **Lojinha do Vale — Artigos Doutrinários O.S.O.E.C.**, no lugar do amanhecer desenhado.
- A arte entra inteira, na proporção original (8,19 : 1), sem corte e sem distorção, sobre um fundo escuro que combina com o preto e o dourado do material.
- Título, texto e botão continuam com as mesmas palavras, agora centralizados abaixo da arte, em branco sobre o fundo escuro, com o botão em dourado para manter o contraste.

### Adicionado
- Arte otimizada em 640, 960, 1280, 1440 e 1920 px, em WebP e JPG, mais o arquivo original.
- Tela **Aparência** no painel, onde o administrador troca o banner ou volta ao que veio na instalação.
- `GET /api/loja/aparencia`, `GET/POST/DELETE /api/admin/aparencia/banner` — o envio aceita os mesmos formatos das fotos, corrige a orientação e gera as versões otimizadas mantendo a proporção. Só a conta administradora pode trocar.

### Mantido
- Produtos, categorias, fotos, carrinho, checkout, cadastro, área do cliente, pedidos, pagamentos, painel, segurança, frete, integrações e banco de dados sem nenhuma alteração. Nenhuma migração foi necessária: o banner usa a tabela `configuracoes` que já existia.

## 0.8.1 — Marca da Lojinha do Amanhecer

### Alterado
- O ícone antigo (sol desenhado) saiu de todos os lugares e foi substituído pela arte da Lojinha do Amanhecer: cabeçalho da loja, painel, tela de entrada do painel e confirmação do pedido.
- Ícone do navegador (favicon) e ícone de instalação no celular passaram a usar a mesma imagem.
- Arte recortada no círculo, com o fundo cinza removido e bordas transparentes, gerada em 32, 48, 64, 96, 192 e 512 px, em WebP e PNG, mais o `favicon.ico`. Todos os arquivos são quadrados, então a imagem nunca estica.

### Mantido
- Tamanho e alinhamento do cabeçalho iguais aos de antes (38 px, altura de 66 px). Nenhum texto, cor, menu ou funcionalidade foi alterado.

## 0.8.0 — Pagamentos e recebimentos

### Adicionado
- Área "Pagamentos e recebimentos" no painel, exclusiva da conta administradora.
- Conexão da conta do Mercado Pago pelo painel, com teste antes de aceitar a credencial, ou pela variável de ambiente do servidor, que tem prioridade.
- Access Token guardado cifrado (AES-GCM) e exibido apenas mascarado; nunca é enviado ao navegador nem gravado no Git.
- Ativar e desativar Pix, cartão e boleto, com a loja mostrando só as formas ativas no checkout.
- Máximo de parcelas, juros do parcelamento e valor mínimo por parcela.
- Alternância entre ambiente de teste e produção.
- Situação da conexão, conta ligada e resultado do último teste.
- Lista de recebimentos com número do pedido, cliente, forma, valor, taxa do provedor, líquido previsto, estornos e ambiente; filtro por situação e busca por pedido ou cliente.
- Resumo com aprovados, pendentes, recusados, estornados e cancelados, mais bruto, taxas e líquido previsto.
- Estorno total ou parcial, com registro no histórico interno do pedido.
- Taxa e líquido gravados a partir do que o Mercado Pago informa; sem integração, usa as taxas de referência configuradas.
- `GET /api/pagamentos/opcoes` para o checkout da loja.
- 18 testes novos (82 no total), incluindo a prova de que o token não aparece na resposta nem em texto puro no banco.

### Mantido
- Modo simulado enquanto não houver credencial, e troca para produção sem alterar código.
- Pedidos, produtos, categorias, clientes, relatórios, fotos, integrações e telas existentes sem alteração. A migração é só de acréscimo.

## 0.7.0 — Isolamento entre clientes, conferido por testes

### Adicionado
- 22 testes de integração que sobem a API contra um banco temporário e provam, com duas contas de cliente e a conta administradora, que cada cliente só alcança os próprios dados, endereços, pedidos, pagamentos, prazos, rastreio e histórico.
- Tentativa de abrir um pedido de outra conta passa a ficar registrada como `PedidoDeOutroCliente` em `registros_acesso`.
- Resposta `404` com "Pedido não encontrado na sua conta", para não confirmar a existência do número de outra pessoa.
- Seção de isolamento entre clientes na documentação de segurança.

### Alterado
- Magick.NET atualizado de 13.10.0 para 14.17.1, saindo de uma versão com alertas de segurança conhecidos. Módulo de fotos reconferido depois da atualização: HEIC, orientação, versões otimizadas e medalhões de categoria seguem iguais.

### Mantido
- Nenhuma mudança de banco, tela, fluxo ou regra. A conferência confirmou que a API já identificava o cliente pelo token; o que entrou foi registro, mensagem e prova automatizada.

## 0.6.0 — Acesso ao painel restrito ao administrador

### Adicionado
- Painel em `/painel`, com tela de entrada própria; a loja pública não tem mais link nem botão para ele.
- Acesso limitado ao perfil Administrador, pela configuração `Painel:PerfisPermitidos`.
- Recusa padronizada com "Acesso não autorizado" para clientes, vendedores, contas inativas e sessões encerradas.
- Proteção no servidor de todas as rotas `/api/admin/...` e `/api/painel/...`, conferindo perfil, conta ativa e carimbo de sessão a cada requisição.
- Primeira conta administradora criada com token de instalação de uso único, gravado no log e em `primeiro-acesso.txt`.
- Troca de senha, recuperação por e-mail com link de uso único e redefinição que desbloqueia a conta.
- Bloqueio temporário de 15 minutos após 5 senhas incorretas.
- Registro de todas as tentativas de acesso, com tela própria no painel e `GET /api/admin/acessos`.
- Sessão do painel de 8 horas e opção de sair da conta, que invalida os tokens emitidos.
- Mensagens do ASP.NET Identity traduzidas para português.

### Mantido
- Vendedores continuam cadastrados no banco e na API, com a tela de gestão, o "assumir pedido" e o histórico de atendimento intactos. Só a entrada no painel está restrita, e um item de configuração libera os vendedores quando você quiser.
- Pedidos, produtos, categorias, clientes, relatórios, configurações, fotos e integrações sem alteração. A migração é só de acréscimo.

## 0.5.0 — Fotos no card do produto

### Adicionado
- Card de produto da loja com navegação entre as fotos: setas contextuais (a "anterior" some na primeira foto e a "próxima" na última) e pontos indicando a foto atual.
- No computador as setas aparecem ao passar o mouse ou ao chegar pelo teclado; no celular ficam sempre visíveis e também dá para deslizar o dedo.
- Clicar na foto ou no nome continua abrindo o produto; a seta e o deslize só trocam a foto, sem redesenhar a página nem perder a rolagem.
- `GET /api/produtos` passou a devolver `fotos`, com todas as fotos do produto na ordem do cadastro.

### Mantido
- Cards com uma única foto seguem iguais. Tamanho, selos, textos, a página do produto e o painel não mudaram; `imagemUrl` continua no mesmo formato.

## 0.4.0 — Foto das categorias

### Adicionado
- Foto própria para cada categoria e subcategoria, enviada pelo painel.
- Enquadramento antes de salvar: arrastar a foto e aproximar dentro do círculo, com prévia igual ao que a loja vai mostrar.
- Trocar e excluir a foto; ao trocar, os arquivos anteriores são apagados.
- Aceita as mesmas fotos do produto, inclusive HEIC de alta resolução do celular, com orientação corrigida.
- Geração automática do medalhão quadrado de 600 × 600 e da miniatura de 200 × 200 em WebP, com o original preservado.
- Loja passa a exibir a foto dentro do medalhão, mantendo formato, tamanho, borda dourada e organização; sem foto, continua a ilustração padrão.
- Subcategorias com foto aparecem com a imagem nos atalhos da loja.
- 7 testes novos (42 no total).

### Mantido
- Categorias, produtos, fluxos e telas existentes sem alteração. As duas colunas novas em `categorias` são opcionais e a `imagem_url`, que já existia, continua igual.

## 0.3.0 — Módulo de fotos

### Adicionado
- Envio de fotos em JPG, JPEG, PNG, WEBP, AVIF e HEIC/HEIF, até 60 MB cada.
- Correção automática da orientação pelo EXIF.
- Original preservado byte a byte, sem nenhuma alteração.
- Geração automática de miniatura (400 px), versão de catálogo (900 px) e versão da página do produto (1600 px) em WebP, com opção de AVIF.
- Remoção de metadados das cópias (inclusive localização da foto) e compressão sem perda visível.
- Cache de um ano nas fotos servidas em `/uploads`.
- No painel: área de envio com arrastar e soltar, botão "Tirar foto agora" para o celular, barra de progresso por foto e aviso claro quando o arquivo é recusado.
- Exclusão de uma foto agora apaga também as versões geradas e o original.
- 14 testes novos do módulo de fotos (35 no total).

### Mantido
- Nenhuma tela, fluxo, regra ou coluna existente foi alterada. As colunas novas em `produto_imagens` são opcionais e as fotos antigas continuam sendo exibidas normalmente.

## 0.2.0 — Etapas 2 e 3 (API)

### Adicionado
- Cotação de frete (`/api/frete/cotar`) já com o prazo total: produção + transporte.
- Fechamento de pedido com recálculo de preços, prazos e frete no servidor, número sequencial e cobrança gerada no ato.
- Baixa de estoque na compra e devolução automática no cancelamento.
- Área do cliente: dados, endereços e acompanhamento dos pedidos.
- Painel de pedidos: filtros, detalhe, assumir, mudança de status, rastreio, etiqueta, confirmação manual de pagamento e observação interna.
- Relatórios de vendas (por dia, categoria, produto e vendedor) e exportações em Excel de pedidos e vendas.
- Integrações: ViaCEP, Melhor Envio, Mercado Pago (Pix, boleto e cartão pelo Checkout Pro) com webhook, e e-mail SMTP com modelos em HTML.
- Modo simulado de frete, pagamento e e-mail para testar sem as contas configuradas, com aviso no log.
- 21 testes automatizados (8 novos).

### Corrigido
- Entidades novas dentro de um pedido já gravado passaram a ser marcadas corretamente como inclusão (evitava gravar pagamento e histórico).

## 0.1.0 — Etapa 1 (aguardando aprovação)

### Adicionado
- Estrutura do repositório e solução .NET 8 em camadas.
- Modelo de dados completo: catálogo, variações, clientes, endereços, pedidos, pagamentos, histórico e configurações.
- Migração inicial e script SQL (`database/schema.sql`).
- Dados iniciais: perfis, administrador, categorias aprovadas e configurações da loja.
- Autenticação JWT com perfis Administrador, Vendedor e Cliente.
- API do catálogo com busca sem acento e filtro por categoria/subcategoria.
- API do painel: produtos (fotos, variações, ativo/inativo, exportação Excel), categorias, clientes, vendedores e resumo.
- Regras de prazo (produção + transporte) e fluxo de status com testes automatizados (13 testes).
- Protótipo visual navegável da loja e do painel para aprovação.
- Documentação de instalação, configuração, publicação, banco e API.
- Docker Compose, Caddy (HTTPS) e script de backup.
