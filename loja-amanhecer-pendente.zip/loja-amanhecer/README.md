# Loja Amanhecer

Plataforma de vendas on-line de artigos para integrantes do Vale do Amanhecer: loja responsiva, área do cliente e painel administrativo para vendedores.

> **Situação atual: Etapas 1, 2 e 3 concluídas na API.** Falta ligar as contas reais do Melhor Envio, do Mercado Pago e do e-mail, e construir o frontend definitivo (Etapa 4).
> Sem as chaves, a API roda com frete, cobrança e e-mail simulados e avisa no log — dá para testar o fluxo inteiro.

## O que tem neste repositório

```
loja-amanhecer/
├── prototipo/index.html        Protótipo navegável da loja e do painel (abrir no navegador)
├── backend/                    API ASP.NET Core 8 + PostgreSQL
│   ├── src/LojaAmanhecer.Domain          Entidades e regras de negócio
│   ├── src/LojaAmanhecer.Application     DTOs e contratos das integrações
│   ├── src/LojaAmanhecer.Infrastructure  Banco (EF Core), migrações, dados iniciais, arquivos
│   ├── src/LojaAmanhecer.Api             Endpoints REST, autenticação JWT, Swagger
│   └── tests/LojaAmanhecer.Tests         Testes das regras de negócio
├── database/schema.sql         Script SQL completo do banco (gerado das migrações)
├── frontend/                   Loja e painel em Next.js (Etapa 4)
├── infra/                      Proxy HTTPS e backup
├── docs/                       Documentação
├── docker-compose.yml
└── .env.example
```

## Tecnologias

| Camada | Tecnologia |
|---|---|
| API | ASP.NET Core 8, EF Core 8, ASP.NET Identity + JWT |
| Banco | PostgreSQL 16 |
| Fotos | Magick.NET (HEIC do iPhone, correção de orientação, WebP/AVIF) |
| Loja e painel | Next.js 14 + Tailwind (Etapa 4) |
| Frete | Melhor Envio + ViaCEP |
| Pagamento | Mercado Pago — Pix, cartão e boleto |
| Publicação | VPS Linux + Docker + Caddy (HTTPS automático) |

## Começo rápido (desenvolvimento no Windows)

Veja o passo a passo completo em [docs/INSTALACAO.md](docs/INSTALACAO.md). Resumo, com o PostgreSQL já instalado:

```powershell
cd backend\src\LojaAmanhecer.Api
```
```powershell
dotnet run --urls http://localhost:5080
```

Abra `http://localhost:5080/swagger`. Na primeira execução o banco é criado com as categorias iniciais e o administrador `admin@loja.local` / `Admin@12345` (troque em produção).

## Documentação

| Documento | Conteúdo |
|---|---|
| [docs/ETAPAS.md](docs/ETAPAS.md) | Planejamento por etapas e situação de cada uma |
| [docs/SEGURANCA.md](docs/SEGURANCA.md) | Acesso ao painel, primeira conta, senhas, bloqueio e registro de acessos |
| [docs/APROVACOES.md](docs/APROVACOES.md) | Registro do que foi aprovado e do que aguarda aprovação |
| [docs/INSTALACAO.md](docs/INSTALACAO.md) | Instalação do ambiente de desenvolvimento |
| [docs/CONFIGURACAO.md](docs/CONFIGURACAO.md) | Todas as configurações e chaves das integrações |
| [docs/PUBLICACAO.md](docs/PUBLICACAO.md) | Publicação em servidor com domínio e HTTPS |
| [docs/BANCO-DE-DADOS.md](docs/BANCO-DE-DADOS.md) | Tabelas, relacionamentos e regras gravadas no banco |
| [docs/API.md](docs/API.md) | Endpoints disponíveis |
| [CHANGELOG.md](CHANGELOG.md) | Histórico de versões |
