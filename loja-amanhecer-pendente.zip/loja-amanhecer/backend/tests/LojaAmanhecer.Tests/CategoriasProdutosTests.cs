using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace LojaAmanhecer.Tests;

/// <summary>
/// Integração entre categorias e cadastro de produtos: o que é criado no painel aparece
/// na hora no formulário do produto, nos filtros e nas páginas da loja.
/// </summary>
public class CategoriasProdutosTests(ApiDeTeste api) : IClassFixture<ApiDeTeste>, IAsyncLifetime
{
    private HttpClient _admin = null!;
    private HttpClient _loja = null!;

    public async Task InitializeAsync()
    {
        _admin = api.CreateClient();
        var login = await _admin.PostAsJsonAsync("/api/painel/auth/login", new { email = ApiDeTeste.AdminEmail, senha = ApiDeTeste.AdminSenha });
        login.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await login.Content.ReadAsStringAsync());
        _admin.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", doc.RootElement.GetProperty("token").GetString());
        _loja = api.CreateClient();
    }

    public Task DisposeAsync() => Task.CompletedTask;

    [Fact]
    public async Task Categoria_e_subcategoria_novas_aparecem_na_hora_no_formulario_e_na_loja()
    {
        var nome = $"Velas e incensos {Sufixo()}";
        var pai = await CriarCategoriaAsync(nome, null);
        var sub = await CriarCategoriaAsync("Incensos naturais", pai);

        // 1. o formulário de produto já enxerga as duas, com o caminho montado
        var opcoes = await OpcoesAsync();
        var opcaoPai = opcoes.First(o => o.GetProperty("id").GetGuid() == pai);
        var opcaoSub = opcoes.First(o => o.GetProperty("id").GetGuid() == sub);
        Assert.Equal(nome, opcaoPai.GetProperty("caminho").GetString());
        Assert.Equal($"{nome} › Incensos naturais", opcaoSub.GetProperty("caminho").GetString());
        Assert.True(opcaoSub.GetProperty("ehSubcategoria").GetBoolean());
        // a subcategoria vem logo depois da categoria pai
        var posicaoPai = opcoes.FindIndex(o => o.GetProperty("id").GetGuid() == pai);
        Assert.Equal(pai, opcoes[posicaoPai].GetProperty("id").GetGuid());
        Assert.Equal(sub, opcoes[posicaoPai + 1].GetProperty("id").GetGuid());

        // 2. um produto cadastrado na subcategoria nova
        var produtoId = await CriarProdutoAsync("Incenso de alecrim", sub);

        // 3. a loja mostra a categoria nova no menu e o produto dentro dela
        var arvore = await _loja.GetFromJsonAsync<JsonElement>("/api/categorias");
        var naLoja = arvore.EnumerateArray().First(c => c.GetProperty("id").GetGuid() == pai);
        Assert.Equal("Incensos naturais", naLoja.GetProperty("subcategorias")[0].GetProperty("nome").GetString());

        var slugPai = naLoja.GetProperty("slug").GetString();
        var slugSub = naLoja.GetProperty("subcategorias")[0].GetProperty("slug").GetString();

        var porSub = await _loja.GetFromJsonAsync<JsonElement>($"/api/produtos?categoria={slugSub}");
        Assert.Contains(produtoId, Ids(porSub));

        // filtrar pela categoria principal também traz o produto da subcategoria
        var porPai = await _loja.GetFromJsonAsync<JsonElement>($"/api/produtos?categoria={slugPai}");
        Assert.Contains(produtoId, Ids(porPai));

        // e a página do produto mostra a categoria certa
        var detalhe = await _loja.GetFromJsonAsync<JsonElement>("/api/produtos/incenso-de-alecrim");
        Assert.Equal("Incensos naturais", detalhe.GetProperty("categoria").GetString());
        Assert.Equal(nome, detalhe.GetProperty("categoriaPai").GetString());
    }

    [Fact]
    public async Task Renomear_aparece_na_hora_nas_opcoes_e_na_loja()
    {
        var pai = await CriarCategoriaAsync($"Artigos de mesa {Sufixo()}", null);
        var sub = await CriarCategoriaAsync("Toalhas", pai);

        var r = await _admin.PutAsJsonAsync($"/api/admin/categorias/{sub}",
            new { nome = "Toalhas bordadas", descricao = (string?)null, imagemUrl = (string?)null, ordem = 1, ativa = true, categoriaPaiId = pai });
        r.EnsureSuccessStatusCode();

        var opcao = (await OpcoesAsync()).First(o => o.GetProperty("id").GetGuid() == sub);
        Assert.EndsWith("› Toalhas bordadas", opcao.GetProperty("caminho").GetString());

        var arvore = await _loja.GetFromJsonAsync<JsonElement>("/api/categorias");
        var naLoja = arvore.EnumerateArray().First(c => c.GetProperty("id").GetGuid() == pai);
        Assert.Equal("Toalhas bordadas", naLoja.GetProperty("subcategorias")[0].GetProperty("nome").GetString());
    }

    [Fact]
    public async Task Categoria_desativada_some_das_opcoes_mas_o_produto_antigo_mantem_o_vinculo()
    {
        var pai = await CriarCategoriaAsync($"Temporada {Sufixo()}", null);
        var produtoId = await CriarProdutoAsync("Item de temporada", pai);

        await DesativarAsync(pai, "Temporada desativada");

        // 1. sai da lista do formulário para novos cadastros
        var opcoes = await OpcoesAsync();
        Assert.DoesNotContain(pai, opcoes.Select(o => o.GetProperty("id").GetGuid()));

        // 2. mas aparece ao editar o produto que já estava nela, marcada como desativada
        var comProduto = await OpcoesAsync(pai);
        var opcao = comProduto.First(o => o.GetProperty("id").GetGuid() == pai);
        Assert.False(opcao.GetProperty("ativa").GetBoolean());
        Assert.Equal(1, opcao.GetProperty("produtos").GetInt32());

        // 3. o produto continua vinculado e pode ser salvo sem trocar de categoria
        var produto = await _admin.GetFromJsonAsync<JsonElement>($"/api/admin/produtos/{produtoId}");
        Assert.Equal(pai, produto.GetProperty("categoriaId").GetGuid());
        var salvar = await _admin.PutAsJsonAsync($"/api/admin/produtos/{produtoId}", CorpoProduto("Item de temporada", pai));
        salvar.EnsureSuccessStatusCode();

        // 4. a loja não mostra mais a categoria desativada
        var arvore = await _loja.GetFromJsonAsync<JsonElement>("/api/categorias");
        Assert.DoesNotContain(pai, arvore.EnumerateArray().Select(c => c.GetProperty("id").GetGuid()));
    }

    [Fact]
    public async Task Produto_novo_nao_pode_ser_cadastrado_em_categoria_desativada()
    {
        var pai = await CriarCategoriaAsync($"Fora de linha {Sufixo()}", null);
        await DesativarAsync(pai, "Fora de linha");

        var r = await _admin.PostAsJsonAsync("/api/admin/produtos", CorpoProduto("Produto recusado", pai));
        Assert.Equal(HttpStatusCode.UnprocessableEntity, r.StatusCode);
        Assert.Contains("desativada", await r.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task Categoria_com_produtos_nao_pode_ser_excluida()
    {
        var pai = await CriarCategoriaAsync($"Com produtos {Sufixo()}", null);
        await CriarProdutoAsync("Produto vinculado", pai);

        var r = await _admin.DeleteAsync($"/api/admin/categorias/{pai}");
        Assert.Equal(HttpStatusCode.UnprocessableEntity, r.StatusCode);
        Assert.Contains("produtos nesta categoria", await r.Content.ReadAsStringAsync());

        // e continua na lista do painel
        var todas = await _admin.GetFromJsonAsync<JsonElement>("/api/admin/categorias");
        Assert.Contains(pai, todas.EnumerateArray().Select(c => c.GetProperty("id").GetGuid()));
    }

    [Fact]
    public async Task Categoria_com_subcategorias_nao_pode_ser_excluida()
    {
        var pai = await CriarCategoriaAsync($"Com filhas {Sufixo()}", null);
        await CriarCategoriaAsync("Uma sub", pai);

        var r = await _admin.DeleteAsync($"/api/admin/categorias/{pai}");
        Assert.Equal(HttpStatusCode.UnprocessableEntity, r.StatusCode);
        Assert.Contains("subcategorias", await r.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task Categoria_vazia_pode_ser_excluida()
    {
        var id = await CriarCategoriaAsync($"Criada sem uso {Sufixo()}", null);
        Assert.Equal(HttpStatusCode.NoContent, (await _admin.DeleteAsync($"/api/admin/categorias/{id}")).StatusCode);
        Assert.DoesNotContain(id, (await OpcoesAsync()).Select(o => o.GetProperty("id").GetGuid()));
    }

    [Fact]
    public async Task Subcategoria_de_subcategoria_nao_e_aceita()
    {
        var pai = await CriarCategoriaAsync($"Dois níveis {Sufixo()}", null);
        var sub = await CriarCategoriaAsync("Nível dois", pai);

        var r = await _admin.PostAsJsonAsync("/api/admin/categorias",
            new { nome = "Nível três", descricao = (string?)null, imagemUrl = (string?)null, ordem = 1, ativa = true, categoriaPaiId = sub });
        Assert.Equal(HttpStatusCode.UnprocessableEntity, r.StatusCode);
    }

    // ---------------- apoio ----------------

    private static string Sufixo() => Guid.NewGuid().ToString("N")[..6];

    private static List<Guid> Ids(JsonElement pagina) =>
        pagina.GetProperty("itens").EnumerateArray().Select(p => p.GetProperty("id").GetGuid()).ToList();

    private async Task<List<JsonElement>> OpcoesAsync(Guid? incluirId = null)
    {
        var rota = incluirId is null ? "/api/admin/categorias/opcoes" : $"/api/admin/categorias/opcoes?incluirId={incluirId}";
        var opcoes = await _admin.GetFromJsonAsync<JsonElement>(rota);
        return opcoes.EnumerateArray().ToList();
    }

    private async Task<Guid> CriarCategoriaAsync(string nome, Guid? pai)
    {
        var r = await _admin.PostAsJsonAsync("/api/admin/categorias",
            new { nome, descricao = (string?)null, imagemUrl = (string?)null, ordem = 99, ativa = true, categoriaPaiId = pai });
        r.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await r.Content.ReadAsStringAsync());
        return doc.RootElement.GetProperty("id").GetGuid();
    }

    private async Task DesativarAsync(Guid id, string nome)
    {
        var r = await _admin.PutAsJsonAsync($"/api/admin/categorias/{id}",
            new { nome, descricao = (string?)null, imagemUrl = (string?)null, ordem = 99, ativa = false, categoriaPaiId = (Guid?)null });
        r.EnsureSuccessStatusCode();
    }

    private static object CorpoProduto(string nome, Guid categoriaId) => new
    {
        nome, descricao = "teste de categoria", categoriaId, preco = 39.9m, estoque = 5,
        pesoGramas = 120, alturaCm = 3m, larguraCm = 8m, comprimentoCm = 10m, disponibilidade = "ProntaEntrega",
        prazoProducaoDias = 5, permitePersonalizacao = false, rotuloPersonalizacao = (string?)null,
        limiteCaracteresPersonalizacao = (int?)null, valorPersonalizacao = 0m, ativo = true, destaque = false,
        opcoes = Array.Empty<object>(), variacoes = Array.Empty<object>()
    };

    private async Task<Guid> CriarProdutoAsync(string nome, Guid categoriaId)
    {
        var r = await _admin.PostAsJsonAsync("/api/admin/produtos", CorpoProduto(nome, categoriaId));
        r.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await r.Content.ReadAsStringAsync());
        return doc.RootElement.GetProperty("id").GetGuid();
    }
}
