using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using ImageMagick;

namespace LojaAmanhecer.Tests;

/// <summary>
/// Gestão das fotos do produto no painel: excluir, substituir, escolher a capa.
/// Confere também que os arquivos somem do armazenamento e que nada mais é afetado.
/// </summary>
public class GestaoFotosTests(ApiDeTeste api) : IClassFixture<ApiDeTeste>, IAsyncLifetime
{
    private HttpClient _admin = null!, _cliente = null!;
    private Guid _produtoId;
    private string _slug = "";

    public async Task InitializeAsync()
    {
        _admin = api.CreateClient();
        var login = await _admin.PostAsJsonAsync("/api/painel/auth/login", new { email = ApiDeTeste.AdminEmail, senha = ApiDeTeste.AdminSenha });
        login.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await login.Content.ReadAsStringAsync());
        _admin.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", doc.RootElement.GetProperty("token").GetString());

        _cliente = api.CreateClient();
        var conta = await _cliente.PostAsJsonAsync("/api/auth/registrar",
            new { nomeCompleto = "Cliente Fotos", email = $"fot{Guid.NewGuid():N}"[..14] + "@teste.com", senha = "senha1234", telefone = (string?)null, cpf = (string?)null });
        using var doc2 = JsonDocument.Parse(await conta.Content.ReadAsStringAsync());
        _cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", doc2.RootElement.GetProperty("token").GetString());

        var categorias = await _admin.GetFromJsonAsync<JsonElement>("/api/categorias");
        var categoriaId = categorias[0].GetProperty("subcategorias")[0].GetProperty("id").GetGuid();
        var produto = await _admin.PostAsJsonAsync("/api/admin/produtos", new
        {
            nome = $"Broche com fotos {Guid.NewGuid():N}"[..24], descricao = "teste de fotos", categoriaId,
            preco = 59.9m, estoque = 10, pesoGramas = 150, alturaCm = 3m, larguraCm = 10m, comprimentoCm = 12m,
            disponibilidade = "ProntaEntrega", prazoProducaoDias = 5, permitePersonalizacao = false,
            rotuloPersonalizacao = (string?)null, limiteCaracteresPersonalizacao = (int?)null, valorPersonalizacao = 0m,
            ativo = true, destaque = false, opcoes = Array.Empty<object>(), variacoes = Array.Empty<object>()
        });
        produto.EnsureSuccessStatusCode();
        using var doc3 = JsonDocument.Parse(await produto.Content.ReadAsStringAsync());
        _produtoId = doc3.RootElement.GetProperty("id").GetGuid();
        _slug = doc3.RootElement.GetProperty("slug").GetString()!;
    }

    public Task DisposeAsync() => Task.CompletedTask;

    // ---------------- exclusão ----------------

    [Fact]
    public async Task Excluir_uma_foto_nao_mexe_nas_outras_nem_no_produto()
    {
        var fotos = await EnviarFotosAsync(3);
        var doMeio = fotos[1];
        var arquivosDoMeio = ArquivosDe(doMeio);
        var arquivosDaPrimeira = ArquivosDe(fotos[0]);

        var resposta = await _admin.DeleteAsync($"/api/admin/produtos/{_produtoId}/imagens/{Id(doMeio)}");
        resposta.EnsureSuccessStatusCode();

        var restantes = await GaleriaAsync();
        Assert.Equal(2, restantes.Count);
        Assert.DoesNotContain(Id(doMeio), restantes.Select(Id));
        Assert.Equal([0, 1], restantes.Select(f => f.GetProperty("ordem").GetInt32()).ToList());

        // o produto continua lá, com nome, preço e estoque intactos
        var produto = await _admin.GetFromJsonAsync<JsonElement>($"/api/admin/produtos/{_produtoId}");
        Assert.Equal(59.9m, produto.GetProperty("preco").GetDecimal());
        Assert.True(produto.GetProperty("ativo").GetBoolean());

        // os arquivos da foto excluída saíram do armazenamento; os das outras ficaram
        foreach (var arquivo in arquivosDoMeio) Assert.False(Existe(arquivo), $"{arquivo} deveria ter sido apagado");
        foreach (var arquivo in arquivosDaPrimeira) Assert.True(Existe(arquivo), $"{arquivo} não podia ter sido apagado");
    }

    [Fact]
    public async Task Excluir_a_capa_promove_a_proxima_foto()
    {
        var fotos = await EnviarFotosAsync(3);
        var segunda = Id(fotos[1]);

        (await _admin.DeleteAsync($"/api/admin/produtos/{_produtoId}/imagens/{Id(fotos[0])}")).EnsureSuccessStatusCode();

        var galeria = await GaleriaAsync();
        Assert.Equal(segunda, Id(galeria[0]));
        Assert.Equal(0, galeria[0].GetProperty("ordem").GetInt32());

        // a vitrine da loja passa a mostrar a nova capa
        var naLoja = await api.CreateClient().GetFromJsonAsync<JsonElement>($"/api/produtos?busca={Guid.Empty}");
        var detalhe = await api.CreateClient().GetFromJsonAsync<JsonElement>($"/api/produtos/{_slug}");
        Assert.Equal(galeria[0].GetProperty("url").GetString(), detalhe.GetProperty("imagens")[0].GetProperty("url").GetString());
    }

    [Fact]
    public async Task Excluir_todas_deixa_o_produto_sem_foto_e_ativo()
    {
        var fotos = await EnviarFotosAsync(2);
        foreach (var f in fotos)
            (await _admin.DeleteAsync($"/api/admin/produtos/{_produtoId}/imagens/{Id(f)}")).EnsureSuccessStatusCode();

        Assert.Empty(await GaleriaAsync());

        // na listagem da loja o produto aparece sem imagem: o frontend usa a imagem padrão
        var vitrine = await api.CreateClient().GetFromJsonAsync<JsonElement>($"/api/produtos?busca={Uri.EscapeDataString(await NomeAsync())}");
        var item = vitrine.GetProperty("itens").EnumerateArray().First(p => p.GetProperty("id").GetGuid() == _produtoId);
        Assert.True(item.GetProperty("imagemUrl").ValueKind is JsonValueKind.Null);
        Assert.Empty(item.GetProperty("fotos").EnumerateArray());
    }

    [Fact]
    public async Task Excluir_foto_que_nao_existe_devolve_404()
    {
        await EnviarFotosAsync(1);
        var r = await _admin.DeleteAsync($"/api/admin/produtos/{_produtoId}/imagens/{Guid.NewGuid()}");
        Assert.Equal(HttpStatusCode.NotFound, r.StatusCode);
        Assert.Single(await GaleriaAsync());
    }

    // ---------------- substituição ----------------

    [Fact]
    public async Task Substituir_troca_o_arquivo_e_mantem_a_posicao()
    {
        var fotos = await EnviarFotosAsync(3);
        var alvo = fotos[1];
        var urlAntiga = alvo.GetProperty("url").GetString()!;
        var arquivosAntigos = ArquivosDe(alvo);

        var conteudo = new MultipartFormDataContent();
        var arquivo = new ByteArrayContent(FotoFalsa(900, 700, MagickColors.Crimson));
        arquivo.Headers.ContentType = new MediaTypeHeaderValue("image/jpeg");
        conteudo.Add(arquivo, "foto", "nova.jpg");
        var r = await _admin.PostAsync($"/api/admin/produtos/{_produtoId}/imagens/{Id(alvo)}/substituir", conteudo);
        r.EnsureSuccessStatusCode();

        var galeria = await GaleriaAsync();
        Assert.Equal(3, galeria.Count);
        var atual = galeria.First(f => Id(f) == Id(alvo));
        Assert.Equal(1, atual.GetProperty("ordem").GetInt32());        // continua no mesmo lugar
        Assert.NotEqual(urlAntiga, atual.GetProperty("url").GetString());
        foreach (var antigo in arquivosAntigos) Assert.False(Existe(antigo), $"{antigo} deveria ter sido apagado");
        Assert.True(Existe(atual.GetProperty("url").GetString()!));
    }

    // ---------------- capa escolhida a dedo ----------------

    [Fact]
    public async Task Administrador_escolhe_qual_foto_e_a_capa()
    {
        var fotos = await EnviarFotosAsync(3);
        var terceira = Id(fotos[2]);

        var r = await _admin.PatchAsync($"/api/admin/produtos/{_produtoId}/imagens/{terceira}/principal", null);
        r.EnsureSuccessStatusCode();

        var galeria = await GaleriaAsync();
        Assert.Equal(terceira, Id(galeria[0]));
        Assert.Equal(3, galeria.Count);
        Assert.Equal([0, 1, 2], galeria.Select(f => f.GetProperty("ordem").GetInt32()).ToList());
    }

    // ---------------- permissões ----------------

    [Fact]
    public async Task Cliente_nao_exclui_nem_substitui_fotos()
    {
        var fotos = await EnviarFotosAsync(1);
        var id = Id(fotos[0]);

        Assert.Equal(HttpStatusCode.Forbidden, (await _cliente.DeleteAsync($"/api/admin/produtos/{_produtoId}/imagens/{id}")).StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, (await _cliente.PatchAsync($"/api/admin/produtos/{_produtoId}/imagens/{id}/principal", null)).StatusCode);

        var conteudo = new MultipartFormDataContent();
        var arquivo = new ByteArrayContent(FotoFalsa(400, 400, MagickColors.Green));
        arquivo.Headers.ContentType = new MediaTypeHeaderValue("image/jpeg");
        conteudo.Add(arquivo, "foto", "tentativa.jpg");
        Assert.Equal(HttpStatusCode.Forbidden, (await _cliente.PostAsync($"/api/admin/produtos/{_produtoId}/imagens/{id}/substituir", conteudo)).StatusCode);

        Assert.Equal(HttpStatusCode.Unauthorized, (await api.CreateClient().DeleteAsync($"/api/admin/produtos/{_produtoId}/imagens/{id}")).StatusCode);
        Assert.Single(await GaleriaAsync());   // continua tudo lá
    }

    [Fact]
    public async Task Exclusao_fica_registrada_com_o_administrador_que_fez()
    {
        var fotos = await EnviarFotosAsync(1);
        (await _admin.DeleteAsync($"/api/admin/produtos/{_produtoId}/imagens/{Id(fotos[0])}")).EnsureSuccessStatusCode();

        var acessos = await _admin.GetFromJsonAsync<JsonElement>("/api/admin/acessos?dias=1&limite=200");
        var registro = acessos.EnumerateArray().FirstOrDefault(r => r.GetProperty("motivo").GetString() == "FotoRemovida");
        Assert.True(registro.ValueKind != JsonValueKind.Undefined, "a exclusão deveria estar no registro de acessos");
        Assert.Equal(ApiDeTeste.AdminEmail.ToLowerInvariant(), registro.GetProperty("email").GetString());
    }

    // ---------------- apoio ----------------

    private static Guid Id(JsonElement foto) => foto.GetProperty("id").GetGuid();

    private static byte[] FotoFalsa(int largura, int altura, MagickColor cor)
    {
        using var img = new MagickImage(cor, (uint)largura, (uint)altura);
        img.Format = MagickFormat.Jpeg;
        return img.ToByteArray();
    }

    private async Task<List<JsonElement>> EnviarFotosAsync(int quantas)
    {
        var cores = new[] { MagickColors.RebeccaPurple, MagickColors.SeaGreen, MagickColors.Goldenrod };
        var conteudo = new MultipartFormDataContent();
        for (var i = 0; i < quantas; i++)
        {
            var arquivo = new ByteArrayContent(FotoFalsa(1200 + i, 900, cores[i % cores.Length]));
            arquivo.Headers.ContentType = new MediaTypeHeaderValue("image/jpeg");
            conteudo.Add(arquivo, "fotos", $"foto{i + 1}.jpg");
        }
        var r = await _admin.PostAsync($"/api/admin/produtos/{_produtoId}/imagens", conteudo);
        r.EnsureSuccessStatusCode();
        return await GaleriaAsync();
    }

    private async Task<List<JsonElement>> GaleriaAsync()
    {
        var produto = await _admin.GetFromJsonAsync<JsonElement>($"/api/admin/produtos/{_produtoId}");
        return produto.GetProperty("imagens").EnumerateArray()
            .OrderBy(f => f.GetProperty("ordem").GetInt32()).ToList();
    }

    private async Task<string> NomeAsync()
    {
        var produto = await _admin.GetFromJsonAsync<JsonElement>($"/api/admin/produtos/{_produtoId}");
        return produto.GetProperty("nome").GetString()!;
    }

    private static string[] ArquivosDe(JsonElement foto) =>
        new[] { "url", "urlMiniatura", "urlGrande", "urlOriginal" }
            .Select(c => foto.TryGetProperty(c, out var v) ? v.GetString() : null)
            .Where(u => !string.IsNullOrWhiteSpace(u)).Select(u => u!).Distinct().ToArray();

    private bool Existe(string url) => File.Exists(Path.Combine(api.PastaUploads, Path.GetFileName(url)));
}
