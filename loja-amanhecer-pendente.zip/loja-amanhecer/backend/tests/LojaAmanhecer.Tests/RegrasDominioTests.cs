using LojaAmanhecer.Domain.Catalogo;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Domain.Pedidos;
using LojaAmanhecer.Domain.Servicos;

namespace LojaAmanhecer.Tests;

public class PrazoTests
{
    [Fact]
    public void Prazo_total_soma_maior_producao_com_transporte()
    {
        Assert.Equal(20, CalculadoraPrazo.PrazoTotal([0, 15, 7], prazoTransporteDias: 5));
    }

    [Fact]
    public void Carrinho_so_pronta_entrega_usa_apenas_transporte()
    {
        Assert.Equal(4, CalculadoraPrazo.PrazoTotal([0, 0], 4));
    }

    [Fact]
    public void Pronta_entrega_sem_estoque_suficiente_usa_prazo_producao()
    {
        var p = new Produto { Disponibilidade = TipoDisponibilidade.ProntaEntrega, Estoque = 2, PrazoProducaoDias = 10 };
        Assert.Equal(0, p.PrazoProducaoPara(2));
        Assert.Equal(10, p.PrazoProducaoPara(3));
    }

    [Fact]
    public void Sob_encomenda_sempre_usa_prazo_producao()
    {
        var p = new Produto { Disponibilidade = TipoDisponibilidade.SobEncomenda, Estoque = 50, PrazoProducaoDias = 12 };
        Assert.Equal(12, p.PrazoProducaoPara(1));
    }
}

public class PedidoTests
{
    [Fact]
    public void Fluxo_completo_registra_historico()
    {
        var p = new Pedido { CodigoRastreio = "AA123456789BR", ServicoFreteId = 1 };
        p.AlterarStatus(StatusPedido.AguardandoPagamento, null);
        p.AlterarStatus(StatusPedido.PagamentoConfirmado, null);
        p.AlterarStatus(StatusPedido.EmProducao, null);
        p.AlterarStatus(StatusPedido.ProntoParaEnvio, null);
        p.AlterarStatus(StatusPedido.Enviado, null);
        p.AlterarStatus(StatusPedido.Entregue, null);
        Assert.Equal(StatusPedido.Entregue, p.Status);
        Assert.Equal(6, p.Historico.Count);
    }

    [Fact]
    public void Nao_permite_enviar_sem_pagamento()
    {
        var p = new Pedido();
        Assert.Throws<RegraNegocioException>(() => p.AlterarStatus(StatusPedido.Enviado, null));
    }

    [Fact]
    public void Nao_permite_enviar_sem_rastreio_quando_ha_transportadora()
    {
        var p = new Pedido { ServicoFreteId = 2 };
        p.AlterarStatus(StatusPedido.PagamentoConfirmado, null);
        p.AlterarStatus(StatusPedido.ProntoParaEnvio, null);
        Assert.Throws<RegraNegocioException>(() => p.AlterarStatus(StatusPedido.Enviado, null));
    }

    [Fact]
    public void Pedido_cancelado_nao_volta()
    {
        var p = new Pedido();
        p.AlterarStatus(StatusPedido.Cancelado, null);
        Assert.False(p.PodeMudarPara(StatusPedido.PagamentoConfirmado));
    }

    [Fact]
    public void Outro_vendedor_nao_assume_pedido_ja_assumido()
    {
        var p = new Pedido();
        p.Assumir(Guid.NewGuid());
        Assert.Throws<RegraNegocioException>(() => p.Assumir(Guid.NewGuid()));
    }

    [Fact]
    public void Numero_formatado()
    {
        Assert.Equal("VA-000042", new Pedido { Numero = 42 }.NumeroFormatado);
    }
}

public class SlugTests
{
    [Theory]
    [InlineData("Colete de Apará", "colete-de-apara")]
    [InlineData("Fotografias, imagens e quadros", "fotografias-imagens-e-quadros")]
    [InlineData("  Broche Preto-Velho  ", "broche-preto-velho")]
    public void Gera_slug(string entrada, string esperado) => Assert.Equal(esperado, Slug.Gerar(entrada));
}

public class EntregaTests
{
    [Fact]
    public void Retirada_no_local_pode_ir_direto_para_entregue()
    {
        var p = new Pedido(); // sem ServicoFreteId = retirada
        p.AlterarStatus(StatusPedido.PagamentoConfirmado, null);
        p.AlterarStatus(StatusPedido.ProntoParaEnvio, null);
        p.AlterarStatus(StatusPedido.Entregue, null);
        Assert.Equal(StatusPedido.Entregue, p.Status);
    }

    [Fact]
    public void Retirada_no_local_dispensa_rastreio_no_envio()
    {
        var p = new Pedido();
        p.AlterarStatus(StatusPedido.PagamentoConfirmado, null);
        p.AlterarStatus(StatusPedido.ProntoParaEnvio, null);
        p.AlterarStatus(StatusPedido.Enviado, null);
        Assert.Equal(StatusPedido.Enviado, p.Status);
    }

    [Fact]
    public void Total_soma_frete_e_desconta()
    {
        var p = new Pedido { Subtotal = 200m, ValorFrete = 27.5m, Desconto = 10m };
        Assert.Equal(217.5m, p.Total);
    }

    [Fact]
    public void Prazo_total_do_pedido_soma_producao_e_transporte()
    {
        var p = new Pedido { PrazoProducaoDias = 15, PrazoTransporteDias = 7 };
        Assert.Equal(22, p.PrazoTotalDias);
    }
}

public class FreteSimuladoTests
{
    [Theory]
    [InlineData("78005-000", "MT")]
    [InlineData("70000000", "DF")]
    [InlineData("01310-100", "SP")]
    [InlineData("90010-000", "RS")]
    public void Identifica_uf_pelo_cep(string cep, string uf) =>
        Assert.Equal(uf, LojaAmanhecer.Infrastructure.Integracoes.ServicoFreteSimulado.UfDoCep(cep));
}
