using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Npgsql;

namespace LojaAmanhecer.Tests;

/// <summary>
/// Sobe a API de verdade contra um banco PostgreSQL só para testes.
/// Defina TESTES_BANCO para apontar outro servidor, se precisar.
/// </summary>
public class ApiDeTeste : WebApplicationFactory<Program>
{
    private const string Servidor = "Host=localhost;Port=5432;Username=loja;Password=loja_dev_123";
    private readonly string _banco = $"loja_testes_{Guid.NewGuid():N}"[..28];

    public string ConexaoTestes => Environment.GetEnvironmentVariable("TESTES_BANCO") is { Length: > 0 } c
        ? c.Replace("{banco}", _banco)
        : $"{Servidor};Database={_banco}";

    /// <summary>Pasta onde a API de teste grava as fotos; usada para conferir a exclusão dos arquivos.</summary>
    public string PastaUploads { get; } = Directory.CreateTempSubdirectory("uploads-testes").FullName;

    public const string AdminEmail = "admin.testes@loja.local";
    public const string AdminSenha = "Admin@Testes123";

    protected override IHost CreateHost(IHostBuilder builder)
    {
        CriarBanco();
        builder.UseEnvironment("Testes");
        builder.ConfigureHostConfiguration(c => c.AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["ConnectionStrings:Banco"] = ConexaoTestes,
            ["Jwt:Chave"] = "chave-exclusiva-dos-testes-com-mais-de-32-caracteres",
            ["Jwt:Emissor"] = "loja-amanhecer",
            ["Jwt:Publico"] = "loja-amanhecer-web",
            ["AdminInicial:Nome"] = "Administrador dos testes",
            ["AdminInicial:Email"] = AdminEmail,
            ["AdminInicial:Senha"] = AdminSenha,
            ["Armazenamento:PastaLocal"] = PastaUploads,
            ["Banco:AplicarMigracoesAoIniciar"] = "true"
        }));
        return base.CreateHost(builder);
    }

    private void CriarBanco()
    {
        using var conexao = new NpgsqlConnection($"{Servidor};Database=postgres");
        conexao.Open();
        using var cmd = conexao.CreateCommand();
        cmd.CommandText = $"DROP DATABASE IF EXISTS \"{_banco}\"; CREATE DATABASE \"{_banco}\";";
        cmd.ExecuteNonQuery();
    }

    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        if (!disposing) return;
        try
        {
            using var conexao = new NpgsqlConnection($"{Servidor};Database=postgres");
            conexao.Open();
            using var cmd = conexao.CreateCommand();
            cmd.CommandText = $"DROP DATABASE IF EXISTS \"{_banco}\" WITH (FORCE);";
            cmd.ExecuteNonQuery();
        }
        catch { /* banco temporário: se sobrar, não atrapalha */ }
    }
}

/// <summary>
/// Cada cliente enxerga apenas a própria conta. Os testes usam DUAS contas de cliente
/// mais a conta administradora, conversando com a API pelo HTTP, como o navegador faz.
/// </summary>
public class IsolamentoClientesTests(ApiDeTeste api) : IClassFixture<ApiDeTeste>, IAsyncLifetime
{
    private HttpClient _ana = null!, _joao = null!, _admin = null!;
    private long _pedidoAna, _pedidoJoao;
    private Guid _enderecoAna, _enderecoJoao;
    private string _emailAna = "", _emailJoao = "";

    public async Task InitializeAsync()
    {
        _admin = api.CreateClient();
        var tokenAdmin = await Json(await _admin.PostAsJsonAsync("/api/painel/auth/login",
            new { email = ApiDeTeste.AdminEmail, senha = ApiDeTeste.AdminSenha }), "token");
        _admin.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", tokenAdmin);

        var produtoId = await CriarProdutoAsync();

        (_ana, _emailAna) = await CriarClienteAsync("Ana Cláudia Ferreira");
        (_joao, _emailJoao) = await CriarClienteAsync("João Batista Lima");

        (_pedidoAna, _enderecoAna) = await CriarPedidoAsync(_ana, produtoId, "Ana Cláudia Ferreira", "78005-000", "Cuiabá", "MT");
        (_pedidoJoao, _enderecoJoao) = await CriarPedidoAsync(_joao, produtoId, "João Batista Lima", "30140-071", "Belo Horizonte", "MG");
    }

    public Task DisposeAsync() => Task.CompletedTask;

    // ---------------- 1. cada cliente vê só os próprios pedidos ----------------

    [Fact]
    public async Task Cliente_lista_apenas_os_proprios_pedidos()
    {
        var pedidosAna = await ListaDeNumerosAsync(_ana);
        var pedidosJoao = await ListaDeNumerosAsync(_joao);

        Assert.Equal([_pedidoAna], pedidosAna);
        Assert.Equal([_pedidoJoao], pedidosJoao);
        Assert.DoesNotContain(_pedidoJoao, pedidosAna);
        Assert.DoesNotContain(_pedidoAna, pedidosJoao);
    }

    // ---------------- 2. não abre o pedido do outro pelo número ----------------

    [Fact]
    public async Task Cliente_nao_abre_pedido_de_outro_cliente()
    {
        var resposta = await _ana.GetAsync($"/api/pedidos/{_pedidoJoao}");
        Assert.Equal(HttpStatusCode.NotFound, resposta.StatusCode);

        var aoContrario = await _joao.GetAsync($"/api/pedidos/{_pedidoAna}");
        Assert.Equal(HttpStatusCode.NotFound, aoContrario.StatusCode);

        // o próprio pedido continua abrindo, com itens, pagamento, prazos e rastreio
        var meu = await _ana.GetAsync($"/api/pedidos/{_pedidoAna}");
        meu.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await meu.Content.ReadAsStringAsync());
        Assert.Equal(_pedidoAna, doc.RootElement.GetProperty("numero").GetInt64());
        Assert.True(doc.RootElement.GetProperty("itens").GetArrayLength() > 0);
        Assert.True(doc.RootElement.TryGetProperty("pagamento", out _));
        Assert.True(doc.RootElement.GetProperty("prazoTotalDias").GetInt32() >= 0);
    }

    [Theory]
    [InlineData(999999)]
    [InlineData(1)]
    public async Task Numeros_chutados_na_url_nao_abrem_nada(long numero)
    {
        var r = await _ana.GetAsync($"/api/pedidos/{numero}");
        Assert.True(r.StatusCode is HttpStatusCode.NotFound, $"esperava 404, veio {r.StatusCode}");
    }

    // ---------------- 3. não mexe nos dados nem nos endereços do outro ----------------

    [Fact]
    public async Task Cliente_ve_e_altera_apenas_os_proprios_dados()
    {
        var meus = await _ana.GetFromJsonAsync<JsonElement>("/api/conta/dados");
        Assert.Equal(_emailAna, meus.GetProperty("email").GetString());

        // alterar os próprios dados funciona e não toca na outra conta
        var alterar = await _ana.PutAsJsonAsync("/api/conta/dados", new { nomeCompleto = "Ana C. Ferreira", telefone = "(65) 96666-3333", cpf = (string?)null });
        Assert.Equal(HttpStatusCode.NoContent, alterar.StatusCode);

        var doJoao = await _joao.GetFromJsonAsync<JsonElement>("/api/conta/dados");
        Assert.Equal("João Batista Lima", doJoao.GetProperty("nomeCompleto").GetString());
        Assert.Equal(_emailJoao, doJoao.GetProperty("email").GetString());
    }

    [Fact]
    public async Task Cliente_nao_altera_nem_apaga_endereco_de_outro()
    {
        var enderecosAna = await _ana.GetFromJsonAsync<JsonElement>("/api/conta/enderecos");
        Assert.Equal(1, enderecosAna.GetArrayLength());
        Assert.Equal(_enderecoAna, enderecosAna[0].GetProperty("id").GetGuid());

        var alterar = await _ana.PutAsJsonAsync($"/api/conta/enderecos/{_enderecoJoao}", new
        {
            apelido = "Invadido", destinatario = "Ana", cep = "78005-000", logradouro = "Rua X",
            numero = "1", complemento = (string?)null, bairro = "Centro", cidade = "Cuiabá", uf = "MT", principal = true
        });
        Assert.Equal(HttpStatusCode.NotFound, alterar.StatusCode);

        var apagar = await _ana.DeleteAsync($"/api/conta/enderecos/{_enderecoJoao}");
        Assert.Equal(HttpStatusCode.NotFound, apagar.StatusCode);

        // o endereço do João continua intacto
        var doJoao = await _joao.GetFromJsonAsync<JsonElement>("/api/conta/enderecos");
        Assert.Equal(1, doJoao.GetArrayLength());
        Assert.Equal("Belo Horizonte", doJoao[0].GetProperty("cidade").GetString());
    }

    [Fact]
    public async Task Cliente_nao_compra_usando_endereco_de_outro()
    {
        var produtoId = await PrimeiroProdutoAsync();
        var resposta = await _ana.PostAsJsonAsync("/api/pedidos", new
        {
            itens = new[] { new { produtoId, variacaoId = (Guid?)null, quantidade = 1, personalizacao = (string?)null } },
            enderecoId = _enderecoJoao,   // endereço de outra conta
            servicoFreteId = 1,
            metodoPagamento = "Pix"
        });
        Assert.Equal(HttpStatusCode.UnprocessableEntity, resposta.StatusCode);
        Assert.Contains("não encontrado", await resposta.Content.ReadAsStringAsync());
    }

    // ---------------- 4. nenhuma rota administrativa ----------------

    [Theory]
    [InlineData("/api/admin/pedidos")]
    [InlineData("/api/admin/produtos")]
    [InlineData("/api/admin/categorias")]
    [InlineData("/api/admin/clientes")]
    [InlineData("/api/admin/usuarios/clientes")]
    [InlineData("/api/admin/usuarios/equipe")]
    [InlineData("/api/admin/painel/resumo")]
    [InlineData("/api/admin/relatorios/vendas")]
    [InlineData("/api/admin/acessos")]
    [InlineData("/api/painel/auth/eu")]
    public async Task Cliente_nao_acessa_rota_administrativa(string rota)
    {
        var r = await _ana.GetAsync(rota);
        Assert.True(r.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.NotFound,
            $"{rota} devolveu {r.StatusCode}");
        if (r.StatusCode == HttpStatusCode.Forbidden)
            Assert.Contains("Acesso não autorizado", await r.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task Cliente_nao_entra_no_painel_nem_com_a_senha_certa()
    {
        var r = await api.CreateClient().PostAsJsonAsync("/api/painel/auth/login", new { email = _emailAna, senha = "senha1234" });
        Assert.Equal(HttpStatusCode.Forbidden, r.StatusCode);
        Assert.Contains("Acesso não autorizado", await r.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task Cliente_nao_muda_status_nem_rastreio_de_pedido()
    {
        var status = await _ana.PatchAsJsonAsync($"/api/admin/pedidos/{_pedidoAna}/status", new { status = "Entregue", comentario = "" });
        Assert.Equal(HttpStatusCode.Forbidden, status.StatusCode);

        var rastreio = await _ana.PutAsJsonAsync($"/api/admin/pedidos/{_pedidoAna}/rastreio", new { codigoRastreio = "AA123456789BR" });
        Assert.Equal(HttpStatusCode.Forbidden, rastreio.StatusCode);
    }

    [Fact]
    public async Task Sem_token_nada_de_conta_nem_de_pedidos()
    {
        var anonimo = api.CreateClient();
        foreach (var rota in new[] { "/api/pedidos", $"/api/pedidos/{_pedidoAna}", "/api/conta/dados", "/api/conta/enderecos" })
            Assert.Equal(HttpStatusCode.Unauthorized, (await anonimo.GetAsync(rota)).StatusCode);
    }

    // ---------------- 5. o administrador continua vendo tudo ----------------

    [Fact]
    public async Task Administrador_consulta_todos_os_clientes_e_pedidos()
    {
        var pedidos = await _admin.GetFromJsonAsync<JsonElement>("/api/admin/pedidos");
        var numeros = pedidos.GetProperty("itens").EnumerateArray().Select(p => p.GetProperty("numero").GetInt64()).ToList();
        Assert.Contains(_pedidoAna, numeros);
        Assert.Contains(_pedidoJoao, numeros);

        foreach (var numero in new[] { _pedidoAna, _pedidoJoao })
        {
            var detalhe = await _admin.GetAsync($"/api/admin/pedidos/{numero}");
            detalhe.EnsureSuccessStatusCode();
        }

        var clientes = await _admin.GetFromJsonAsync<JsonElement>("/api/admin/usuarios/clientes");
        var emails = clientes.EnumerateArray().Select(c => c.GetProperty("email").GetString()).ToList();
        Assert.Contains(_emailAna, emails);
        Assert.Contains(_emailJoao, emails);
    }

    [Fact]
    public async Task Tentativa_de_abrir_pedido_alheio_fica_registrada()
    {
        await _ana.GetAsync($"/api/pedidos/{_pedidoJoao}");
        var acessos = await _admin.GetFromJsonAsync<JsonElement>("/api/admin/acessos?dias=1&limite=200");
        var houve = acessos.EnumerateArray().Any(r =>
            r.GetProperty("motivo").GetString() == "PedidoDeOutroCliente" &&
            r.GetProperty("email").GetString() == _emailAna.ToLowerInvariant());
        Assert.True(houve, "a tentativa deveria estar no registro de acessos");
    }

    // ---------------- apoio ----------------

    private static async Task<string> Json(HttpResponseMessage resposta, string campo)
    {
        resposta.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await resposta.Content.ReadAsStringAsync());
        return doc.RootElement.GetProperty(campo).GetString()!;
    }

    private async Task<(HttpClient Cliente, string Email)> CriarClienteAsync(string nome)
    {
        var email = $"{Guid.NewGuid():N}@teste.com"[..20].Replace("@", "") + "@teste.com";
        var http = api.CreateClient();
        var token = await Json(await http.PostAsJsonAsync("/api/auth/registrar",
            new { nomeCompleto = nome, email, senha = "senha1234", telefone = "(61) 98888-0000", cpf = (string?)null }), "token");
        http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        return (http, email);
    }

    private async Task<Guid> CriarProdutoAsync()
    {
        var categorias = await _admin.GetFromJsonAsync<JsonElement>("/api/categorias");
        var categoriaId = categorias[0].GetProperty("subcategorias")[0].GetProperty("id").GetGuid();
        var resposta = await _admin.PostAsJsonAsync("/api/admin/produtos", new
        {
            nome = "Broche de teste", descricao = "Produto usado nos testes", categoriaId,
            preco = 49.9m, estoque = 50, pesoGramas = 150, alturaCm = 3m, larguraCm = 10m, comprimentoCm = 12m,
            disponibilidade = "ProntaEntrega", prazoProducaoDias = 7, permitePersonalizacao = false,
            rotuloPersonalizacao = (string?)null, limiteCaracteresPersonalizacao = (int?)null, valorPersonalizacao = 0m,
            ativo = true, destaque = true, opcoes = Array.Empty<object>(), variacoes = Array.Empty<object>()
        });
        resposta.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await resposta.Content.ReadAsStringAsync());
        return doc.RootElement.GetProperty("id").GetGuid();
    }

    private async Task<Guid> PrimeiroProdutoAsync()
    {
        var produtos = await _admin.GetFromJsonAsync<JsonElement>("/api/produtos");
        return produtos.GetProperty("itens")[0].GetProperty("id").GetGuid();
    }

    private async Task<(long Numero, Guid EnderecoId)> CriarPedidoAsync(HttpClient cliente, Guid produtoId, string nome, string cep, string cidade, string uf)
    {
        var resposta = await cliente.PostAsJsonAsync("/api/pedidos", new
        {
            itens = new[] { new { produtoId, variacaoId = (Guid?)null, quantidade = 1, personalizacao = (string?)null } },
            novoEndereco = new
            {
                id = (Guid?)null, apelido = "Casa", destinatario = nome, cep, logradouro = "Rua das Flores",
                numero = "100", complemento = (string?)null, bairro = "Centro", cidade, uf, principal = true
            },
            servicoFreteId = 1,
            metodoPagamento = "Pix",
            observacao = (string?)null
        });
        resposta.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await resposta.Content.ReadAsStringAsync());
        var numero = doc.RootElement.GetProperty("numero").GetInt64();

        var enderecos = await cliente.GetFromJsonAsync<JsonElement>("/api/conta/enderecos");
        return (numero, enderecos[0].GetProperty("id").GetGuid());
    }

    private static async Task<List<long>> ListaDeNumerosAsync(HttpClient cliente)
    {
        var pedidos = await cliente.GetFromJsonAsync<JsonElement>("/api/pedidos");
        return pedidos.EnumerateArray().Select(p => p.GetProperty("numero").GetInt64()).ToList();
    }
}
