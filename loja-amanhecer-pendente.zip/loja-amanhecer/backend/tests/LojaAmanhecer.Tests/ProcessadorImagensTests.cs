using ImageMagick;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Catalogo;
using LojaAmanhecer.Infrastructure.Imagens;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;

namespace LojaAmanhecer.Tests;

/// <summary>Armazenamento de mentira: guarda os arquivos numa pasta temporária do teste.</summary>
public class ArmazenamentoDeTeste : IArmazenamentoArquivos
{
    public string Pasta { get; } = Directory.CreateTempSubdirectory("fotos-teste").FullName;
    public List<string> Salvos { get; } = [];

    public Task<string> SalvarAsync(Stream conteudo, string nomeArquivo, string contentType, CancellationToken ct = default)
        => SalvarComNomeAsync(conteudo, nomeArquivo, ct);

    public async Task<string> SalvarComNomeAsync(Stream conteudo, string nomeArquivo, CancellationToken ct = default)
    {
        var caminho = Path.Combine(Pasta, Path.GetFileName(nomeArquivo));
        await using (var destino = File.Create(caminho)) await conteudo.CopyToAsync(destino, ct);
        Salvos.Add(caminho);
        return $"/uploads/{Path.GetFileName(nomeArquivo)}";
    }

    public Task RemoverAsync(string url, CancellationToken ct = default) => Task.CompletedTask;
}

public class ProcessadorImagensTests
{
    private static ProcessadorImagens Criar(ArmazenamentoDeTeste armazenamento, Dictionary<string, string?>? extra = null)
    {
        var config = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["Armazenamento:PastaLocal"] = armazenamento.Pasta,
            ["Imagens:Miniatura"] = "400", ["Imagens:Catalogo"] = "900", ["Imagens:Produto"] = "1600"
        }.Concat(extra ?? []).ToDictionary(x => x.Key, x => x.Value)).Build();
        return new ProcessadorImagens(armazenamento, config, NullLogger<ProcessadorImagens>.Instance);
    }

    private static MemoryStream FotoJpeg(int largura, int altura, OrientationType? orientacao = null)
    {
        using var img = new MagickImage(MagickColors.RebeccaPurple, (uint)largura, (uint)altura);
        img.Format = MagickFormat.Jpeg;
        if (orientacao is not null)
        {
            var exif = new ExifProfile();
            exif.SetValue(ExifTag.Orientation, (ushort)orientacao.Value);
            img.SetProfile(exif);
        }
        var ms = new MemoryStream();
        img.Write(ms);
        ms.Position = 0;
        return ms;
    }

    [Theory]
    [InlineData("foto.jpg", true)]
    [InlineData("FOTO.JPEG", true)]
    [InlineData("IMG_4821.HEIC", true)]
    [InlineData("imagem.heif", true)]
    [InlineData("desenho.png", true)]
    [InlineData("moderna.avif", true)]
    [InlineData("planilha.xlsx", false)]
    [InlineData("texto.txt", false)]
    public void Aceita_os_formatos_combinados(string nome, bool esperado) =>
        Assert.Equal(esperado, Criar(new ArmazenamentoDeTeste()).Aceita(nome, null));

    [Fact]
    public async Task Gera_as_tres_versoes_e_preserva_o_original()
    {
        var armazenamento = new ArmazenamentoDeTeste();
        var processador = Criar(armazenamento);
        using var foto = FotoJpeg(3000, 2000);
        var bytesOriginais = foto.ToArray();
        foto.Position = 0;

        var r = await processador.ProcessarAsync(foto, "IMG_1234.jpg");

        Assert.EndsWith("-original.jpg", r.UrlOriginal);
        Assert.EndsWith(".webp", r.UrlMiniatura);
        Assert.EndsWith(".webp", r.UrlCatalogo);
        Assert.EndsWith(".webp", r.UrlGrande);
        Assert.Equal(4, armazenamento.Salvos.Count);

        // o original precisa ficar byte a byte igual ao que o vendedor enviou
        var original = Path.Combine(armazenamento.Pasta, Path.GetFileName(r.UrlOriginal));
        Assert.Equal(bytesOriginais, await File.ReadAllBytesAsync(original));

        static uint LadoMaior(string caminho) { using var i = new MagickImage(caminho); return Math.Max(i.Width, i.Height); }
        Assert.Equal(400u, LadoMaior(Path.Combine(armazenamento.Pasta, Path.GetFileName(r.UrlMiniatura))));
        Assert.Equal(900u, LadoMaior(Path.Combine(armazenamento.Pasta, Path.GetFileName(r.UrlCatalogo))));
        Assert.Equal(1600u, LadoMaior(Path.Combine(armazenamento.Pasta, Path.GetFileName(r.UrlGrande))));
        Assert.True(r.BytesCatalogo < r.BytesOriginal, "a versão de catálogo precisa ser menor que o original");
    }

    [Fact]
    public async Task Nao_amplia_foto_pequena()
    {
        var armazenamento = new ArmazenamentoDeTeste();
        using var foto = FotoJpeg(300, 200);
        var r = await Criar(armazenamento).ProcessarAsync(foto, "pequena.jpg");
        using var grande = new MagickImage(Path.Combine(armazenamento.Pasta, Path.GetFileName(r.UrlGrande)));
        Assert.Equal(300u, grande.Width);
    }

    [Fact]
    public async Task Converte_para_avif_quando_configurado()
    {
        var armazenamento = new ArmazenamentoDeTeste();
        var processador = Criar(armazenamento, new Dictionary<string, string?> { ["Imagens:Formato"] = "avif" });
        using var foto = FotoJpeg(1200, 800);
        var r = await processador.ProcessarAsync(foto, "foto.jpg");
        Assert.EndsWith(".avif", r.UrlCatalogo);
        Assert.EndsWith("-original.jpg", r.UrlOriginal);
    }

    [Fact]
    public async Task Arquivo_vazio_vira_erro_de_regra_de_negocio()
    {
        var processador = Criar(new ArmazenamentoDeTeste());
        using var vazio = new MemoryStream();
        await Assert.ThrowsAsync<LojaAmanhecer.Domain.Comum.RegraNegocioException>(
            () => processador.ProcessarAsync(vazio, "foto.jpg"));
    }
}

public class ProdutoImagemTests
{
    [Fact]
    public void Foto_antiga_sem_versoes_cai_para_a_url_principal()
    {
        var img = new ProdutoImagem { Url = "/uploads/antiga.png" };
        Assert.Equal("/uploads/antiga.png", img.Miniatura);
        Assert.Equal("/uploads/antiga.png", img.Grande);
    }

    [Fact]
    public void Foto_nova_usa_cada_versao()
    {
        var img = new ProdutoImagem { Url = "/uploads/a-cat.webp", UrlMiniatura = "/uploads/a-mini.webp", UrlGrande = "/uploads/a-grande.webp" };
        Assert.Equal("/uploads/a-mini.webp", img.Miniatura);
        Assert.Equal("/uploads/a-grande.webp", img.Grande);
    }
}

public class FotoDeCategoriaTests
{
    private static ProcessadorImagens Criar(ArmazenamentoDeTeste a)
    {
        var config = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["Armazenamento:PastaLocal"] = a.Pasta,
            ["Imagens:CategoriaMedalhao"] = "600", ["Imagens:CategoriaMiniatura"] = "200"
        }).Build();
        return new ProcessadorImagens(a, config, NullLogger<ProcessadorImagens>.Instance);
    }

    private static MemoryStream Foto(int largura, int altura)
    {
        using var img = new MagickImage(MagickColors.SeaGreen, (uint)largura, (uint)altura);
        img.Format = MagickFormat.Jpeg;
        var ms = new MemoryStream();
        img.Write(ms);
        ms.Position = 0;
        return ms;
    }

    [Fact]
    public void Sem_recorte_corta_quadrado_no_centro()
    {
        var r = ProcessadorImagens.AjustarRecorte(null, 4000, 3000);
        Assert.Equal(new Recorte(500, 0, 3000, 3000), r);
    }

    [Fact]
    public void Recorte_fora_da_foto_e_encaixado_dentro_dela()
    {
        var r = ProcessadorImagens.AjustarRecorte(new Recorte(-50, 2500, 5000, 5000), 4000, 3000);
        Assert.True(r.X >= 0 && r.Y >= 0);
        Assert.True(r.X + r.Largura <= 4000);
        Assert.True(r.Y + r.Altura <= 3000);
    }

    [Fact]
    public void Recorte_do_painel_vira_quadrado()
    {
        var r = ProcessadorImagens.AjustarRecorte(new Recorte(100, 200, 900, 1200), 4000, 3000);
        Assert.Equal(900, r.Largura);
        Assert.Equal(900, r.Altura);
        Assert.Equal(100, r.X);
        Assert.Equal(200, r.Y);
    }

    [Fact]
    public async Task Gera_medalhao_quadrado_e_preserva_o_original()
    {
        var armazenamento = new ArmazenamentoDeTeste();
        using var foto = Foto(4000, 3000);
        var bytes = foto.ToArray();
        foto.Position = 0;

        var r = await Criar(armazenamento).ProcessarQuadradoAsync(foto, "IMG_0007.jpg", new Recorte(400, 200, 2000, 2000));

        using var medalhao = new MagickImage(Path.Combine(armazenamento.Pasta, Path.GetFileName(r.UrlCatalogo)));
        using var mini = new MagickImage(Path.Combine(armazenamento.Pasta, Path.GetFileName(r.UrlMiniatura)));
        Assert.Equal(600u, medalhao.Width);
        Assert.Equal(600u, medalhao.Height);
        Assert.Equal(200u, mini.Width);
        Assert.Equal(200u, mini.Height);
        Assert.Equal(bytes, await File.ReadAllBytesAsync(Path.Combine(armazenamento.Pasta, Path.GetFileName(r.UrlOriginal))));
    }

    [Fact]
    public async Task Foto_menor_que_o_medalhao_nao_e_ampliada()
    {
        var armazenamento = new ArmazenamentoDeTeste();
        using var foto = Foto(300, 300);
        var r = await Criar(armazenamento).ProcessarQuadradoAsync(foto, "pequena.jpg", null);
        using var medalhao = new MagickImage(Path.Combine(armazenamento.Pasta, Path.GetFileName(r.UrlCatalogo)));
        Assert.Equal(300u, medalhao.Width);
    }
}

public class CategoriaComFotoTests
{
    [Fact]
    public void Categoria_sem_foto_usa_ilustracao_padrao()
    {
        var c = new LojaAmanhecer.Domain.Catalogo.Categoria { Nome = "Broches de povos" };
        Assert.False(c.TemFoto);
    }

    [Fact]
    public void Categoria_com_foto_e_sinalizada_para_a_loja()
    {
        var c = new LojaAmanhecer.Domain.Catalogo.Categoria { Nome = "Coletes", ImagemUrl = "/uploads/x-cat.webp" };
        Assert.True(c.TemFoto);
    }
}

public class ArmazenamentoS3Tests
{
    [Theory]
    [InlineData("/uploads/abc123-cat.webp", "abc123-cat.webp")]
    [InlineData("https://cdn.lojinha.com.br/abc123-original.heic", "abc123-original.heic")]
    [InlineData("https://bucket.r2.cloudflarestorage.com/uploads/abc123-mini.webp?v=2", "abc123-mini.webp")]
    [InlineData("abc123-grande.webp", "abc123-grande.webp")]
    public void Descobre_o_arquivo_a_apagar_a_partir_da_url(string url, string esperado) =>
        Assert.Equal(esperado, LojaAmanhecer.Infrastructure.Armazenamento.ArmazenamentoS3.ChaveDe(url));
}
