using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using LojaAmanhecer.Api.Seguranca;
using Microsoft.Extensions.Configuration;

namespace LojaAmanhecer.Tests;

/// <summary>Área "Pagamentos e recebimentos": acesso, credenciais e recebimentos.</summary>
public class PagamentosAdminTests(ApiDeTeste api) : IClassFixture<ApiDeTeste>, IAsyncLifetime
{
    private HttpClient _admin = null!, _cliente = null!;
    private Guid _produtoId;

    public async Task InitializeAsync()
    {
        _admin = api.CreateClient();
        var login = await _admin.PostAsJsonAsync("/api/painel/auth/login", new { email = ApiDeTeste.AdminEmail, senha = ApiDeTeste.AdminSenha });
        login.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await login.Content.ReadAsStringAsync());
        _admin.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", doc.RootElement.GetProperty("token").GetString());

        _cliente = api.CreateClient();
        var conta = await _cliente.PostAsJsonAsync("/api/auth/registrar",
            new { nomeCompleto = "Cliente Pagamentos", email = $"pag{Guid.NewGuid():N}"[..14] + "@teste.com", senha = "senha1234", telefone = (string?)null, cpf = (string?)null });
        using var doc2 = JsonDocument.Parse(await conta.Content.ReadAsStringAsync());
        _cliente.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", doc2.RootElement.GetProperty("token").GetString());

        var categorias = await _admin.GetFromJsonAsync<JsonElement>("/api/categorias");
        var categoriaId = categorias[0].GetProperty("subcategorias")[0].GetProperty("id").GetGuid();
        var produto = await _admin.PostAsJsonAsync("/api/admin/produtos", new
        {
            nome = "Produto de pagamento", descricao = "teste", categoriaId, preco = 120m, estoque = 20,
            pesoGramas = 200, alturaCm = 3m, larguraCm = 10m, comprimentoCm = 12m, disponibilidade = "ProntaEntrega",
            prazoProducaoDias = 5, permitePersonalizacao = false, rotuloPersonalizacao = (string?)null,
            limiteCaracteresPersonalizacao = (int?)null, valorPersonalizacao = 0m, ativo = true, destaque = false,
            opcoes = Array.Empty<object>(), variacoes = Array.Empty<object>()
        });
        using var doc3 = JsonDocument.Parse(await produto.Content.ReadAsStringAsync());
        _produtoId = doc3.RootElement.GetProperty("id").GetGuid();
    }

    public Task DisposeAsync() => Task.CompletedTask;

    [Theory]
    [InlineData("/api/admin/pagamentos/configuracao")]
    [InlineData("/api/admin/pagamentos")]
    [InlineData("/api/admin/pagamentos/resumo")]
    public async Task Somente_administrador_acessa(string rota)
    {
        Assert.Equal(HttpStatusCode.Forbidden, (await _cliente.GetAsync(rota)).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized, (await api.CreateClient().GetAsync(rota)).StatusCode);
        (await _admin.GetAsync(rota)).EnsureSuccessStatusCode();
    }

    [Fact]
    public async Task Cliente_nao_altera_configuracao_nem_credencial()
    {
        var config = await _cliente.PutAsJsonAsync("/api/admin/pagamentos/configuracao", new
        { pixAtivo = true, cartaoAtivo = true, boletoAtivo = true, maximoParcelas = 12, parcelamentoComJuros = true, valorMinimoParcela = 10m, ambiente = "producao", taxaPix = 0m, taxaCartao = 0m, taxaBoleto = 0m });
        Assert.Equal(HttpStatusCode.Forbidden, config.StatusCode);

        var credencial = await _cliente.PutAsJsonAsync("/api/admin/pagamentos/credencial", new { accessToken = "TEST-1234567890123456789012345", ambiente = "teste", testarAntes = false });
        Assert.Equal(HttpStatusCode.Forbidden, credencial.StatusCode);
    }

    [Fact]
    public async Task Comeca_em_modo_simulado_sem_nenhuma_credencial()
    {
        var c = await _admin.GetFromJsonAsync<JsonElement>("/api/admin/pagamentos/configuracao");
        Assert.True(c.GetProperty("simulado").GetBoolean());
        Assert.False(c.GetProperty("conectado").GetBoolean());
        Assert.Equal("", c.GetProperty("tokenMascarado").GetString());
        Assert.Equal("teste", c.GetProperty("ambiente").GetString());
    }

    [Fact]
    public async Task Credencial_e_guardada_cifrada_e_so_aparece_mascarada()
    {
        const string token = "TEST-0123456789012345678901234567-abcdef";
        var salvar = await _admin.PutAsJsonAsync("/api/admin/pagamentos/credencial", new { accessToken = token, ambiente = "teste", testarAntes = false });
        salvar.EnsureSuccessStatusCode();
        var corpo = await salvar.Content.ReadAsStringAsync();

        Assert.DoesNotContain(token, corpo);                       // o token completo nunca vai para o navegador
        Assert.Contains("••••", corpo);
        using var doc = JsonDocument.Parse(corpo);
        Assert.True(doc.RootElement.GetProperty("conectado").GetBoolean());
        Assert.EndsWith("cdef", doc.RootElement.GetProperty("tokenMascarado").GetString());

        // e no banco fica cifrado, não em texto puro
        var guardado = await ValorNoBancoAsync("pagamento.mp.access_token");
        Assert.StartsWith("v1.", guardado);
        Assert.DoesNotContain(token, guardado);

        // desconectar volta ao modo simulado
        var remover = await _admin.DeleteAsync("/api/admin/pagamentos/credencial");
        remover.EnsureSuccessStatusCode();
        using var doc2 = JsonDocument.Parse(await remover.Content.ReadAsStringAsync());
        Assert.True(doc2.RootElement.GetProperty("simulado").GetBoolean());
    }

    [Fact]
    public async Task Token_curto_demais_e_recusado()
    {
        var r = await _admin.PutAsJsonAsync("/api/admin/pagamentos/credencial", new { accessToken = "curto", ambiente = "teste", testarAntes = false });
        Assert.Equal(HttpStatusCode.UnprocessableEntity, r.StatusCode);
    }

    [Fact]
    public async Task Teste_de_conexao_em_modo_simulado_avisa_que_nao_ha_conta()
    {
        var r = await _admin.PostAsJsonAsync("/api/admin/pagamentos/testar-conexao", new { });
        r.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await r.Content.ReadAsStringAsync());
        Assert.False(doc.RootElement.GetProperty("ok").GetBoolean());
        Assert.True(doc.RootElement.GetProperty("simulado").GetBoolean());
    }

    [Fact]
    public async Task Formas_de_pagamento_e_parcelamento_valem_na_loja()
    {
        var salvar = await _admin.PutAsJsonAsync("/api/admin/pagamentos/configuracao", new
        { pixAtivo = true, cartaoAtivo = false, boletoAtivo = true, maximoParcelas = 6, parcelamentoComJuros = true, valorMinimoParcela = 25m, ambiente = "teste", taxaPix = 1.2m, taxaCartao = 4.5m, taxaBoleto = 3m });
        salvar.EnsureSuccessStatusCode();

        var opcoes = await api.CreateClient().GetFromJsonAsync<JsonElement>("/api/pagamentos/opcoes");
        Assert.True(opcoes.GetProperty("pix").GetBoolean());
        Assert.False(opcoes.GetProperty("cartao").GetBoolean());
        Assert.Equal(6, opcoes.GetProperty("maximoParcelas").GetInt32());
        Assert.True(opcoes.GetProperty("comJuros").GetBoolean());
        Assert.Equal(25m, opcoes.GetProperty("valorMinimoParcela").GetDecimal());

        // cliente tentando pagar com cartão desativado
        var pedido = await CriarPedidoAsync("CartaoCredito");
        Assert.Equal(HttpStatusCode.UnprocessableEntity, pedido.StatusCode);
        Assert.Contains("não está disponível", await pedido.Content.ReadAsStringAsync());

        // volta tudo ligado
        (await _admin.PutAsJsonAsync("/api/admin/pagamentos/configuracao", new
        { pixAtivo = true, cartaoAtivo = true, boletoAtivo = true, maximoParcelas = 3, parcelamentoComJuros = false, valorMinimoParcela = 30m, ambiente = "teste", taxaPix = 0.99m, taxaCartao = 4.98m, taxaBoleto = 3.49m })).EnsureSuccessStatusCode();
    }

    [Fact]
    public async Task Desativar_todas_as_formas_e_recusado()
    {
        var r = await _admin.PutAsJsonAsync("/api/admin/pagamentos/configuracao", new
        { pixAtivo = false, cartaoAtivo = false, boletoAtivo = false, maximoParcelas = 3, parcelamentoComJuros = false, valorMinimoParcela = 30m, ambiente = "teste", taxaPix = 1m, taxaCartao = 1m, taxaBoleto = 1m });
        Assert.Equal(HttpStatusCode.UnprocessableEntity, r.StatusCode);
    }

    [Fact]
    public async Task Recebimentos_mostram_pedido_taxa_liquido_e_permitem_estorno()
    {
        var criado = await CriarPedidoAsync("Pix");
        criado.EnsureSuccessStatusCode();
        using var docPedido = JsonDocument.Parse(await criado.Content.ReadAsStringAsync());
        var numero = docPedido.RootElement.GetProperty("numero").GetInt64();
        var valor = docPedido.RootElement.GetProperty("total").GetDecimal();

        // o vendedor confirma o pagamento (modo simulado não recebe webhook)
        (await _admin.PostAsync($"/api/admin/pedidos/{numero}/assumir", null)).EnsureSuccessStatusCode();
        (await _admin.PostAsync($"/api/admin/pedidos/{numero}/confirmar-pagamento?observacao=Pix%20recebido", null)).EnsureSuccessStatusCode();

        var lista = await _admin.GetFromJsonAsync<JsonElement>($"/api/admin/pagamentos?busca={numero}");
        var pagamento = lista.EnumerateArray().First(p => p.GetProperty("pedidoNumero").GetInt64() == numero);
        Assert.Equal($"VA-{numero:D6}", pagamento.GetProperty("pedidoFormatado").GetString());
        Assert.Equal("Aprovado", pagamento.GetProperty("statusTexto").GetString());
        Assert.Equal(valor, pagamento.GetProperty("valor").GetDecimal());
        Assert.True(pagamento.GetProperty("liquido").GetDecimal() > 0);
        Assert.True(pagamento.GetProperty("podeEstornar").GetBoolean());
        Assert.Equal("simulado", pagamento.GetProperty("ambiente").GetString());

        var id = pagamento.GetProperty("id").GetGuid();

        // estorno parcial
        var parcial = await _admin.PostAsJsonAsync($"/api/admin/pagamentos/{id}/estornar", new { valor = 10m, motivo = "Ajuste de frete" });
        parcial.EnsureSuccessStatusCode();
        using var docParcial = JsonDocument.Parse(await parcial.Content.ReadAsStringAsync());
        Assert.Equal(10m, docParcial.RootElement.GetProperty("valorEstornado").GetDecimal());
        Assert.Equal("Aprovado", docParcial.RootElement.GetProperty("statusTexto").GetString());

        // estorno maior que o disponível é recusado
        var demais = await _admin.PostAsJsonAsync($"/api/admin/pagamentos/{id}/estornar", new { valor = valor, motivo = "erro" });
        Assert.Equal(HttpStatusCode.UnprocessableEntity, demais.StatusCode);

        // estorno total (sem valor) fecha o pagamento
        var total = await _admin.PostAsJsonAsync($"/api/admin/pagamentos/{id}/estornar", new { valor = (decimal?)null, motivo = "Pedido cancelado" });
        total.EnsureSuccessStatusCode();
        using var docTotal = JsonDocument.Parse(await total.Content.ReadAsStringAsync());
        Assert.Equal("Estornado", docTotal.RootElement.GetProperty("statusTexto").GetString());

        var resumo = await _admin.GetFromJsonAsync<JsonElement>("/api/admin/pagamentos/resumo");
        Assert.True(resumo.GetProperty("totalEstornado").GetDecimal() >= valor);
        Assert.True(resumo.GetProperty("simulado").GetBoolean());
    }

    [Fact]
    public async Task Pagamento_pendente_nao_pode_ser_estornado()
    {
        var criado = await CriarPedidoAsync("Boleto");
        criado.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await criado.Content.ReadAsStringAsync());
        var numero = doc.RootElement.GetProperty("numero").GetInt64();

        var lista = await _admin.GetFromJsonAsync<JsonElement>($"/api/admin/pagamentos?busca={numero}");
        var id = lista.EnumerateArray().First().GetProperty("id").GetGuid();

        var r = await _admin.PostAsJsonAsync($"/api/admin/pagamentos/{id}/estornar", new { valor = (decimal?)null, motivo = "teste" });
        Assert.Equal(HttpStatusCode.UnprocessableEntity, r.StatusCode);
    }

    // ---------------- apoio ----------------

    private Task<HttpResponseMessage> CriarPedidoAsync(string metodo) => _cliente.PostAsJsonAsync("/api/pedidos", new
    {
        itens = new[] { new { produtoId = _produtoId, variacaoId = (Guid?)null, quantidade = 1, personalizacao = (string?)null } },
        novoEndereco = new
        {
            id = (Guid?)null, apelido = "Casa", destinatario = "Cliente Pagamentos", cep = "78005-000",
            logradouro = "Rua A", numero = "10", complemento = (string?)null, bairro = "Centro", cidade = "Cuiabá", uf = "MT", principal = true
        },
        servicoFreteId = 1, metodoPagamento = metodo, observacao = (string?)null
    });

    private async Task<string> ValorNoBancoAsync(string chave)
    {
        await using var conexao = new Npgsql.NpgsqlConnection(api.ConexaoTestes);
        await conexao.OpenAsync();
        await using var cmd = conexao.CreateCommand();
        cmd.CommandText = "select valor from configuracoes where chave = @c";
        cmd.Parameters.AddWithValue("c", chave);
        return (await cmd.ExecuteScalarAsync()) as string ?? "";
    }
}

public class CofreTests
{
    private static Cofre Criar() => new(new ConfigurationBuilder()
        .AddInMemoryCollection(new Dictionary<string, string?> { ["Seguranca:ChaveCriptografia"] = "chave-de-teste-do-cofre-1234567890" }).Build());

    [Fact]
    public void Cifra_e_decifra_o_mesmo_texto()
    {
        const string segredo = "APP_USR-1234567890-abcdefg";
        var cofre = Criar();
        var guardado = cofre.Cifrar(segredo);
        Assert.NotEqual(segredo, guardado);
        Assert.DoesNotContain(segredo, guardado);
        Assert.Equal(segredo, cofre.Decifrar(guardado));
    }

    [Fact]
    public void Cada_cifragem_gera_um_texto_diferente()
    {
        var cofre = Criar();
        Assert.NotEqual(cofre.Cifrar("mesmo-segredo"), cofre.Cifrar("mesmo-segredo"));
    }

    [Fact]
    public void Chave_diferente_nao_decifra()
    {
        var guardado = Criar().Cifrar("APP_USR-segredo");
        var outro = new Cofre(new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?> { ["Seguranca:ChaveCriptografia"] = "outra-chave-completamente-diferente" }).Build());
        Assert.Null(outro.Decifrar(guardado));
    }

    [Theory]
    [InlineData("APP_USR-1234567890abcdef", "APP_USR-••••••••cdef")]
    [InlineData("TEST-9876543210", "TEST-••••••••3210")]
    [InlineData("", "")]
    public void Mascara_mostra_so_o_necessario(string token, string esperado) =>
        Assert.Equal(esperado, Cofre.Mascarar(token));
}
