using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Clientes;
using LojaAmanhecer.Infrastructure.Armazenamento;
using LojaAmanhecer.Infrastructure.Dados;
using LojaAmanhecer.Infrastructure.Dados.Seed;
using LojaAmanhecer.Infrastructure.Integracoes;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace LojaAmanhecer.Infrastructure;

public static class InjecaoDependencia
{
    public static IServiceCollection AdicionarInfraestrutura(this IServiceCollection services, IConfiguration config)
    {
        services.AddDbContext<LojaDbContext>(o => o
            .UseNpgsql(config.GetConnectionString("Banco"))
            .UseSnakeCaseNamingConvention());

        services.AddIdentityCore<Usuario>(o =>
            {
                o.User.RequireUniqueEmail = true;
                o.Password.RequiredLength = 8;
                o.Password.RequireNonAlphanumeric = false;
                o.Password.RequireUppercase = false;
                // Bloqueio temporário depois de várias senhas incorretas
                o.Lockout.AllowedForNewUsers = true;
                o.Lockout.MaxFailedAccessAttempts = config.GetValue("Seguranca:TentativasAteBloquear", 5);
                o.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(config.GetValue("Seguranca:MinutosDeBloqueio", 15));
            })
            .AddRoles<IdentityRole<Guid>>()
            .AddEntityFrameworkStores<LojaDbContext>()
            .AddDefaultTokenProviders();

        services.AddScoped<SemeadorInicial>();
        // Onde ficam as fotos: disco local em desenvolvimento, S3/R2 em produção.
        // Os dois implementam o mesmo contrato, inclusive a exclusão dos arquivos.
        if ((config["Armazenamento:Provedor"] ?? "local").Equals("s3", StringComparison.OrdinalIgnoreCase))
            services.AddSingleton<IArmazenamentoArquivos, ArmazenamentoS3>();
        else
            services.AddScoped<IArmazenamentoArquivos, ArmazenamentoLocal>();
        services.AddScoped<IProcessadorImagens, LojaAmanhecer.Infrastructure.Imagens.ProcessadorImagens>();

        // ViaCEP não precisa de chave
        services.AddHttpClient<IServicoCep, ServicoCepViaCep>(c => c.Timeout = TimeSpan.FromSeconds(8));

        // Frete: Melhor Envio quando houver token; senão, cotação simulada (só desenvolvimento)
        if (!string.IsNullOrWhiteSpace(config["MelhorEnvio:Token"]))
            services.AddHttpClient<IServicoFrete, ServicoFreteMelhorEnvio>(c => c.Timeout = TimeSpan.FromSeconds(20));
        else
            services.AddScoped<IServicoFrete, ServicoFreteSimulado>();

        // Pagamento: os dois serviços ficam disponíveis; a API escolhe em tempo de execução,
        // conforme exista ou não uma conta do Mercado Pago conectada (ambiente ou painel).
        services.AddHttpClient<ServicoPagamentoMercadoPago>(c => c.Timeout = TimeSpan.FromSeconds(20));
        services.AddScoped<ServicoPagamentoSimulado>();

        // E-mail: SMTP quando configurado; senão, registra no log
        if (!string.IsNullOrWhiteSpace(config["Email:Host"]))
            services.AddScoped<IServicoEmail, ServicoEmailSmtp>();
        else
            services.AddScoped<IServicoEmail, ServicoEmailRegistro>();

        // Login com Google: valida o token do botão "Continuar com o Google" (OAuth 2.0 / Google Identity Services)
        services.AddScoped<IServicoLoginGoogle, ServicoLoginGoogle>();

        return services;
    }

    /// <summary>Avisa no log quando a loja está rodando com integrações simuladas.</summary>
    public static void AvisarIntegracoesSimuladas(IConfiguration config, ILogger log)
    {
        if (string.IsNullOrWhiteSpace(config["MelhorEnvio:Token"])) log.LogWarning("Melhor Envio sem token: o frete está sendo SIMULADO.");
        if (string.IsNullOrWhiteSpace(config["MercadoPago:AccessToken"])) log.LogWarning("Mercado Pago sem token no ambiente: se não houver conta conectada pelo painel, os pagamentos ficam SIMULADOS.");
        if (string.IsNullOrWhiteSpace(config["Email:Host"])) log.LogWarning("SMTP não configurado: os e-mails só aparecem no log.");
        if (string.IsNullOrWhiteSpace(config["Autenticacao:Google:ClientId"])) log.LogWarning("Autenticacao:Google:ClientId não configurado: o login com Google fica indisponível.");
        if (string.IsNullOrWhiteSpace(config["Seguranca:ChaveCriptografia"]))
            log.LogWarning("Seguranca:ChaveCriptografia não configurada: a credencial do Mercado Pago está sendo cifrada com uma chave " +
                "derivada de Jwt:Chave, em vez de uma chave própria. Configure Seguranca:ChaveCriptografia (32+ caracteres) antes de ir para produção.");
    }
}
