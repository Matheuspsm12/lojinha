using System.Text.Json;
using LojaAmanhecer.Domain.Catalogo;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LojaAmanhecer.Infrastructure.Dados.Configuracoes;

public class CategoriaConfig : IEntityTypeConfiguration<Categoria>
{
    public void Configure(EntityTypeBuilder<Categoria> b)
    {
        b.ToTable("categorias");
        b.Property(x => x.Nome).HasMaxLength(120).IsRequired();
        b.Property(x => x.Slug).HasMaxLength(140).IsRequired();
        b.HasIndex(x => x.Slug).IsUnique();
        b.Property(x => x.ImagemMiniaturaUrl).HasMaxLength(500);
        b.Property(x => x.ImagemOriginalUrl).HasMaxLength(500);
        b.Ignore(x => x.TemFoto);
        b.HasOne(x => x.CategoriaPai).WithMany(x => x.Subcategorias)
            .HasForeignKey(x => x.CategoriaPaiId).OnDelete(DeleteBehavior.Restrict);
    }
}

public class ProdutoConfig : IEntityTypeConfiguration<Produto>
{
    public void Configure(EntityTypeBuilder<Produto> b)
    {
        b.ToTable("produtos");
        b.Property(x => x.Nome).HasMaxLength(160).IsRequired();
        b.Property(x => x.Slug).HasMaxLength(180).IsRequired();
        b.HasIndex(x => x.Slug).IsUnique();
        b.HasIndex(x => new { x.CategoriaId, x.Ativo });
        b.Property(x => x.Preco).HasPrecision(10, 2);
        b.Property(x => x.ValorPersonalizacao).HasPrecision(10, 2);
        b.Property(x => x.AlturaCm).HasPrecision(6, 1);
        b.Property(x => x.LarguraCm).HasPrecision(6, 1);
        b.Property(x => x.ComprimentoCm).HasPrecision(6, 1);
        b.Property(x => x.RotuloPersonalizacao).HasMaxLength(80);
        b.Property(x => x.Disponibilidade).HasConversion<string>().HasMaxLength(20);
        b.HasOne(x => x.Categoria).WithMany(x => x.Produtos)
            .HasForeignKey(x => x.CategoriaId).OnDelete(DeleteBehavior.Restrict);
        b.HasMany(x => x.Imagens).WithOne().HasForeignKey(x => x.ProdutoId).OnDelete(DeleteBehavior.Cascade);
        b.HasMany(x => x.Opcoes).WithOne().HasForeignKey(x => x.ProdutoId).OnDelete(DeleteBehavior.Cascade);
        b.HasMany(x => x.Variacoes).WithOne().HasForeignKey(x => x.ProdutoId).OnDelete(DeleteBehavior.Cascade);
        b.Ignore(x => x.PossuiVariacoes);
        b.Ignore(x => x.EstoqueTotal);
    }
}

public class ProdutoImagemConfig : IEntityTypeConfiguration<ProdutoImagem>
{
    public void Configure(EntityTypeBuilder<ProdutoImagem> b)
    {
        b.ToTable("produto_imagens");
        b.Property(x => x.Url).HasMaxLength(500).IsRequired();
        b.Property(x => x.UrlOriginal).HasMaxLength(500);
        b.Property(x => x.UrlMiniatura).HasMaxLength(500);
        b.Property(x => x.UrlGrande).HasMaxLength(500);
        b.Ignore(x => x.Miniatura);
        b.Ignore(x => x.Grande);
    }
}

public class ProdutoOpcaoConfig : IEntityTypeConfiguration<ProdutoOpcao>
{
    public void Configure(EntityTypeBuilder<ProdutoOpcao> b)
    {
        b.ToTable("produto_opcoes");
        b.Property(x => x.Nome).HasMaxLength(60).IsRequired();
        // List<string> → text[] no PostgreSQL
    }
}

public class ProdutoVariacaoConfig : IEntityTypeConfiguration<ProdutoVariacao>
{
    public void Configure(EntityTypeBuilder<ProdutoVariacao> b)
    {
        b.ToTable("produto_variacoes");
        b.Property(x => x.Sku).HasMaxLength(60);
        b.Property(x => x.Preco).HasPrecision(10, 2);
        b.Ignore(x => x.Descricao);
        b.Property(x => x.Atributos)
            .HasColumnType("jsonb")
            .HasConversion(
                v => JsonSerializer.Serialize(v, (JsonSerializerOptions?)null),
                v => JsonSerializer.Deserialize<Dictionary<string, string>>(v, (JsonSerializerOptions?)null) ?? new())
            .Metadata.SetValueComparer(new ValueComparer<Dictionary<string, string>>(
                (a, c) => JsonSerializer.Serialize(a, (JsonSerializerOptions?)null) == JsonSerializer.Serialize(c, (JsonSerializerOptions?)null),
                v => JsonSerializer.Serialize(v, (JsonSerializerOptions?)null).GetHashCode(),
                v => new Dictionary<string, string>(v)));
    }
}
