using LojaAmanhecer.Domain.Clientes;
using LojaAmanhecer.Domain.Configuracoes;
using LojaAmanhecer.Domain.Pedidos;
using LojaAmanhecer.Domain.Seguranca;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LojaAmanhecer.Infrastructure.Dados.Configuracoes;

public class UsuarioConfig : IEntityTypeConfiguration<Usuario>
{
    public void Configure(EntityTypeBuilder<Usuario> b)
    {
        b.Property(x => x.NomeCompleto).HasMaxLength(160).IsRequired();
        b.Property(x => x.Cpf).HasMaxLength(14);
        b.HasMany(x => x.Enderecos).WithOne().HasForeignKey(x => x.UsuarioId).OnDelete(DeleteBehavior.Cascade);
    }
}

public class EnderecoConfig : IEntityTypeConfiguration<Endereco>
{
    public void Configure(EntityTypeBuilder<Endereco> b)
    {
        b.ToTable("enderecos");
        b.Property(x => x.Cep).HasMaxLength(9).IsRequired();
        b.Property(x => x.Uf).HasMaxLength(2).IsRequired();
        b.Property(x => x.Logradouro).HasMaxLength(200);
        b.Property(x => x.Cidade).HasMaxLength(100);
    }
}

public class PedidoConfig : IEntityTypeConfiguration<Pedido>
{
    public void Configure(EntityTypeBuilder<Pedido> b)
    {
        b.ToTable("pedidos");
        b.HasIndex(x => x.Numero).IsUnique();
        b.Property(x => x.Numero).HasDefaultValueSql("nextval('pedido_numero_seq')");
        b.HasIndex(x => new { x.Status, x.CriadoEm });
        b.HasIndex(x => x.ClienteId);
        b.HasIndex(x => x.VendedorId);
        b.Property(x => x.Status).HasConversion<string>().HasMaxLength(30);
        b.Property(x => x.Subtotal).HasPrecision(10, 2);
        b.Property(x => x.ValorFrete).HasPrecision(10, 2);
        b.Property(x => x.Desconto).HasPrecision(10, 2);
        b.Property(x => x.FormaEntrega).HasMaxLength(80);
        b.Property(x => x.CodigoRastreio).HasMaxLength(60);
        b.Ignore(x => x.Total);
        b.Ignore(x => x.PrazoTotalDias);
        b.Ignore(x => x.NumeroFormatado);
        b.OwnsOne(x => x.EnderecoEntrega, e =>
        {
            e.Property(p => p.Cep).HasColumnName("entrega_cep").HasMaxLength(9);
            e.Property(p => p.Destinatario).HasColumnName("entrega_destinatario").HasMaxLength(160);
            e.Property(p => p.Logradouro).HasColumnName("entrega_logradouro").HasMaxLength(200);
            e.Property(p => p.Numero).HasColumnName("entrega_numero").HasMaxLength(20);
            e.Property(p => p.Complemento).HasColumnName("entrega_complemento").HasMaxLength(100);
            e.Property(p => p.Bairro).HasColumnName("entrega_bairro").HasMaxLength(100);
            e.Property(p => p.Cidade).HasColumnName("entrega_cidade").HasMaxLength(100);
            e.Property(p => p.Uf).HasColumnName("entrega_uf").HasMaxLength(2);
        });
        b.HasOne<Usuario>().WithMany().HasForeignKey(x => x.ClienteId).OnDelete(DeleteBehavior.Restrict);
        b.HasOne<Usuario>().WithMany().HasForeignKey(x => x.VendedorId).OnDelete(DeleteBehavior.SetNull);
        b.HasMany(x => x.Itens).WithOne().HasForeignKey(x => x.PedidoId).OnDelete(DeleteBehavior.Cascade);
        b.HasMany(x => x.Pagamentos).WithOne().HasForeignKey(x => x.PedidoId).OnDelete(DeleteBehavior.Cascade);
        b.HasMany(x => x.Historico).WithOne().HasForeignKey(x => x.PedidoId).OnDelete(DeleteBehavior.Cascade);
    }
}

public class PedidoItemConfig : IEntityTypeConfiguration<PedidoItem>
{
    public void Configure(EntityTypeBuilder<PedidoItem> b)
    {
        b.ToTable("pedido_itens");
        b.Property(x => x.NomeProduto).HasMaxLength(160);
        b.Property(x => x.Personalizacao).HasMaxLength(120);
        b.Property(x => x.PrecoUnitario).HasPrecision(10, 2);
        b.Ignore(x => x.Total);
    }
}

public class PagamentoConfig : IEntityTypeConfiguration<Pagamento>
{
    public void Configure(EntityTypeBuilder<Pagamento> b)
    {
        b.ToTable("pagamentos");
        b.Property(x => x.Metodo).HasConversion<string>().HasMaxLength(20);
        b.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
        b.Property(x => x.Valor).HasPrecision(10, 2);
        b.Property(x => x.GatewayId).HasMaxLength(80);
        b.Property(x => x.TaxaGateway).HasPrecision(10, 2);
        b.Property(x => x.ValorLiquido).HasPrecision(10, 2);
        b.Property(x => x.ValorEstornado).HasPrecision(10, 2);
        b.Property(x => x.Ambiente).HasMaxLength(20);
        b.HasIndex(x => x.GatewayId);
    }
}

public class PedidoHistoricoConfig : IEntityTypeConfiguration<PedidoHistorico>
{
    public void Configure(EntityTypeBuilder<PedidoHistorico> b)
    {
        b.ToTable("pedido_historico");
        b.Property(x => x.StatusAnterior).HasConversion<string>().HasMaxLength(30);
        b.Property(x => x.StatusNovo).HasConversion<string>().HasMaxLength(30);
    }
}

public class ConfiguracaoLojaConfig : IEntityTypeConfiguration<ConfiguracaoLoja>
{
    public void Configure(EntityTypeBuilder<ConfiguracaoLoja> b)
    {
        b.ToTable("configuracoes");
        b.HasKey(x => x.Chave);
        b.Property(x => x.Chave).HasMaxLength(80);
    }
}

public class RegistroAcessoConfig : IEntityTypeConfiguration<RegistroAcesso>
{
    public void Configure(EntityTypeBuilder<RegistroAcesso> b)
    {
        b.ToTable("registros_acesso");
        b.Property(x => x.Email).HasMaxLength(160).IsRequired();
        b.Property(x => x.Origem).HasMaxLength(20);
        b.Property(x => x.Motivo).HasMaxLength(40);
        b.Property(x => x.Ip).HasMaxLength(60);
        b.Property(x => x.Navegador).HasMaxLength(300);
        b.HasIndex(x => x.CriadoEm);
        b.HasIndex(x => new { x.Email, x.CriadoEm });
    }
}
