using LojaAmanhecer.Domain.Catalogo;
using LojaAmanhecer.Domain.Clientes;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Configuracoes;
using LojaAmanhecer.Domain.Enums;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LojaAmanhecer.Infrastructure.Dados.Seed;

/// <summary>
/// Cria perfis, administrador inicial, categorias iniciais aprovadas e configurações.
/// É idempotente: só insere o que ainda não existe.
/// </summary>
public class SemeadorInicial(
    LojaDbContext db,
    UserManager<Usuario> usuarios,
    RoleManager<IdentityRole<Guid>> perfis,
    IConfiguration config,
    ILogger<SemeadorInicial> log)
{
    public async Task ExecutarAsync()
    {
        foreach (var perfil in new[] { Perfis.Administrador, Perfis.Vendedor, Perfis.Cliente })
            if (!await perfis.RoleExistsAsync(perfil))
                await perfis.CreateAsync(new IdentityRole<Guid>(perfil));

        await CriarAdministradorAsync();
        await CriarCategoriasAsync();
        await CriarConfiguracoesAsync();
        await db.SaveChangesAsync();
    }

    /// <summary>
    /// Primeiro administrador. Há dois caminhos, e nenhum deles deixa senha padrão no ar:
    /// 1. AdminInicial:Email + AdminInicial:Senha configurados (usado em desenvolvimento) — a conta é criada
    ///    já marcada para trocar a senha no primeiro acesso;
    /// 2. sem essa configuração, é gerado um token de instalação de uso único, gravado no log e no arquivo
    ///    primeiro-acesso.txt, que permite criar a conta pela tela de instalação do painel.
    /// Os dois caminhos só valem enquanto não existir nenhum administrador.
    /// </summary>
    private async Task CriarAdministradorAsync()
    {
        if ((await usuarios.GetUsersInRoleAsync(Perfis.Administrador)).Any()) return;

        var email = config["AdminInicial:Email"];
        var senha = config["AdminInicial:Senha"];

        if (!string.IsNullOrWhiteSpace(email) && !string.IsNullOrWhiteSpace(senha))
        {
            if (await usuarios.FindByEmailAsync(email) is null)
            {
                var admin = new Usuario
                {
                    UserName = email, Email = email, EmailConfirmed = true,
                    NomeCompleto = config["AdminInicial:Nome"] ?? "Administrador",
                    DeveTrocarSenha = true
                };
                var r = await usuarios.CreateAsync(admin, senha);
                if (!r.Succeeded)
                {
                    log.LogWarning("Não foi possível criar o administrador inicial: {Erros}", string.Join("; ", r.Errors.Select(e => e.Description)));
                    return;
                }
                await usuarios.AddToRoleAsync(admin, Perfis.Administrador);
                log.LogInformation("Administrador inicial criado: {Email}. A senha precisa ser trocada no primeiro acesso.", email);
            }
            return;
        }

        await GerarTokenDeInstalacaoAsync();
    }

    public const string ChaveTokenInstalacao = "instalacao.token";

    private async Task GerarTokenDeInstalacaoAsync()
    {
        var existente = await db.Configuracoes.FindAsync(ChaveTokenInstalacao);
        if (existente is not null && !string.IsNullOrWhiteSpace(existente.Valor)) return;

        var token = Convert.ToHexString(System.Security.Cryptography.RandomNumberGenerator.GetBytes(24));
        var guardado = new ConfiguracaoLoja
        {
            Chave = ChaveTokenInstalacao,
            Valor = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(token))),
            Descricao = "Token de uso único para criar o primeiro administrador"
        };
        if (existente is null) db.Configuracoes.Add(guardado); else existente.Valor = guardado.Valor;

        try
        {
            var caminho = Path.Combine(AppContext.BaseDirectory, "primeiro-acesso.txt");
            await File.WriteAllTextAsync(caminho,
                $"Token de instalação do painel (uso único, gerado em {DateTime.Now:g}):\n{token}\n\n" +
                "Abra /painel no navegador e use este token para criar a conta administradora.\n" +
                "Apague este arquivo depois de criar a conta.\n");
            log.LogWarning("Nenhum administrador cadastrado. Token de instalação gravado em {Caminho}", caminho);
        }
        catch (Exception ex) { log.LogWarning(ex, "Não foi possível gravar o arquivo primeiro-acesso.txt"); }

        log.LogWarning("Token de instalação do painel (uso único): {Token}", token);
    }

    /// <summary>Estrutura de categorias aprovada para o MVP.</summary>
    private static readonly (string Nome, string[] Subs)[] CategoriasIniciais =
    [
        ("Broches de povos", ["Princesas", "Pretos-velhos", "Demais povos"]),
        ("Radares", ["Radar de Doutrinador", "Radar de Apará"]),
        ("Coletes", ["Colete de Doutrinador", "Colete de Apará"]),
        ("Fitas", ["Fita de Doutrinador", "Fita de Apará"]),
        ("Fotografias, imagens e quadros", []),
        ("Outros artigos", [])
    ];

    private async Task CriarCategoriasAsync()
    {
        if (await db.Categorias.AnyAsync()) return;
        var ordem = 1;
        foreach (var (nome, subs) in CategoriasIniciais)
        {
            var pai = new Categoria { Nome = nome, Slug = Slug.Gerar(nome), Ordem = ordem++ };
            var o = 1;
            foreach (var s in subs)
                pai.Subcategorias.Add(new Categoria { Nome = s, Slug = Slug.Gerar($"{nome}-{s}"), Ordem = o++ });
            db.Categorias.Add(pai);
        }
    }

    private async Task CriarConfiguracoesAsync()
    {
        var padrao = new Dictionary<string, (string Valor, string Descricao)>
        {
            ["loja.nome"] = ("Lojinha Do Vale", "Nome exibido na loja"),
            ["loja.whatsapp"] = ("556192032613", "WhatsApp com DDI e DDD, só números"),
            ["loja.email"] = ("contato@exemplo.com.br", "E-mail de contato"),
            ["loja.instagram"] = ("https://www.instagram.com/lojinha_dovale/", "Link do Instagram (vazio esconde o botão)"),
            ["frete.cep_origem"] = ("73000000", "CEP de onde saem os envios"),
            ["frete.retirada_habilitada"] = ("true", "Permite retirada no local"),
            ["frete.retirada_endereco"] = ("A definir", "Endereço/instruções de retirada"),
            ["estoque.alerta_minimo"] = ("3", "Alerta de estoque baixo no painel"),
            ["pagamento.metodo.pix"] = ("true", "Pix ativo na loja"),
            ["pagamento.metodo.cartao"] = ("true", "Cartão de crédito ativo na loja"),
            ["pagamento.metodo.boleto"] = ("true", "Boleto ativo na loja"),
            ["pagamento.parcelas.maximo"] = ("3", "Máximo de parcelas no cartão"),
            ["pagamento.parcelas.com_juros"] = ("false", "Parcelamento com juros do comprador"),
            ["pagamento.parcelas.valor_minimo"] = ("30", "Valor mínimo de cada parcela"),
            ["pagamento.mp.ambiente"] = ("teste", "Ambiente do Mercado Pago: teste ou producao"),
            ["pagamento.taxa.pix"] = ("0.99", "Taxa estimada do Pix (%)"),
            ["pagamento.taxa.cartao"] = ("4.98", "Taxa estimada do cartão (%)"),
            ["pagamento.taxa.boleto"] = ("3.49", "Taxa estimada do boleto (%)")
        };
        var existentes = await db.Configuracoes.Select(c => c.Chave).ToListAsync();
        foreach (var (chave, (valor, desc)) in padrao.Where(p => !existentes.Contains(p.Key)))
            db.Configuracoes.Add(new ConfiguracaoLoja { Chave = chave, Valor = valor, Descricao = desc });
    }
}
