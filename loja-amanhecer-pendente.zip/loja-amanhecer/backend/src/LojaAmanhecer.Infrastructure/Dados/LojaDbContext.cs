using LojaAmanhecer.Domain.Catalogo;
using LojaAmanhecer.Domain.Clientes;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Configuracoes;
using LojaAmanhecer.Domain.Pedidos;
using LojaAmanhecer.Domain.Seguranca;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Infrastructure.Dados;

public class LojaDbContext(DbContextOptions<LojaDbContext> options)
    : IdentityDbContext<Usuario, IdentityRole<Guid>, Guid>(options)
{
    public DbSet<Categoria> Categorias => Set<Categoria>();
    public DbSet<Produto> Produtos => Set<Produto>();
    public DbSet<ProdutoImagem> ProdutoImagens => Set<ProdutoImagem>();
    public DbSet<ProdutoOpcao> ProdutoOpcoes => Set<ProdutoOpcao>();
    public DbSet<ProdutoVariacao> ProdutoVariacoes => Set<ProdutoVariacao>();
    public DbSet<Endereco> Enderecos => Set<Endereco>();
    public DbSet<Pedido> Pedidos => Set<Pedido>();
    public DbSet<PedidoItem> PedidoItens => Set<PedidoItem>();
    public DbSet<Pagamento> Pagamentos => Set<Pagamento>();
    public DbSet<PedidoHistorico> PedidoHistoricos => Set<PedidoHistorico>();
    public DbSet<ConfiguracaoLoja> Configuracoes => Set<ConfiguracaoLoja>();
    public DbSet<RegistroAcesso> RegistrosAcesso => Set<RegistroAcesso>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        // Tabelas do Identity com nomes em português
        builder.Entity<Usuario>().ToTable("usuarios");
        builder.Entity<IdentityRole<Guid>>().ToTable("perfis");
        builder.Entity<IdentityUserRole<Guid>>().ToTable("usuarios_perfis");
        builder.Entity<IdentityUserClaim<Guid>>().ToTable("usuarios_claims");
        builder.Entity<IdentityUserLogin<Guid>>().ToTable("usuarios_logins");
        builder.Entity<IdentityUserToken<Guid>>().ToTable("usuarios_tokens");
        builder.Entity<IdentityRoleClaim<Guid>>().ToTable("perfis_claims");

        builder.HasPostgresExtension("unaccent"); // busca sem acento

        // Número sequencial dos pedidos (VA-000001, VA-000002...)
        builder.HasSequence<long>("pedido_numero_seq").StartsAt(1).IncrementsBy(1);

        builder.ApplyConfigurationsFromAssembly(typeof(LojaDbContext).Assembly);
    }

    public override Task<int> SaveChangesAsync(CancellationToken ct = default)
    {
        foreach (var e in ChangeTracker.Entries<Entidade>().Where(e => e.State == EntityState.Modified))
            e.Entity.AtualizadoEm = DateTime.UtcNow;
        return base.SaveChangesAsync(ct);
    }
}
