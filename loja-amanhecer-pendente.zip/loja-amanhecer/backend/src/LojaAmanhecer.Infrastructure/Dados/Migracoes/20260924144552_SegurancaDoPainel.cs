﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LojaAmanhecer.Infrastructure.Dados.Migracoes
{
    /// <inheritdoc />
    public partial class SegurancaDoPainel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "deve_trocar_senha",
                table: "usuarios",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateTable(
                name: "registros_acesso",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    email = table.Column<string>(type: "character varying(160)", maxLength: 160, nullable: false),
                    usuario_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sucesso = table.Column<bool>(type: "boolean", nullable: false),
                    origem = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false),
                    motivo = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false),
                    ip = table.Column<string>(type: "character varying(60)", maxLength: 60, nullable: true),
                    navegador = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    criado_em = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    atualizado_em = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_registros_acesso", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "ix_registros_acesso_criado_em",
                table: "registros_acesso",
                column: "criado_em");

            migrationBuilder.CreateIndex(
                name: "ix_registros_acesso_email_criado_em",
                table: "registros_acesso",
                columns: new[] { "email", "criado_em" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "registros_acesso");

            migrationBuilder.DropColumn(
                name: "deve_trocar_senha",
                table: "usuarios");
        }
    }
}
