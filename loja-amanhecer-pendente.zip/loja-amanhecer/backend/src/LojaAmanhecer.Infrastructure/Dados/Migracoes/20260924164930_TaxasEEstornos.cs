﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LojaAmanhecer.Infrastructure.Dados.Migracoes
{
    /// <inheritdoc />
    public partial class TaxasEEstornos : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ambiente",
                table: "pagamentos",
                type: "character varying(20)",
                maxLength: 20,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "taxa_gateway",
                table: "pagamentos",
                type: "numeric(10,2)",
                precision: 10,
                scale: 2,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "valor_estornado",
                table: "pagamentos",
                type: "numeric(10,2)",
                precision: 10,
                scale: 2,
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "valor_liquido",
                table: "pagamentos",
                type: "numeric(10,2)",
                precision: 10,
                scale: 2,
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ambiente",
                table: "pagamentos");

            migrationBuilder.DropColumn(
                name: "taxa_gateway",
                table: "pagamentos");

            migrationBuilder.DropColumn(
                name: "valor_estornado",
                table: "pagamentos");

            migrationBuilder.DropColumn(
                name: "valor_liquido",
                table: "pagamentos");
        }
    }
}
