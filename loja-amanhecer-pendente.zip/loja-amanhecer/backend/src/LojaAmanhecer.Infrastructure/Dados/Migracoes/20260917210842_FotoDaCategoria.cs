﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LojaAmanhecer.Infrastructure.Dados.Migracoes
{
    /// <inheritdoc />
    public partial class FotoDaCategoria : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "imagem_miniatura_url",
                table: "categorias",
                type: "character varying(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "imagem_original_url",
                table: "categorias",
                type: "character varying(500)",
                maxLength: 500,
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "imagem_miniatura_url",
                table: "categorias");

            migrationBuilder.DropColumn(
                name: "imagem_original_url",
                table: "categorias");
        }
    }
}
