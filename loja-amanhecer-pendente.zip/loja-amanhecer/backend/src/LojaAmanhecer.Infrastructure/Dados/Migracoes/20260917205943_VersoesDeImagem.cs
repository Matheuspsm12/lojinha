﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LojaAmanhecer.Infrastructure.Dados.Migracoes
{
    /// <inheritdoc />
    public partial class VersoesDeImagem : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "altura",
                table: "produto_imagens",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "largura",
                table: "produto_imagens",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "url_grande",
                table: "produto_imagens",
                type: "character varying(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "url_miniatura",
                table: "produto_imagens",
                type: "character varying(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "url_original",
                table: "produto_imagens",
                type: "character varying(500)",
                maxLength: 500,
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "altura",
                table: "produto_imagens");

            migrationBuilder.DropColumn(
                name: "largura",
                table: "produto_imagens");

            migrationBuilder.DropColumn(
                name: "url_grande",
                table: "produto_imagens");

            migrationBuilder.DropColumn(
                name: "url_miniatura",
                table: "produto_imagens");

            migrationBuilder.DropColumn(
                name: "url_original",
                table: "produto_imagens");
        }
    }
}
