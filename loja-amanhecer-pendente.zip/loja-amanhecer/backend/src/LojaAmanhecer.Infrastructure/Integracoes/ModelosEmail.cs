using System.Globalization;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Domain.Pedidos;

namespace LojaAmanhecer.Infrastructure.Integracoes;

/// <summary>Textos e HTML dos e-mails do pedido.</summary>
public static class ModelosEmail
{
    private static readonly CultureInfo Br = new("pt-BR");
    public static string Reais(decimal v) => v.ToString("C", Br);

    public static string Texto(StatusPedido s) => s switch
    {
        StatusPedido.PedidoRecebido => "Pedido recebido",
        StatusPedido.AguardandoPagamento => "Aguardando pagamento",
        StatusPedido.PagamentoConfirmado => "Pagamento confirmado",
        StatusPedido.EmProducao => "Em produção",
        StatusPedido.ProntoParaEnvio => "Pronto para envio",
        StatusPedido.Enviado => "Enviado",
        StatusPedido.Entregue => "Entregue",
        _ => "Cancelado"
    };

    private static string Moldura(string lojaNome, string conteudo) => $@"
<div style=""font-family:Arial,Helvetica,sans-serif;background:#F4F0FC;padding:24px"">
  <div style=""max-width:560px;margin:auto;background:#fff;border-radius:14px;overflow:hidden"">
    <div style=""background:#3E2A6E;color:#E2C46B;padding:18px 24px;font-size:20px"">{lojaNome}</div>
    <div style=""padding:24px;color:#2B2140;line-height:1.5"">{conteudo}</div>
    <div style=""padding:16px 24px;background:#F4F0FC;color:#6A5F80;font-size:12px"">Você recebeu este e-mail porque fez um pedido na {lojaNome}.</div>
  </div>
</div>";

    public static string Confirmacao(Pedido p, string lojaNome, string? whatsapp)
    {
        var itens = string.Join("", p.Itens.Select(i => $@"
      <tr><td style=""padding:6px 0"">{i.Quantidade}× {i.NomeProduto}{(string.IsNullOrEmpty(i.DescricaoVariacao) ? "" : $"<br><small style='color:#6A5F80'>{i.DescricaoVariacao}</small>")}{(string.IsNullOrEmpty(i.Personalizacao) ? "" : $"<br><small style='color:#6A5F80'>Personalização: {i.Personalizacao}</small>")}</td>
      <td align=""right"">{Reais(i.Total)}</td></tr>"));

        return Moldura(lojaNome, $@"
    <h2 style=""color:#3E2A6E;margin:0 0 6px"">Recebemos o seu pedido</h2>
    <p>Sua ordem de compra é a <strong style=""font-size:18px"">{p.NumeroFormatado}</strong>.</p>
    <table width=""100%"" style=""border-collapse:collapse;font-size:14px"">{itens}
      <tr><td style=""padding-top:10px"">Frete ({p.FormaEntrega})</td><td align=""right"" style=""padding-top:10px"">{Reais(p.ValorFrete)}</td></tr>
      <tr><td style=""border-top:1px solid #E6DFF3;padding-top:8px""><strong>Total</strong></td><td align=""right"" style=""border-top:1px solid #E6DFF3;padding-top:8px""><strong>{Reais(p.Total)}</strong></td></tr>
    </table>
    <p style=""background:#E8F6FC;padding:12px;border-radius:8px"">Prazo previsto: <strong>{p.PrazoProducaoDias} dia(s) úteis de produção + {p.PrazoTransporteDias} dia(s) úteis de transporte</strong>, contados a partir da confirmação do pagamento.</p>
    <p>Entrega em: {p.EnderecoEntrega.Logradouro}, {p.EnderecoEntrega.Numero} — {p.EnderecoEntrega.Bairro}, {p.EnderecoEntrega.Cidade}/{p.EnderecoEntrega.Uf}</p>
    {(string.IsNullOrWhiteSpace(whatsapp) ? "" : $@"<p><a href=""https://wa.me/{whatsapp}?text=Ol%C3%A1!%20Sobre%20o%20pedido%20{p.NumeroFormatado}"" style=""background:#1f8f53;color:#fff;padding:10px 18px;border-radius:99px;text-decoration:none;display:inline-block"">Falar no WhatsApp</a></p>")}");
    }

    public static string MudancaStatus(Pedido p, string lojaNome, string? whatsapp)
    {
        var extra = p.Status switch
        {
            StatusPedido.PagamentoConfirmado => "<p>Seu pagamento foi confirmado e o pedido entrou na fila de produção.</p>",
            StatusPedido.EmProducao => $"<p>Seu pedido está sendo produzido. Prazo de produção: {p.PrazoProducaoDias} dia(s) úteis.</p>",
            StatusPedido.ProntoParaEnvio => "<p>Seu pedido está pronto e será despachado em breve.</p>",
            StatusPedido.Enviado => string.IsNullOrWhiteSpace(p.CodigoRastreio)
                ? "<p>Seu pedido foi despachado.</p>"
                : $@"<p>Seu pedido foi despachado. Código de rastreamento: <strong>{p.CodigoRastreio}</strong>.</p>",
            StatusPedido.Entregue => "<p>Seu pedido foi entregue. Obrigado pela confiança.</p>",
            StatusPedido.Cancelado => "<p>Seu pedido foi cancelado. Se tiver dúvidas, fale com a gente.</p>",
            _ => ""
        };
        return Moldura(lojaNome, $@"
    <h2 style=""color:#3E2A6E;margin:0 0 6px"">{Texto(p.Status)}</h2>
    <p>Pedido <strong>{p.NumeroFormatado}</strong>.</p>{extra}
    {(string.IsNullOrWhiteSpace(whatsapp) ? "" : $@"<p><a href=""https://wa.me/{whatsapp}?text=Ol%C3%A1!%20Sobre%20o%20pedido%20{p.NumeroFormatado}"" style=""color:#3E2A6E"">Falar no WhatsApp</a></p>")}");
    }

    public static string NovoPedidoParaEquipe(Pedido p, string cliente, string lojaNome, string urlPainel) => Moldura(lojaNome, $@"
    <h2 style=""color:#3E2A6E;margin:0 0 6px"">Novo pedido: {p.NumeroFormatado}</h2>
    <p>Cliente: <strong>{cliente}</strong><br>Total: <strong>{Reais(p.Total)}</strong><br>Entrega: {p.FormaEntrega}</p>
    <p><a href=""{urlPainel}"" style=""background:#3E2A6E;color:#fff;padding:10px 18px;border-radius:99px;text-decoration:none;display:inline-block"">Abrir no painel</a></p>");
}
