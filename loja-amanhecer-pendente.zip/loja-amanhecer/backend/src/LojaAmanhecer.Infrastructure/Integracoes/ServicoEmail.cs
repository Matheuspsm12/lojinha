using System.Net;
using System.Net.Mail;
using LojaAmanhecer.Application.Integracoes;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LojaAmanhecer.Infrastructure.Integracoes;

/// <summary>Envio por SMTP (Brevo, Resend, SES, Zoho…). Sem Email:Host, usa o ServicoEmailRegistro.</summary>
public class ServicoEmailSmtp(IConfiguration config, ILogger<ServicoEmailSmtp> log) : IServicoEmail
{
    public async Task EnviarAsync(string para, string assunto, string html, CancellationToken ct = default)
    {
        try
        {
            using var cliente = new SmtpClient(config["Email:Host"], config.GetValue("Email:Porta", 587))
            {
                EnableSsl = config.GetValue("Email:Ssl", true),
                Credentials = new NetworkCredential(config["Email:Usuario"], config["Email:Senha"])
            };
            using var msg = new MailMessage
            {
                From = new MailAddress(config["Email:RemetenteEndereco"] ?? config["Email:Usuario"]!, config["Email:RemetenteNome"] ?? "Lojinha Do Vale"),
                Subject = assunto, Body = html, IsBodyHtml = true
            };
            msg.To.Add(para);
            await cliente.SendMailAsync(msg, ct);
            log.LogInformation("E-mail enviado para {Para}: {Assunto}", para, assunto);
        }
        catch (Exception ex)
        {
            // Nunca derruba o pedido por causa do e-mail
            log.LogError(ex, "Falha ao enviar e-mail para {Para}", para);
        }
    }
}

/// <summary>Registra o e-mail no log em vez de enviar (desenvolvimento).</summary>
public class ServicoEmailRegistro(ILogger<ServicoEmailRegistro> log) : IServicoEmail
{
    public Task EnviarAsync(string para, string assunto, string html, CancellationToken ct = default)
    {
        log.LogInformation("[E-mail simulado] Para: {Para} | Assunto: {Assunto}", para, assunto);
        return Task.CompletedTask;
    }
}
