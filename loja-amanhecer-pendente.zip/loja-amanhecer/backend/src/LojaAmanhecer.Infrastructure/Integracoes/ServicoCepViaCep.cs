using System.Text.Json;
using LojaAmanhecer.Application.Integracoes;
using Microsoft.Extensions.Logging;

namespace LojaAmanhecer.Infrastructure.Integracoes;

/// <summary>Consulta de CEP no ViaCEP (gratuito, sem chave).</summary>
public class ServicoCepViaCep(HttpClient http, ILogger<ServicoCepViaCep> log) : IServicoCep
{
    public async Task<EnderecoCep?> ConsultarAsync(string cep, CancellationToken ct = default)
    {
        var limpo = new string(cep.Where(char.IsDigit).ToArray());
        if (limpo.Length != 8) return null;
        try
        {
            using var resposta = await http.GetAsync($"https://viacep.com.br/ws/{limpo}/json/", ct);
            if (!resposta.IsSuccessStatusCode) return null;
            using var doc = JsonDocument.Parse(await resposta.Content.ReadAsStringAsync(ct));
            var r = doc.RootElement;
            if (r.TryGetProperty("erro", out _)) return null;
            string T(string p) => r.TryGetProperty(p, out var v) ? v.GetString() ?? "" : "";
            return new EnderecoCep($"{limpo[..5]}-{limpo[5..]}", T("logradouro"), T("bairro"), T("localidade"), T("uf"));
        }
        catch (Exception ex)
        {
            log.LogWarning(ex, "Falha ao consultar o CEP {Cep} no ViaCEP", limpo);
            return null;
        }
    }
}
