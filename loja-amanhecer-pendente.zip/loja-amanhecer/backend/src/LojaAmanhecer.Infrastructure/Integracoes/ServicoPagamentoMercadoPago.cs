using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Domain.Pedidos;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LojaAmanhecer.Infrastructure.Integracoes;

/// <summary>
/// Mercado Pago: Pix e boleto pela API de pagamentos; cartão pelo Checkout Pro (o cliente
/// digita o cartão no ambiente do Mercado Pago, a loja nunca recebe o número).
/// Precisa de MercadoPago:AccessToken. Sem token, é usado o ServicoPagamentoSimulado.
/// </summary>
public class ServicoPagamentoMercadoPago(
    HttpClient http, IConfiguration config, IFonteCredencialPagamento credenciais, ILogger<ServicoPagamentoMercadoPago> log) : IServicoPagamento
{
    public bool Real => true;
    private bool _sandbox;

    private async Task PrepararAsync(CancellationToken ct = default)
    {
        var (token, sandbox) = await credenciais.ObterAsync(ct);
        if (string.IsNullOrWhiteSpace(token))
            throw new RegraNegocioException("Nenhuma conta do Mercado Pago conectada. Conecte em Pagamentos e recebimentos.");
        _sandbox = sandbox;
        http.BaseAddress ??= new Uri("https://api.mercadopago.com/");
        http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }

    private string UrlApi => (config["Urls:Api"] ?? "http://localhost:5080").TrimEnd('/');
    private string UrlLoja => (config["Urls:Loja"] ?? "http://localhost:3000").TrimEnd('/');

    public async Task<CobrancaCriada> CriarCobrancaAsync(Pedido pedido, string emailPagador, string nomePagador, MetodoPagamento metodo, CancellationToken ct = default)
    {
        await PrepararAsync(ct);
        var total = Math.Round(pedido.Total, 2);
        var descricao = $"Pedido {pedido.NumeroFormatado}";

        if (metodo == MetodoPagamento.CartaoCredito)
        {
            var preferencia = new
            {
                items = new[] { new { title = descricao, quantity = 1, unit_price = total, currency_id = "BRL" } },
                payer = new { name = nomePagador, email = emailPagador },
                external_reference = pedido.Id.ToString(),
                notification_url = $"{UrlApi}/api/pagamentos/webhook",
                back_urls = new { success = $"{UrlLoja}/pedido/{pedido.Numero}", pending = $"{UrlLoja}/pedido/{pedido.Numero}", failure = $"{UrlLoja}/pedido/{pedido.Numero}" },
                payment_methods = new { excluded_payment_types = new[] { new { id = "ticket" }, new { id = "bank_transfer" } } }
            };
            using var r = await http.PostAsJsonAsync("checkout/preferences", preferencia, ct);
            var t = await r.Content.ReadAsStringAsync(ct);
            if (!r.IsSuccessStatusCode) { log.LogError("Mercado Pago (preferência): {Corpo}", t); throw new RegraNegocioException("Não foi possível iniciar o pagamento com cartão."); }
            var p = JsonDocument.Parse(t).RootElement;
            var link = p.GetProperty(_sandbox ? "sandbox_init_point" : "init_point").GetString();
            return new CobrancaCriada(p.GetProperty("id").GetString()!, "pending", LinkCheckout: link);
        }

        var pagamento = new
        {
            transaction_amount = total,
            description = descricao,
            payment_method_id = metodo == MetodoPagamento.Pix ? "pix" : "bolbradesco",
            external_reference = pedido.Id.ToString(),
            notification_url = $"{UrlApi}/api/pagamentos/webhook",
            date_of_expiration = DateTime.UtcNow.AddDays(metodo == MetodoPagamento.Pix ? 1 : 3).ToString("yyyy-MM-ddTHH:mm:ss.fffzzz"),
            payer = new
            {
                email = emailPagador,
                first_name = nomePagador.Split(' ')[0],
                last_name = nomePagador.Contains(' ') ? nomePagador[(nomePagador.IndexOf(' ') + 1)..] : "",
                address = new
                {
                    zip_code = new string(pedido.EnderecoEntrega.Cep.Where(char.IsDigit).ToArray()),
                    street_name = pedido.EnderecoEntrega.Logradouro, street_number = pedido.EnderecoEntrega.Numero,
                    neighborhood = pedido.EnderecoEntrega.Bairro, city = pedido.EnderecoEntrega.Cidade, federal_unit = pedido.EnderecoEntrega.Uf
                }
            }
        };

        var requisicao = new HttpRequestMessage(HttpMethod.Post, "v1/payments") { Content = JsonContent.Create(pagamento) };
        requisicao.Headers.Add("X-Idempotency-Key", pedido.Id.ToString());
        using var resposta = await http.SendAsync(requisicao, ct);
        var texto = await resposta.Content.ReadAsStringAsync(ct);
        if (!resposta.IsSuccessStatusCode)
        {
            log.LogError("Mercado Pago (pagamento): {Corpo}", texto);
            throw new RegraNegocioException("Não foi possível gerar a cobrança. Tente outra forma de pagamento.");
        }
        var raiz = JsonDocument.Parse(texto).RootElement;
        var transacao = raiz.GetProperty("point_of_interaction").TryGetProperty("transaction_data", out var td) ? td : default;
        return new CobrancaCriada(
            raiz.GetProperty("id").GetRawText().Trim('"'),
            raiz.GetProperty("status").GetString() ?? "pending",
            QrCodePix: transacao.ValueKind == JsonValueKind.Object && transacao.TryGetProperty("qr_code", out var qr) ? qr.GetString() : null,
            QrCodeBase64: transacao.ValueKind == JsonValueKind.Object && transacao.TryGetProperty("qr_code_base64", out var qb) ? qb.GetString() : null,
            LinkBoleto: raiz.TryGetProperty("transaction_details", out var det) && det.TryGetProperty("external_resource_url", out var url) ? url.GetString() : null,
            CodigoCopiaECola: transacao.ValueKind == JsonValueKind.Object && transacao.TryGetProperty("qr_code", out var cc) ? cc.GetString() : null);
    }

    public async Task<AvisoPagamento?> LerAvisoAsync(string corpo, IDictionary<string, string> cabecalhos, CancellationToken ct = default)
    {
        await PrepararAsync(ct);
        using var doc = JsonDocument.Parse(corpo);
        var raiz = doc.RootElement;
        var tipo = raiz.TryGetProperty("type", out var t) ? t.GetString() : raiz.TryGetProperty("topic", out var tp) ? tp.GetString() : null;
        if (tipo is not ("payment" or "merchant_order")) return null;

        var id = raiz.TryGetProperty("data", out var d) && d.TryGetProperty("id", out var di) ? di.GetRawText().Trim('"')
               : raiz.TryGetProperty("id", out var i) ? i.GetRawText().Trim('"') : null;
        if (id is null) return null;

        // Confirma a situação direto na API (o corpo do aviso não é fonte confiável)
        using var r = await http.GetAsync($"v1/payments/{id}", ct);
        if (!r.IsSuccessStatusCode) { log.LogWarning("Aviso do Mercado Pago sem pagamento correspondente: {Id}", id); return null; }
        var p = JsonDocument.Parse(await r.Content.ReadAsStringAsync(ct)).RootElement;
        var status = p.GetProperty("status").GetString() ?? "";
        return new AvisoPagamento(id, Converter(status), status);
    }

    public async Task<DetalhePagamentoGateway?> ConsultarAsync(string gatewayId, CancellationToken ct = default)
    {
        await PrepararAsync(ct);
        using var r = await http.GetAsync($"v1/payments/{gatewayId}", ct);
        if (!r.IsSuccessStatusCode) return null;
        var p = JsonDocument.Parse(await r.Content.ReadAsStringAsync(ct)).RootElement;
        var status = p.GetProperty("status").GetString() ?? "";

        decimal? taxa = null;
        if (p.TryGetProperty("fee_details", out var taxas) && taxas.ValueKind == JsonValueKind.Array)
            taxa = taxas.EnumerateArray().Sum(t => t.TryGetProperty("amount", out var a) ? a.GetDecimal() : 0m);
        var liquido = p.TryGetProperty("transaction_details", out var td) && td.TryGetProperty("net_received_amount", out var n)
            ? n.GetDecimal() : (decimal?)null;
        var estornado = p.TryGetProperty("transaction_amount_refunded", out var e) ? e.GetDecimal() : 0m;

        return new DetalhePagamentoGateway(gatewayId, Converter(status), status, taxa, liquido, estornado);
    }

    public async Task<EstornoFeito> EstornarAsync(string gatewayId, decimal? valor, CancellationToken ct = default)
    {
        await PrepararAsync(ct);
        var requisicao = new HttpRequestMessage(HttpMethod.Post, $"v1/payments/{gatewayId}/refunds")
        {
            Content = valor is null ? JsonContent.Create(new { }) : JsonContent.Create(new { amount = Math.Round(valor.Value, 2) })
        };
        requisicao.Headers.Add("X-Idempotency-Key", $"{gatewayId}-{valor?.ToString("0.00") ?? "total"}");
        using var resposta = await http.SendAsync(requisicao, ct);
        var texto = await resposta.Content.ReadAsStringAsync(ct);
        if (!resposta.IsSuccessStatusCode)
        {
            log.LogError("Mercado Pago (estorno): {Corpo}", texto);
            throw new RegraNegocioException("O Mercado Pago recusou o estorno. Verifique o prazo e o saldo da conta.");
        }
        var r = JsonDocument.Parse(texto).RootElement;
        var devolvido = r.TryGetProperty("amount", out var a) ? a.GetDecimal() : valor ?? 0m;
        var detalhe = await ConsultarAsync(gatewayId, ct);
        return new EstornoFeito(devolvido, detalhe?.Status ?? StatusPagamento.Estornado);
    }

    public async Task<(bool Ok, string Detalhe)> TestarConexaoAsync(CancellationToken ct = default)
    {
        await PrepararAsync(ct);
        using var r = await http.GetAsync("users/me", ct);
        var texto = await r.Content.ReadAsStringAsync(ct);
        if (!r.IsSuccessStatusCode)
            return (false, r.StatusCode == System.Net.HttpStatusCode.Unauthorized
                ? "Credencial recusada pelo Mercado Pago. Confira o Access Token."
                : $"O Mercado Pago respondeu {(int)r.StatusCode}.");
        var u = JsonDocument.Parse(texto).RootElement;
        var apelido = u.TryGetProperty("nickname", out var n) ? n.GetString() : null;
        var email = u.TryGetProperty("email", out var e) ? e.GetString() : null;
        return (true, $"Conectado à conta {apelido ?? email ?? "do Mercado Pago"}{(_sandbox ? " (ambiente de teste)" : " (produção)")}.");
    }

    public static StatusPagamento Converter(string status) => status switch
    {
        "approved" => StatusPagamento.Aprovado,
        "rejected" or "cancelled" => StatusPagamento.Recusado,
        "refunded" or "charged_back" => StatusPagamento.Estornado,
        _ => StatusPagamento.Pendente
    };
}

/// <summary>Cobrança simulada para testes sem conta no Mercado Pago. NÃO usar em produção.</summary>
public class ServicoPagamentoSimulado(ILogger<ServicoPagamentoSimulado> log) : IServicoPagamento
{
    public bool Real => false;

    public Task<DetalhePagamentoGateway?> ConsultarAsync(string gatewayId, CancellationToken ct = default)
        => Task.FromResult<DetalhePagamentoGateway?>(null);

    /// <summary>No modo simulado o estorno só muda a situação no banco: nenhum dinheiro se move.</summary>
    public Task<EstornoFeito> EstornarAsync(string gatewayId, decimal? valor, CancellationToken ct = default)
    {
        log.LogWarning("Estorno simulado de {Id}: configure o Mercado Pago para estornar de verdade.", gatewayId);
        return Task.FromResult(new EstornoFeito(valor ?? 0m, valor is null ? StatusPagamento.Estornado : StatusPagamento.Aprovado, "Estorno simulado"));
    }

    public Task<(bool Ok, string Detalhe)> TestarConexaoAsync(CancellationToken ct = default)
        => Task.FromResult((false, "Modo simulado: nenhuma conta do Mercado Pago conectada."));

    public Task<CobrancaCriada> CriarCobrancaAsync(Pedido pedido, string emailPagador, string nomePagador, MetodoPagamento metodo, CancellationToken ct = default)
    {
        log.LogWarning("Cobrança simulada do pedido {Numero}: configure MercadoPago:AccessToken para cobrar de verdade.", pedido.NumeroFormatado);
        var id = $"simulado-{pedido.Numero}";
        var copiaECola = $"00020126580014BR.GOV.BCB.PIX0136simulado-{pedido.Id}5204000053039865802BR";
        return Task.FromResult(metodo switch
        {
            MetodoPagamento.Pix => new CobrancaCriada(id, "pending", QrCodePix: copiaECola, CodigoCopiaECola: copiaECola),
            MetodoPagamento.Boleto => new CobrancaCriada(id, "pending", LinkBoleto: "https://exemplo.com/boleto-simulado.pdf"),
            _ => new CobrancaCriada(id, "pending", LinkCheckout: "https://exemplo.com/checkout-simulado")
        });
    }

    public Task<AvisoPagamento?> LerAvisoAsync(string corpo, IDictionary<string, string> cabecalhos, CancellationToken ct = default)
        => Task.FromResult<AvisoPagamento?>(null);
}
