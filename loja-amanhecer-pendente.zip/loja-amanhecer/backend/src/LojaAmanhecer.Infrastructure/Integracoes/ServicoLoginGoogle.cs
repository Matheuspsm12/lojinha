using Google.Apis.Auth;
using LojaAmanhecer.Application.Integracoes;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LojaAmanhecer.Infrastructure.Integracoes;

/// <summary>
/// Confere a assinatura do token do Google (biblioteca oficial <c>Google.Apis.Auth</c>) e se ele foi
/// emitido para o Client ID desta loja. Não precisa de chamada de rede: a validação usa as chaves
/// públicas do Google, já assinadas no próprio token (JWT).
/// </summary>
public class ServicoLoginGoogle(IConfiguration config, ILogger<ServicoLoginGoogle> log) : IServicoLoginGoogle
{
    public async Task<InfoLoginGoogle?> ValidarAsync(string credencialIdToken, CancellationToken ct = default)
    {
        var clientId = config["Autenticacao:Google:ClientId"];
        if (string.IsNullOrWhiteSpace(clientId))
        {
            log.LogWarning("Login com Google recebido, mas Autenticacao:Google:ClientId não está configurado.");
            return null;
        }

        try
        {
            var payload = await GoogleJsonWebSignature.ValidateAsync(credencialIdToken,
                new GoogleJsonWebSignature.ValidationSettings { Audience = [clientId] });

            return new InfoLoginGoogle(payload.Subject, payload.Email, payload.EmailVerified, payload.Name ?? payload.Email);
        }
        catch (InvalidJwtException ex)
        {
            log.LogWarning(ex, "Token do Google recusado na validação.");
            return null;
        }
    }
}
