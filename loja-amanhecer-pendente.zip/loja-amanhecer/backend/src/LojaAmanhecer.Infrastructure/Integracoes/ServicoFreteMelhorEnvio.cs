using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Pedidos;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LojaAmanhecer.Infrastructure.Integracoes;

/// <summary>
/// Melhor Envio: cotação, compra/geração de etiqueta e rastreio.
/// Precisa de MelhorEnvio:Token. Sem token, a injeção de dependência usa o ServicoFreteSimulado.
/// </summary>
public class ServicoFreteMelhorEnvio(HttpClient http, IConfiguration config, ILogger<ServicoFreteMelhorEnvio> log) : IServicoFrete
{
    private string Cep(string s) => new(s.Where(char.IsDigit).ToArray());
    private string CepOrigem => Cep(config["MelhorEnvio:CepOrigem"] ?? config["Frete:CepOrigem"] ?? "");

    private void Preparar()
    {
        http.BaseAddress ??= new Uri((config["MelhorEnvio:Url"] ?? "https://sandbox.melhorenvio.com.br").TrimEnd('/') + "/");
        http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", config["MelhorEnvio:Token"]);
        http.DefaultRequestHeaders.UserAgent.ParseAdd($"Loja Amanhecer ({config["MelhorEnvio:EmailContato"]})");
        http.DefaultRequestHeaders.Accept.ParseAdd("application/json");
    }

    public async Task<IReadOnlyList<OpcaoFrete>> CotarAsync(string cepDestino, IEnumerable<PacoteFrete> pacotes, CancellationToken ct = default)
    {
        Preparar();
        var corpo = new
        {
            from = new { postal_code = CepOrigem },
            to = new { postal_code = Cep(cepDestino) },
            products = pacotes.Select((p, i) => new
            {
                id = (i + 1).ToString(),
                width = (int)Math.Ceiling(p.LarguraCm),
                height = (int)Math.Ceiling(p.AlturaCm),
                length = (int)Math.Ceiling(p.ComprimentoCm),
                weight = Math.Round(p.PesoGramas / 1000m, 3),
                insurance_value = p.ValorSeguro,
                quantity = p.Quantidade
            })
        };

        using var resposta = await http.PostAsJsonAsync("api/v2/me/shipment/calculate", corpo, ct);
        var texto = await resposta.Content.ReadAsStringAsync(ct);
        if (!resposta.IsSuccessStatusCode)
        {
            log.LogError("Melhor Envio recusou a cotação ({Status}): {Corpo}", resposta.StatusCode, texto);
            throw new RegraNegocioException("Não foi possível calcular o frete agora. Tente novamente em alguns instantes.");
        }

        var opcoes = new List<OpcaoFrete>();
        using var doc = JsonDocument.Parse(texto);
        foreach (var s in doc.RootElement.EnumerateArray())
        {
            if (s.TryGetProperty("error", out var erro) && erro.ValueKind == JsonValueKind.String) continue;
            if (!s.TryGetProperty("price", out var preco) || !decimal.TryParse(preco.GetString(), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var valor)) continue;
            var prazo = s.TryGetProperty("delivery_time", out var d) && d.TryGetInt32(out var dias) ? dias : 0;
            opcoes.Add(new OpcaoFrete(
                s.GetProperty("id").GetInt32(),
                s.GetProperty("company").GetProperty("name").GetString() ?? "",
                s.GetProperty("name").GetString() ?? "",
                valor, prazo));
        }
        return opcoes.OrderBy(o => o.Valor).ToList();
    }

    public async Task<string> GerarEtiquetaAsync(Pedido pedido, CancellationToken ct = default)
    {
        Preparar();
        // Fluxo do Melhor Envio: carrinho → compra → geração → impressão.
        var carrinho = new
        {
            service = pedido.ServicoFreteId,
            from = new { postal_code = CepOrigem },
            to = new
            {
                name = pedido.EnderecoEntrega.Destinatario,
                postal_code = Cep(pedido.EnderecoEntrega.Cep),
                address = pedido.EnderecoEntrega.Logradouro,
                number = pedido.EnderecoEntrega.Numero,
                complement = pedido.EnderecoEntrega.Complemento,
                district = pedido.EnderecoEntrega.Bairro,
                city = pedido.EnderecoEntrega.Cidade,
                state_abbr = pedido.EnderecoEntrega.Uf
            },
            products = pedido.Itens.Select(i => new { name = i.NomeProduto, quantity = i.Quantidade, unitary_value = i.PrecoUnitario }),
            options = new { receipt = false, own_hand = false, insurance_value = pedido.Subtotal, reverse = false, non_commercial = true }
        };

        using var r1 = await http.PostAsJsonAsync("api/v2/me/cart", carrinho, ct);
        var t1 = await r1.Content.ReadAsStringAsync(ct);
        if (!r1.IsSuccessStatusCode) { log.LogError("Melhor Envio (carrinho): {Corpo}", t1); throw new RegraNegocioException("Não foi possível gerar a etiqueta no Melhor Envio."); }
        var id = JsonDocument.Parse(t1).RootElement.GetProperty("id").GetString()!;

        using var r2 = await http.PostAsJsonAsync("api/v2/me/shipment/checkout", new { orders = new[] { id } }, ct);
        if (!r2.IsSuccessStatusCode) { log.LogError("Melhor Envio (compra): {Corpo}", await r2.Content.ReadAsStringAsync(ct)); throw new RegraNegocioException("A etiqueta foi adicionada ao carrinho, mas a compra falhou. Verifique o saldo no Melhor Envio."); }

        using var r3 = await http.PostAsJsonAsync("api/v2/me/shipment/generate", new { orders = new[] { id } }, ct);
        if (!r3.IsSuccessStatusCode) log.LogWarning("Melhor Envio (geração): {Corpo}", await r3.Content.ReadAsStringAsync(ct));
        return id;
    }

    public async Task<string?> ObterRastreioAsync(string etiquetaId, CancellationToken ct = default)
    {
        Preparar();
        using var r = await http.PostAsJsonAsync("api/v2/me/shipment/tracking", new { orders = new[] { etiquetaId } }, ct);
        if (!r.IsSuccessStatusCode) return null;
        using var doc = JsonDocument.Parse(await r.Content.ReadAsStringAsync(ct));
        foreach (var item in doc.RootElement.EnumerateObject())
            if (item.Value.TryGetProperty("tracking", out var t) && t.ValueKind == JsonValueKind.String)
                return t.GetString();
        return null;
    }
}

/// <summary>
/// Usado enquanto o token do Melhor Envio não está configurado: calcula um valor aproximado
/// por faixa de CEP e peso, para permitir testes de ponta a ponta. NÃO usar em produção.
/// </summary>
public class ServicoFreteSimulado(ILogger<ServicoFreteSimulado> log) : IServicoFrete
{
    private static readonly (int De, int Ate, string Uf)[] Faixas =
    [(1,19,"SP"),(20,28,"RJ"),(29,29,"ES"),(30,39,"MG"),(40,48,"BA"),(49,49,"SE"),(50,56,"PE"),(57,57,"AL"),(58,58,"PB"),
     (59,59,"RN"),(60,63,"CE"),(64,64,"PI"),(65,65,"MA"),(66,68,"PA"),(69,69,"AM"),(70,73,"DF"),(74,76,"GO"),(77,77,"TO"),
     (78,78,"MT"),(79,79,"MS"),(80,87,"PR"),(88,89,"SC"),(90,99,"RS")];

    public static string UfDoCep(string cep)
    {
        var d = new string(cep.Where(char.IsDigit).ToArray());
        if (d.Length < 2) return "SP";
        var f = int.Parse(d[..2]);
        return Faixas.FirstOrDefault(x => f >= x.De && f <= x.Ate).Uf ?? "SP";
    }

    public Task<IReadOnlyList<OpcaoFrete>> CotarAsync(string cepDestino, IEnumerable<PacoteFrete> pacotes, CancellationToken ct = default)
    {
        log.LogWarning("Cotação simulada: configure MelhorEnvio:Token para usar valores reais.");
        var uf = UfDoCep(cepDestino);
        var distancia = new Dictionary<string, int> { ["DF"] = 0, ["GO"] = 1, ["MG"] = 2, ["MT"] = 2, ["MS"] = 2, ["TO"] = 2, ["BA"] = 2, ["SP"] = 2, ["RJ"] = 3, ["ES"] = 3, ["PR"] = 3, ["SC"] = 3, ["RS"] = 4 }.GetValueOrDefault(uf, 4);
        var pesoKg = Math.Max(0.3m, pacotes.Sum(p => p.PesoGramas * p.Quantidade) / 1000m);
        IReadOnlyList<OpcaoFrete> opcoes =
        [
            new(1, "Correios", "PAC", Math.Round(16.9m + distancia * 4.2m + pesoKg * 5.5m, 2), 3 + distancia * 2),
            new(2, "Correios", "SEDEX", Math.Round(27.5m + distancia * 6.8m + pesoKg * 8.9m, 2), 1 + distancia),
            new(3, "Jadlog", ".Package", Math.Round(19.9m + distancia * 3.9m + pesoKg * 5.1m, 2), 2 + distancia * 2)
        ];
        return Task.FromResult(opcoes);
    }

    public Task<string> GerarEtiquetaAsync(Pedido pedido, CancellationToken ct = default) =>
        throw new RegraNegocioException("Configure o token do Melhor Envio para gerar etiquetas.");

    public Task<string?> ObterRastreioAsync(string etiquetaId, CancellationToken ct = default) => Task.FromResult<string?>(null);
}
