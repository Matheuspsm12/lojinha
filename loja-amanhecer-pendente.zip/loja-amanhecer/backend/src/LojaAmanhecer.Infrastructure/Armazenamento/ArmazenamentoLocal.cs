using LojaAmanhecer.Application.Integracoes;
using Microsoft.Extensions.Configuration;

namespace LojaAmanhecer.Infrastructure.Armazenamento;

/// <summary>Salva fotos em disco (pasta "uploads"), servidas em /uploads. Para produção, trocar por R2/S3.</summary>
public class ArmazenamentoLocal(IConfiguration config) : IArmazenamentoArquivos
{
    // Formatos aceitos no envio: os de câmera de celular entram aqui (HEIC/HEIF) e são convertidos depois.
    private static readonly string[] Permitidos = [".jpg", ".jpeg", ".png", ".webp", ".avif", ".heic", ".heif"];
    private string Pasta => Path.GetFullPath(config["Armazenamento:PastaLocal"] ?? "uploads");

    public Task<string> SalvarAsync(Stream conteudo, string nomeArquivo, string contentType, CancellationToken ct = default)
    {
        var ext = Path.GetExtension(nomeArquivo).ToLowerInvariant();
        if (!Permitidos.Contains(ext))
            throw new InvalidOperationException("Formato de imagem não permitido. Use JPG, PNG, WEBP ou HEIC.");
        return SalvarComNomeAsync(conteudo, $"{Guid.NewGuid():N}{ext}", ct);
    }

    public async Task<string> SalvarComNomeAsync(Stream conteudo, string nomeArquivo, CancellationToken ct = default)
    {
        Directory.CreateDirectory(Pasta);
        var nome = Path.GetFileName(nomeArquivo);
        await using var destino = File.Create(Path.Combine(Pasta, nome));
        await conteudo.CopyToAsync(destino, ct);
        return $"/uploads/{nome}";
    }

    public Task RemoverAsync(string url, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(url)) return Task.CompletedTask;
        var caminho = Path.Combine(Pasta, Path.GetFileName(url));
        if (File.Exists(caminho)) File.Delete(caminho);
        return Task.CompletedTask;
    }
}
