using Amazon.S3;
using Amazon.S3.Model;
using LojaAmanhecer.Application.Integracoes;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LojaAmanhecer.Infrastructure.Armazenamento;

/// <summary>
/// Armazenamento em serviço compatível com S3 (Cloudflare R2, Amazon S3, MinIO, Backblaze B2).
/// Ligado com Armazenamento:Provedor = "s3". O envio e a exclusão funcionam igual ao disco local:
/// quem chama continua usando as mesmas URLs, então nada muda no resto do sistema.
/// </summary>
public class ArmazenamentoS3 : IArmazenamentoArquivos
{
    private static readonly string[] Permitidos = [".jpg", ".jpeg", ".png", ".webp", ".avif", ".heic", ".heif"];

    private readonly IAmazonS3 _s3;
    private readonly IConfiguration _config;
    private readonly ILogger<ArmazenamentoS3> _log;

    public ArmazenamentoS3(IConfiguration config, ILogger<ArmazenamentoS3> log)
    {
        _config = config;
        _log = log;
        var opcoes = new AmazonS3Config
        {
            ForcePathStyle = config.GetValue("Armazenamento:S3:ForcarCaminho", true),
            ServiceURL = config["Armazenamento:S3:Endpoint"]
        };
        if (string.IsNullOrWhiteSpace(opcoes.ServiceURL))
        {
            opcoes.ServiceURL = null;
            opcoes.RegionEndpoint = Amazon.RegionEndpoint.GetBySystemName(config["Armazenamento:S3:Regiao"] ?? "us-east-1");
        }
        _s3 = new AmazonS3Client(config["Armazenamento:S3:ChaveAcesso"], config["Armazenamento:S3:ChaveSecreta"], opcoes);
    }

    private string Bucket => _config["Armazenamento:S3:Bucket"]
        ?? throw new InvalidOperationException("Configure Armazenamento:S3:Bucket.");

    /// <summary>Pasta dentro do bucket. Padrão: uploads.</summary>
    private string Prefixo => (_config["Armazenamento:S3:Prefixo"] ?? "uploads").Trim('/');

    /// <summary>Endereço público dos arquivos (CDN ou domínio do bucket).</summary>
    private string? UrlPublica => _config["Armazenamento:S3:UrlPublica"]?.TrimEnd('/');

    public Task<string> SalvarAsync(Stream conteudo, string nomeArquivo, string contentType, CancellationToken ct = default)
    {
        var ext = Path.GetExtension(nomeArquivo).ToLowerInvariant();
        if (!Permitidos.Contains(ext))
            throw new InvalidOperationException("Formato de imagem não permitido. Use JPG, PNG, WEBP ou HEIC.");
        return SalvarComNomeAsync(conteudo, $"{Guid.NewGuid():N}{ext}", ct);
    }

    public async Task<string> SalvarComNomeAsync(Stream conteudo, string nomeArquivo, CancellationToken ct = default)
    {
        var nome = Path.GetFileName(nomeArquivo);
        var chave = $"{Prefixo}/{nome}";
        await _s3.PutObjectAsync(new PutObjectRequest
        {
            BucketName = Bucket,
            Key = chave,
            InputStream = conteudo,
            ContentType = TipoDe(nome),
            DisablePayloadSigning = true,          // exigido pelo Cloudflare R2
            Headers = { CacheControl = "public,max-age=31536000,immutable" }
        }, ct);
        return UrlPublica is { Length: > 0 } ? $"{UrlPublica}/{nome}" : $"/uploads/{nome}";
    }

    public async Task RemoverAsync(string url, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(url)) return;
        var chave = $"{Prefixo}/{ChaveDe(url)}";
        try
        {
            await _s3.DeleteObjectAsync(new DeleteObjectRequest { BucketName = Bucket, Key = chave }, ct);
            _log.LogInformation("Arquivo removido do armazenamento: {Chave}", chave);
        }
        catch (AmazonS3Exception ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            _log.LogWarning("Arquivo já não existia no armazenamento: {Chave}", chave);
        }
    }

    /// <summary>Extrai o nome do arquivo da URL guardada no banco, venha ela do CDN ou de /uploads.</summary>
    public static string ChaveDe(string url)
    {
        var limpa = url.Split('?')[0].TrimEnd('/');
        var barra = limpa.LastIndexOf('/');
        return barra >= 0 ? limpa[(barra + 1)..] : limpa;
    }

    private static string TipoDe(string nome) => Path.GetExtension(nome).ToLowerInvariant() switch
    {
        ".jpg" or ".jpeg" => "image/jpeg",
        ".png" => "image/png",
        ".webp" => "image/webp",
        ".avif" => "image/avif",
        ".heic" => "image/heic",
        ".heif" => "image/heif",
        _ => "application/octet-stream"
    };
}
