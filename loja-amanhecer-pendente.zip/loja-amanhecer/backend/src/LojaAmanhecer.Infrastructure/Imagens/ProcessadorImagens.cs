using ImageMagick;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Comum;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LojaAmanhecer.Infrastructure.Imagens;

/// <summary>
/// Processa a foto enviada pelo vendedor:
/// 1. guarda o arquivo original sem tocar em nada;
/// 2. corrige a orientação pelo EXIF (foto tirada de lado fica em pé);
/// 3. gera miniatura, versão de catálogo e versão da página do produto em WebP (ou AVIF);
/// 4. remove metadados das cópias (EXIF com localização, por exemplo) e comprime sem perda visível.
/// Formatos aceitos: JPG, JPEG, PNG, WEBP, AVIF e HEIC/HEIF (iPhone).
/// </summary>
public class ProcessadorImagens(IArmazenamentoArquivos armazenamento, IConfiguration config, ILogger<ProcessadorImagens> log) : IProcessadorImagens
{
    private static readonly string[] Extensoes = [".jpg", ".jpeg", ".png", ".webp", ".avif", ".heic", ".heif"];
    private static readonly string[] TiposMime =
        ["image/jpeg", "image/jpg", "image/pjpeg", "image/png", "image/webp", "image/avif", "image/heic", "image/heif", "image/heic-sequence", "application/octet-stream"];

    public IReadOnlyCollection<string> ExtensoesAceitas => Extensoes;

    private int Tamanho(string chave, int padrao) => config.GetValue($"Imagens:{chave}", padrao);
    private string FormatoSaida => (config["Imagens:Formato"] ?? "webp").ToLowerInvariant();

    public bool Aceita(string nomeArquivo, string? contentType)
    {
        var ext = Path.GetExtension(nomeArquivo).ToLowerInvariant();
        if (Extensoes.Contains(ext)) return true;
        return contentType is not null && TiposMime.Contains(contentType.ToLowerInvariant()) && contentType != "application/octet-stream";
    }

    public async Task<ImagemProcessada> ProcessarAsync(Stream conteudo, string nomeArquivo, CancellationToken ct = default)
    {
        var ext = Path.GetExtension(nomeArquivo).ToLowerInvariant();
        if (!Aceita(nomeArquivo, null) && !Extensoes.Contains(ext))
            throw new RegraNegocioException($"O arquivo \"{nomeArquivo}\" não é uma imagem aceita. Use JPG, PNG, WEBP, AVIF ou HEIC.");

        // Copia para memória: o original precisa ser gravado e também lido pelo processador
        using var memoria = new MemoryStream();
        await conteudo.CopyToAsync(memoria, ct);
        memoria.Position = 0;
        var bytesOriginal = memoria.Length;
        if (bytesOriginal == 0) throw new RegraNegocioException($"O arquivo \"{nomeArquivo}\" chegou vazio. Tente enviar de novo.");

        var baseNome = Guid.NewGuid().ToString("N");
        var extOriginal = Extensoes.Contains(ext) ? ext : ".jpg";

        // 1. Original preservado exatamente como veio
        var urlOriginal = await armazenamento.SalvarComNomeAsync(memoria, $"{baseNome}-original{extOriginal}", ct);
        memoria.Position = 0;

        // 2/3/4. Versões otimizadas (trabalho de CPU fora do laço de requisição)
        return await Task.Run(() => GerarVersoes(memoria, baseNome, urlOriginal, extOriginal, bytesOriginal, ct), ct);
    }

    public async Task<ImagemProcessada> ProcessarQuadradoAsync(Stream conteudo, string nomeArquivo, Recorte? recorte, CancellationToken ct = default)
    {
        var ext = Path.GetExtension(nomeArquivo).ToLowerInvariant();
        if (!Aceita(nomeArquivo, null) && !Extensoes.Contains(ext))
            throw new RegraNegocioException($"O arquivo \"{nomeArquivo}\" não é uma imagem aceita. Use JPG, PNG, WEBP, AVIF ou HEIC.");

        using var memoria = new MemoryStream();
        await conteudo.CopyToAsync(memoria, ct);
        memoria.Position = 0;
        var bytesOriginal = memoria.Length;
        if (bytesOriginal == 0) throw new RegraNegocioException($"O arquivo \"{nomeArquivo}\" chegou vazio. Tente enviar de novo.");

        var baseNome = Guid.NewGuid().ToString("N");
        var extOriginal = Extensoes.Contains(ext) ? ext : ".jpg";
        var urlOriginal = await armazenamento.SalvarComNomeAsync(memoria, $"{baseNome}-original{extOriginal}", ct);
        memoria.Position = 0;

        return await Task.Run(() => GerarQuadrados(memoria, baseNome, urlOriginal, extOriginal, bytesOriginal, recorte, ct), ct);
    }

    private ImagemProcessada GerarQuadrados(MemoryStream memoria, string baseNome, string urlOriginal, string extOriginal, long bytesOriginal, Recorte? recorte, CancellationToken ct)
    {
        MagickImage imagem;
        try { imagem = new MagickImage(memoria); }
        catch (MagickException ex)
        {
            log.LogWarning(ex, "Arquivo enviado não pôde ser lido como imagem");
            throw new RegraNegocioException("Não conseguimos ler esta foto. Verifique se o arquivo não está corrompido.");
        }

        using (imagem)
        {
            imagem.AutoOrient();
            imagem.ColorSpace = ColorSpace.sRGB;
            imagem.Strip();

            var larguraOriginal = Convert.ToInt32(imagem.Width);
            var alturaOriginal = Convert.ToInt32(imagem.Height);
            var area = AjustarRecorte(recorte, larguraOriginal, alturaOriginal);
            imagem.Crop(new MagickGeometry(area.X, area.Y, (uint)area.Largura, (uint)area.Altura));
            imagem.ResetPage();   // sem isso o recorte guarda o deslocamento e desalinha o resultado

            var formato = FormatoSaida == "avif" ? MagickFormat.Avif : MagickFormat.WebP;
            var extSaida = formato == MagickFormat.Avif ? ".avif" : ".webp";
            var qualidade = Tamanho("Qualidade", 82);

            string Gravar(string sufixo, int lado)
            {
                ct.ThrowIfCancellationRequested();
                using var copia = (MagickImage)imagem.Clone();
                copia.Resize(new MagickGeometry((uint)lado, (uint)lado) { Greater = true, FillArea = true });
                copia.Quality = (uint)qualidade;
                copia.Format = formato;
                using var saida = new MemoryStream();
                copia.Write(saida);
                saida.Position = 0;
                return armazenamento.SalvarComNomeAsync(saida, $"{baseNome}{sufixo}{extSaida}", ct).GetAwaiter().GetResult();
            }

            var ladoMedalhao = Tamanho("CategoriaMedalhao", 600);
            var ladoMini = Tamanho("CategoriaMiniatura", 200);
            var urlMini = Gravar("-cat-mini", ladoMini);
            var urlMedalhao = Gravar("-cat", ladoMedalhao);

            log.LogInformation("Foto de categoria processada: {Original} ({Mb:F1} MB) → medalhão quadrado de {Lado}px",
                Path.GetFileName(urlOriginal), bytesOriginal / 1048576.0, ladoMedalhao);

            return new ImagemProcessada(urlOriginal, urlMini, urlMedalhao, urlMedalhao,
                area.Largura, area.Altura, extOriginal.TrimStart('.').ToUpperInvariant(), bytesOriginal, TamanhoArquivo(urlMedalhao));
        }
    }

    /// <summary>Encaixa o recorte pedido dentro da foto; sem recorte válido, corta um quadrado no centro.</summary>
    public static Recorte AjustarRecorte(Recorte? recorte, int largura, int altura)
    {
        if (recorte is null || recorte.Largura <= 0 || recorte.Altura <= 0)
        {
            var lado = Math.Min(largura, altura);
            return new Recorte((largura - lado) / 2, (altura - lado) / 2, lado, lado);
        }
        var x = Math.Clamp(recorte.X, 0, Math.Max(0, largura - 1));
        var y = Math.Clamp(recorte.Y, 0, Math.Max(0, altura - 1));
        var l = Math.Clamp(recorte.Largura, 1, largura - x);
        var a = Math.Clamp(recorte.Altura, 1, altura - y);
        var ladoFinal = Math.Min(l, a);   // o medalhão é redondo: o recorte precisa ser quadrado
        return new Recorte(x, y, ladoFinal, ladoFinal);
    }

    private ImagemProcessada GerarVersoes(MemoryStream memoria, string baseNome, string urlOriginal, string extOriginal, long bytesOriginal, CancellationToken ct)
    {
        MagickImage imagem;
        try
        {
            imagem = new MagickImage(memoria);
        }
        catch (MagickException ex)
        {
            log.LogWarning(ex, "Arquivo enviado não pôde ser lido como imagem");
            throw new RegraNegocioException("Não conseguimos ler esta foto. Verifique se o arquivo não está corrompido.");
        }

        using (imagem)
        {
            imagem.AutoOrient();                    // corrige foto tirada de lado
            imagem.ColorSpace = ColorSpace.sRGB;    // cores iguais em qualquer navegador
            imagem.Strip();                         // tira EXIF (inclusive localização) das cópias
            imagem.Settings.Interlace = Interlace.Plane;

            var largura = Convert.ToInt32(imagem.Width);
            var altura = Convert.ToInt32(imagem.Height);

            var formato = FormatoSaida == "avif" ? MagickFormat.Avif : MagickFormat.WebP;
            var extSaida = formato == MagickFormat.Avif ? ".avif" : ".webp";
            var qualidade = Tamanho("Qualidade", 82);

            string Gravar(string sufixo, int ladoMaior)
            {
                ct.ThrowIfCancellationRequested();
                using var copia = (MagickImage)imagem.Clone();
                // Greater = true: só reduz, nunca amplia uma foto pequena
                copia.Resize(new MagickGeometry((uint)ladoMaior, (uint)ladoMaior) { Greater = true });
                copia.Quality = (uint)qualidade;
                copia.Format = formato;
                using var saida = new MemoryStream();
                copia.Write(saida);
                saida.Position = 0;
                return armazenamento.SalvarComNomeAsync(saida, $"{baseNome}{sufixo}{extSaida}", ct).GetAwaiter().GetResult();
            }

            var urlMiniatura = Gravar("-mini", Tamanho("Miniatura", 400));
            var urlCatalogo = Gravar("-cat", Tamanho("Catalogo", 900));
            var urlGrande = Gravar("-grande", Tamanho("Produto", 1600));

            var bytesCatalogo = TamanhoArquivo(urlCatalogo);
            log.LogInformation("Foto processada: {Original} ({Mb:F1} MB, {L}x{A}) → catálogo com {Kb:F0} KB",
                Path.GetFileName(urlOriginal), bytesOriginal / 1048576.0, largura, altura, bytesCatalogo / 1024.0);

            return new ImagemProcessada(urlOriginal, urlMiniatura, urlCatalogo, urlGrande, largura, altura,
                extOriginal.TrimStart('.').ToUpperInvariant(), bytesOriginal, bytesCatalogo);
        }
    }

    private long TamanhoArquivo(string url)
    {
        var caminho = Path.Combine(Path.GetFullPath(config["Armazenamento:PastaLocal"] ?? "uploads"), Path.GetFileName(url));
        return File.Exists(caminho) ? new FileInfo(caminho).Length : 0;
    }
}
