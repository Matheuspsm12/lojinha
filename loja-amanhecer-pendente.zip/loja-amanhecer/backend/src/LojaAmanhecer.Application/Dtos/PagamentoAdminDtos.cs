using LojaAmanhecer.Domain.Enums;

namespace LojaAmanhecer.Application.Dtos;

/// <summary>Situação da integração e regras de pagamento. Nunca traz o Access Token completo.</summary>
public record ConfiguracaoPagamentoDto(
    bool Conectado, bool Simulado, string Ambiente, string FonteCredencial, string TokenMascarado, string? Conta,
    DateTime? UltimoTesteEm, string? UltimoTesteDetalhe,
    bool PixAtivo, bool CartaoAtivo, bool BoletoAtivo,
    int MaximoParcelas, bool ParcelamentoComJuros, decimal ValorMinimoParcela,
    decimal TaxaPix, decimal TaxaCartao, decimal TaxaBoleto);

public record SalvarConfiguracaoPagamentoDto(
    bool PixAtivo, bool CartaoAtivo, bool BoletoAtivo,
    int MaximoParcelas, bool ParcelamentoComJuros, decimal ValorMinimoParcela,
    string Ambiente, decimal TaxaPix, decimal TaxaCartao, decimal TaxaBoleto);

public record SalvarCredencialDto(string AccessToken, string? Ambiente, bool TestarAntes = true);

public record TesteConexaoDto(bool Ok, string Detalhe, bool Simulado);

/// <summary>Opções de pagamento que a loja mostra ao cliente.</summary>
public record OpcoesPagamentoDto(bool Pix, bool Cartao, bool Boleto, int MaximoParcelas, bool ComJuros, decimal ValorMinimoParcela);

public record PagamentoAdminDto(
    Guid Id, long PedidoNumero, string PedidoFormatado, string Cliente, string ClienteEmail,
    MetodoPagamento Metodo, StatusPagamento Status, string StatusTexto,
    decimal Valor, decimal? Taxa, decimal? Liquido, decimal ValorEstornado,
    DateTime CriadoEm, DateTime? PagoEm, string? GatewayIdMascarado, string? Ambiente, bool PodeEstornar);

public record ResumoRecebimentosDto(
    int Aprovados, int Pendentes, int Recusados, int Estornados, int Cancelados,
    decimal TotalAprovado, decimal TotalTaxas, decimal LiquidoPrevisto, decimal TotalEstornado,
    decimal TotalPendente, bool Simulado);

public record EstornarDto(decimal? Valor, string? Motivo);
