using LojaAmanhecer.Domain.Enums;

namespace LojaAmanhecer.Application.Dtos;

public record ItemCarrinhoDto(Guid ProdutoId, Guid? VariacaoId, int Quantidade, string? Personalizacao);

public record CotarFreteDto(string Cep, List<ItemCarrinhoDto> Itens);

public record OpcaoEntregaDto(int ServicoId, string Nome, decimal Valor, int PrazoTransporteDias,
    int PrazoProducaoDias, int PrazoTotalDias, string? Detalhe);

public record EnderecoDto(Guid? Id, string Apelido, string Destinatario, string Cep, string Logradouro,
    string Numero, string? Complemento, string Bairro, string Cidade, string Uf, bool Principal);

public record CriarPedidoDto(List<ItemCarrinhoDto> Itens, Guid? EnderecoId, EnderecoDto? NovoEndereco,
    int ServicoFreteId, MetodoPagamento MetodoPagamento, string? Observacao);

public record PedidoItemDto(string Nome, string? Variacao, string? Personalizacao, decimal PrecoUnitario, int Quantidade, decimal Total);

public record PagamentoDto(MetodoPagamento Metodo, StatusPagamento Status, decimal Valor, string? QrCodePix,
    string? QrCodeBase64, string? LinkBoleto, string? LinkCheckout);

public record HistoricoDto(StatusPedido Status, DateTime Em, string? Comentario);

public record PedidoDto(Guid Id, long Numero, string NumeroFormatado, StatusPedido Status, string StatusTexto,
    DateTime CriadoEm, decimal Subtotal, decimal ValorFrete, decimal Total,
    string FormaEntrega, int PrazoProducaoDias, int PrazoTransporteDias, int PrazoTotalDias,
    string? CodigoRastreio, string? Observacao, EnderecoEntregaDto EnderecoEntrega,
    List<PedidoItemDto> Itens, PagamentoDto? Pagamento, List<HistoricoDto> Historico);

public record EnderecoEntregaDto(string Destinatario, string Cep, string Logradouro, string Numero,
    string? Complemento, string Bairro, string Cidade, string Uf);

public record PedidoAdminDto(Guid Id, long Numero, string NumeroFormatado, StatusPedido Status, string StatusTexto,
    DateTime CriadoEm, string Cliente, string ClienteEmail, string? ClienteTelefone, Guid? VendedorId, string? Vendedor,
    decimal Subtotal, decimal ValorFrete, decimal Total, string FormaEntrega, int PrazoProducaoDias, int PrazoTransporteDias,
    string? CodigoRastreio, string? EtiquetaId, string? ObservacaoCliente, string? ObservacaoInterna,
    EnderecoEntregaDto EnderecoEntrega, List<PedidoItemDto> Itens, PagamentoDto? Pagamento, List<HistoricoDto> Historico,
    List<StatusPedido> ProximosStatus);

public record MudarStatusDto(StatusPedido Status, string? Comentario);
public record RastreioDto(string CodigoRastreio);
public record AtualizarDadosDto(string NomeCompleto, string? Telefone, string? Cpf);

public record RelatorioVendasDto(decimal Faturamento, int Pedidos, decimal TicketMedio, int ClientesNovos,
    List<VendaPorDiaDto> PorDia, List<VendaPorCategoriaDto> PorCategoria, List<ProdutoVendidoDto> MaisVendidos,
    List<VendaPorVendedorDto> PorVendedor);
public record VendaPorDiaDto(DateOnly Dia, decimal Valor, int Pedidos);
public record VendaPorCategoriaDto(string Categoria, decimal Valor, int Unidades);
public record ProdutoVendidoDto(string Produto, int Unidades, decimal Valor);
public record VendaPorVendedorDto(string Vendedor, int Pedidos, decimal Valor);

/// <summary>Cliques (visitas à página do produto) x vendas de fato, lado a lado — o "mapa de calor" do catálogo.</summary>
public record ProdutoDesempenhoDto(string Produto, int Cliques, int Unidades, decimal Valor);
