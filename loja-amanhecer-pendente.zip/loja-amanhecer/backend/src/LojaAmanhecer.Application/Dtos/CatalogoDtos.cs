using LojaAmanhecer.Domain.Enums;

namespace LojaAmanhecer.Application.Dtos;

public record CategoriaDto(Guid Id, string Nome, string Slug, string? Descricao, string? ImagemUrl, int Ordem, bool Ativa,
    Guid? CategoriaPaiId, List<CategoriaDto> Subcategorias,
    string? ImagemMiniaturaUrl = null, string? ImagemOriginalUrl = null, bool TemFoto = false);

/// <summary>Uma linha da lista de categorias do formulário de produto.</summary>
public record CategoriaOpcaoDto(Guid Id, string Nome, string? CategoriaPai, string Caminho, bool Ativa, bool EhSubcategoria, int Produtos);

public record SalvarCategoriaDto(string Nome, string? Descricao, string? ImagemUrl, int Ordem, bool Ativa, Guid? CategoriaPaiId);

public record ProdutoResumoDto(Guid Id, string Nome, string Slug, string Categoria, decimal Preco, string? ImagemUrl,
    TipoDisponibilidade Disponibilidade, int PrazoProducaoDias, int EstoqueTotal, bool Ativo, bool Destaque,
    List<string>? Fotos = null);   // todas as fotos, na ordem do cadastro, para navegar no card da loja

public record ProdutoImagemDto(Guid Id, string Url, string? TextoAlternativo, int Ordem,
    string? UrlMiniatura = null, string? UrlGrande = null, string? UrlOriginal = null, int? Largura = null, int? Altura = null);
public record ProdutoOpcaoDto(string Nome, int Ordem, List<string> Valores);
public record ProdutoVariacaoDto(Guid? Id, string? Sku, Dictionary<string, string> Atributos, decimal? Preco, int Estoque, bool Ativa);

public record ProdutoDetalheDto(
    Guid Id, string Nome, string Slug, string Descricao,
    Guid CategoriaId, string Categoria, Guid? CategoriaPaiId, string? CategoriaPai,
    decimal Preco, int Estoque, int EstoqueTotal,
    int PesoGramas, decimal AlturaCm, decimal LarguraCm, decimal ComprimentoCm,
    TipoDisponibilidade Disponibilidade, int PrazoProducaoDias,
    bool PermitePersonalizacao, string? RotuloPersonalizacao, int? LimiteCaracteresPersonalizacao, decimal ValorPersonalizacao,
    bool Ativo, bool Destaque,
    List<ProdutoImagemDto> Imagens, List<ProdutoOpcaoDto> Opcoes, List<ProdutoVariacaoDto> Variacoes);

public record SalvarProdutoDto(
    string Nome, string Descricao, Guid CategoriaId, decimal Preco, int Estoque,
    int PesoGramas, decimal AlturaCm, decimal LarguraCm, decimal ComprimentoCm,
    TipoDisponibilidade Disponibilidade, int PrazoProducaoDias,
    bool PermitePersonalizacao, string? RotuloPersonalizacao, int? LimiteCaracteresPersonalizacao, decimal ValorPersonalizacao,
    bool Ativo, bool Destaque,
    List<ProdutoOpcaoDto> Opcoes, List<ProdutoVariacaoDto> Variacoes);

public record PaginaDto<T>(IReadOnlyList<T> Itens, int Pagina, int TamanhoPagina, int Total);
