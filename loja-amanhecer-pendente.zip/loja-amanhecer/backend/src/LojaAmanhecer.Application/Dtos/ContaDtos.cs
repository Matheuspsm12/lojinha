namespace LojaAmanhecer.Application.Dtos;

public record RegistrarDto(string NomeCompleto, string Email, string Senha, string? Telefone, string? Cpf);
public record LoginDto(string Email, string Senha);

/// <summary>Token de identidade (JWT) devolvido pelo botão "Continuar com o Google" no navegador.</summary>
public record LoginGoogleDto(string Credencial);
public record TokenDto(string Token, DateTime ExpiraEm, string Nome, string Email, IList<string> Perfis, bool DeveTrocarSenha = false);

public record AlterarSenhaDto(string SenhaAtual, string NovaSenha);
public record EsqueciSenhaDto(string Email, string? Origem);
public record RedefinirSenhaDto(string Email, string Token, string NovaSenha);
public record CriarPrimeiroAdminDto(string TokenInstalacao, string NomeCompleto, string Email, string Senha);
public record SituacaoInstalacaoDto(bool PrecisaCriarAdministrador);
public record SessaoDto(Guid Id, string Nome, string Email, IList<string> Perfis, bool DeveTrocarSenha, DateTime ExpiraEm);
public record RegistroAcessoDto(DateTime Em, string Email, bool Sucesso, string Motivo, string Origem, string? Ip, string? Navegador);

public record PainelResumoDto(int PedidosNovos, int AguardandoPagamento, int EmProducao, int Enviados,
    decimal VendasMes, int PedidosMes, int ProdutosAtivos, int ProdutosEstoqueBaixo);
