using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Domain.Pedidos;

namespace LojaAmanhecer.Application.Integracoes;

public record CobrancaCriada(string GatewayId, string Status, string? QrCodePix = null, string? QrCodeBase64 = null,
    string? LinkBoleto = null, string? LinkCheckout = null, string? CodigoCopiaECola = null);

/// <summary>Resultado da leitura de um aviso (webhook) do gateway.</summary>
public record AvisoPagamento(string GatewayId, StatusPagamento Status, string StatusOriginal);

/// <summary>Situação de um pagamento no gateway, com taxa e líquido quando o provedor informa.</summary>
public record DetalhePagamentoGateway(string GatewayId, StatusPagamento Status, string StatusOriginal,
    decimal? Taxa = null, decimal? Liquido = null, decimal ValorEstornado = 0);

public record EstornoFeito(decimal ValorEstornado, StatusPagamento Status, string? Mensagem = null);

/// <summary>Credencial em uso pelo gateway. Implementada na API, para poder vir do painel ou do ambiente.</summary>
public interface IFonteCredencialPagamento
{
    Task<(string? AccessToken, bool Sandbox)> ObterAsync(CancellationToken ct = default);
}

/// <summary>Mercado Pago: Pix, cartão e boleto + webhook de confirmação.</summary>
public interface IServicoPagamento
{
    Task<CobrancaCriada> CriarCobrancaAsync(Pedido pedido, string emailPagador, string nomePagador, MetodoPagamento metodo, CancellationToken ct = default);
    Task<AvisoPagamento?> LerAvisoAsync(string corpo, IDictionary<string, string> cabecalhos, CancellationToken ct = default);

    /// <summary>Consulta a situação de uma cobrança direto no gateway.</summary>
    Task<DetalhePagamentoGateway?> ConsultarAsync(string gatewayId, CancellationToken ct = default);

    /// <summary>Estorno total (valor nulo) ou parcial.</summary>
    Task<EstornoFeito> EstornarAsync(string gatewayId, decimal? valor, CancellationToken ct = default);

    /// <summary>Confere se a credencial responde; devolve o apelido da conta conectada.</summary>
    Task<(bool Ok, string Detalhe)> TestarConexaoAsync(CancellationToken ct = default);

    /// <summary>False quando está rodando em modo simulado.</summary>
    bool Real { get; }
}

/// <summary>E-mails transacionais: confirmação e mudança de status do pedido.</summary>
public interface IServicoEmail
{
    Task EnviarAsync(string para, string assunto, string html, CancellationToken ct = default);
}

/// <summary>Dados conferidos a partir do token de identidade devolvido pelo botão "Continuar com o Google".</summary>
public record InfoLoginGoogle(string IdentificadorGoogle, string Email, bool EmailVerificado, string Nome);

/// <summary>Confere a autenticidade do token do Google (OAuth 2.0 / Google Identity Services).</summary>
public interface IServicoLoginGoogle
{
    /// <summary>Devolve os dados do usuário quando o token é autêntico, não expirou e é desta loja; null quando é inválido.</summary>
    Task<InfoLoginGoogle?> ValidarAsync(string credencialIdToken, CancellationToken ct = default);
}

/// <summary>Armazenamento de fotos (disco local no MVP; Cloudflare R2/S3 em produção).</summary>
public interface IArmazenamentoArquivos
{
    Task<string> SalvarAsync(Stream conteudo, string nomeArquivo, string contentType, CancellationToken ct = default);

    /// <summary>Grava com um nome definido por quem chama (usado pelas versões geradas da mesma foto).</summary>
    Task<string> SalvarComNomeAsync(Stream conteudo, string nomeArquivo, CancellationToken ct = default);

    Task RemoverAsync(string url, CancellationToken ct = default);
}
