namespace LojaAmanhecer.Application.Integracoes;

/// <summary>Resultado do processamento de uma foto enviada pelo vendedor.</summary>
public record ImagemProcessada(
    string UrlOriginal,     // arquivo exatamente como veio do celular/câmera
    string UrlMiniatura,    // listas e painel
    string UrlCatalogo,     // cartões da loja (é a URL principal gravada em produto_imagens.url)
    string UrlGrande,       // página do produto
    int Largura,            // dimensões já com a orientação corrigida
    int Altura,
    string FormatoOriginal,
    long BytesOriginal,
    long BytesCatalogo);

/// <summary>
/// Recebe a foto original (inclusive HEIC do iPhone), corrige a orientação e gera
/// as versões otimizadas para web. O original nunca é alterado.
/// </summary>
/// <summary>Enquadramento escolhido no painel, em pixels da foto já com a orientação corrigida.</summary>
public record Recorte(int X, int Y, int Largura, int Altura);

public interface IProcessadorImagens
{
    /// <summary>Extensões aceitas no envio.</summary>
    IReadOnlyCollection<string> ExtensoesAceitas { get; }

    bool Aceita(string nomeArquivo, string? contentType);

    Task<ImagemProcessada> ProcessarAsync(Stream conteudo, string nomeArquivo, CancellationToken ct = default);

    /// <summary>
    /// Versão quadrada para os medalhões de categoria. Sem recorte informado, corta pelo centro.
    /// Guarda o original igual ao envio de produto.
    /// </summary>
    Task<ImagemProcessada> ProcessarQuadradoAsync(Stream conteudo, string nomeArquivo, Recorte? recorte, CancellationToken ct = default);
}
