using LojaAmanhecer.Domain.Pedidos;

namespace LojaAmanhecer.Application.Integracoes;

public record PacoteFrete(int PesoGramas, decimal AlturaCm, decimal LarguraCm, decimal ComprimentoCm, decimal ValorSeguro, int Quantidade = 1);

public record OpcaoFrete(int ServicoId, string Transportadora, string Servico, decimal Valor, int PrazoDias);

/// <summary>Melhor Envio: cotação, etiqueta e rastreio.</summary>
public interface IServicoFrete
{
    Task<IReadOnlyList<OpcaoFrete>> CotarAsync(string cepDestino, IEnumerable<PacoteFrete> pacotes, CancellationToken ct = default);
    Task<string> GerarEtiquetaAsync(Pedido pedido, CancellationToken ct = default);
    Task<string?> ObterRastreioAsync(string etiquetaId, CancellationToken ct = default);
}

public record EnderecoCep(string Cep, string Logradouro, string Bairro, string Cidade, string Uf);

/// <summary>ViaCEP: preenchimento automático do endereço.</summary>
public interface IServicoCep
{
    Task<EnderecoCep?> ConsultarAsync(string cep, CancellationToken ct = default);
}
