namespace LojaAmanhecer.Domain.Configuracoes;

/// <summary>Configurações editáveis pelo admin (chave/valor): WhatsApp, CEP de origem etc.</summary>
public class ConfiguracaoLoja
{
    public string Chave { get; set; } = "";
    public string Valor { get; set; } = "";
    public string? Descricao { get; set; }
}
