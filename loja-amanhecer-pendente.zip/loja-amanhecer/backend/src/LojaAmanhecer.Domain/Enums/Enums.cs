namespace LojaAmanhecer.Domain.Enums;

public enum StatusPedido
{
    PedidoRecebido = 1,
    AguardandoPagamento = 2,
    PagamentoConfirmado = 3,
    EmProducao = 4,
    ProntoParaEnvio = 5,
    Enviado = 6,
    Entregue = 7,
    Cancelado = 8
}

public enum TipoDisponibilidade
{
    ProntaEntrega = 1,
    SobEncomenda = 2
}

public enum MetodoPagamento
{
    Pix = 1,
    CartaoCredito = 2,
    Boleto = 3,
    Manual = 4 // transferência ou dinheiro confirmado pelo vendedor
}

public enum StatusPagamento
{
    Pendente = 1,
    Aprovado = 2,
    Recusado = 3,
    Estornado = 4,
    Expirado = 5
}

public static class Perfis
{
    public const string Administrador = "Administrador";
    public const string Vendedor = "Vendedor";
    public const string Cliente = "Cliente";
}
