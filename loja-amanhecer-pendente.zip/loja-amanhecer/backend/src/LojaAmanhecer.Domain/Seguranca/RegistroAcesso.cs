using LojaAmanhecer.Domain.Comum;

namespace LojaAmanhecer.Domain.Seguranca;

/// <summary>Toda tentativa de entrada, com ou sem sucesso, fica registrada aqui.</summary>
public class RegistroAcesso : Entidade
{
    public string Email { get; set; } = "";
    public Guid? UsuarioId { get; set; }
    public bool Sucesso { get; set; }

    /// <summary>"painel" ou "loja".</summary>
    public string Origem { get; set; } = "painel";

    /// <summary>Motivo da recusa: SenhaIncorreta, SemPermissao, ContaBloqueada, ContaInativa, UsuarioInexistente…</summary>
    public string Motivo { get; set; } = "";
    public string? Ip { get; set; }
    public string? Navegador { get; set; }
}

public static class MotivosAcesso
{
    public const string Ok = "Ok";
    public const string UsuarioInexistente = "UsuarioInexistente";
    public const string SenhaIncorreta = "SenhaIncorreta";
    public const string ContaBloqueada = "ContaBloqueada";
    public const string ContaInativa = "ContaInativa";
    public const string SemPermissao = "SemPermissao";
    public const string Saida = "Saida";
    public const string SenhaAlterada = "SenhaAlterada";
    public const string SenhaRedefinida = "SenhaRedefinida";
    public const string PrimeiroAdministrador = "PrimeiroAdministrador";
}
