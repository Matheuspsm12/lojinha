namespace LojaAmanhecer.Domain.Comum;

/// <summary>Base para entidades com identificador e datas de auditoria.</summary>
public abstract class Entidade
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public DateTime AtualizadoEm { get; set; } = DateTime.UtcNow;
}

/// <summary>Exceção para violações de regra de negócio (retorna HTTP 422 na API).</summary>
public class RegraNegocioException(string mensagem) : Exception(mensagem);
