using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace LojaAmanhecer.Domain.Comum;

public static partial class Slug
{
    /// <summary>Gera um slug para URL: "Colete de Apará" → "colete-de-apara".</summary>
    public static string Gerar(string texto)
    {
        var normalizado = texto.Trim().ToLowerInvariant().Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder();
        foreach (var c in normalizado)
            if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                sb.Append(c);
        var semAcento = sb.ToString().Normalize(NormalizationForm.FormC);
        return Hifens().Replace(NaoAlfanumerico().Replace(semAcento, "-"), "-").Trim('-');
    }

    [GeneratedRegex("[^a-z0-9]+")] private static partial Regex NaoAlfanumerico();
    [GeneratedRegex("-{2,}")] private static partial Regex Hifens();
}
