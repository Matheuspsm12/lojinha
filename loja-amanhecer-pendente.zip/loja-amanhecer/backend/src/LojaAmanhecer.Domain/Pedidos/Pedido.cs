using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Enums;

namespace LojaAmanhecer.Domain.Pedidos;

public class Pedido : Entidade
{
    /// <summary>Número sequencial gerado pelo banco (sequência pedido_numero_seq).</summary>
    public long Numero { get; set; }
    public string NumeroFormatado => $"VA-{Numero:D6}";

    public Guid ClienteId { get; set; }
    public Guid? VendedorId { get; set; }
    public DateTime? AssumidoEm { get; set; }

    public StatusPedido Status { get; private set; } = StatusPedido.PedidoRecebido;

    public decimal Subtotal { get; set; }
    public decimal ValorFrete { get; set; }
    public decimal Desconto { get; set; }
    public decimal Total => Subtotal + ValorFrete - Desconto;

    // Entrega (cópia do endereço no momento da compra)
    public EnderecoEntrega EnderecoEntrega { get; set; } = new();
    public string FormaEntrega { get; set; } = "";         // ex.: "Correios PAC", "Retirada"
    public int? ServicoFreteId { get; set; }                // id do serviço no Melhor Envio
    public int PrazoProducaoDias { get; set; }
    public int PrazoTransporteDias { get; set; }
    public int PrazoTotalDias => PrazoProducaoDias + PrazoTransporteDias;

    public string? CodigoRastreio { get; set; }
    public string? EtiquetaId { get; set; }
    public string? ObservacaoCliente { get; set; }
    public string? ObservacaoInterna { get; set; }

    public List<PedidoItem> Itens { get; set; } = [];
    public List<Pagamento> Pagamentos { get; set; } = [];
    public List<PedidoHistorico> Historico { get; set; } = [];

    /// <summary>Transições permitidas entre status.</summary>
    private static readonly Dictionary<StatusPedido, StatusPedido[]> Transicoes = new()
    {
        [StatusPedido.PedidoRecebido]      = [StatusPedido.AguardandoPagamento, StatusPedido.PagamentoConfirmado, StatusPedido.Cancelado],
        [StatusPedido.AguardandoPagamento] = [StatusPedido.PagamentoConfirmado, StatusPedido.Cancelado],
        [StatusPedido.PagamentoConfirmado] = [StatusPedido.EmProducao, StatusPedido.ProntoParaEnvio, StatusPedido.Cancelado],
        [StatusPedido.EmProducao]          = [StatusPedido.ProntoParaEnvio, StatusPedido.Cancelado],
        [StatusPedido.ProntoParaEnvio]     = [StatusPedido.Enviado, StatusPedido.Entregue, StatusPedido.Cancelado], // Entregue direto = retirada
        [StatusPedido.Enviado]             = [StatusPedido.Entregue],
        [StatusPedido.Entregue]            = [],
        [StatusPedido.Cancelado]           = []
    };

    public bool PodeMudarPara(StatusPedido novo) => Transicoes[Status].Contains(novo);

    public void AlterarStatus(StatusPedido novo, Guid? usuarioId, string? comentario = null)
    {
        if (!PodeMudarPara(novo))
            throw new RegraNegocioException($"Não é possível mudar o pedido de {Status} para {novo}.");

        if (novo == StatusPedido.Enviado && string.IsNullOrWhiteSpace(CodigoRastreio) && ServicoFreteId is not null)
            throw new RegraNegocioException("Informe o código de rastreamento antes de marcar como enviado.");

        Historico.Add(new PedidoHistorico
        {
            PedidoId = Id, StatusAnterior = Status, StatusNovo = novo,
            UsuarioId = usuarioId, Comentario = comentario
        });
        Status = novo;
        AtualizadoEm = DateTime.UtcNow;
    }

    public void Assumir(Guid vendedorId)
    {
        if (Status is StatusPedido.Cancelado or StatusPedido.Entregue)
            throw new RegraNegocioException("Pedidos finalizados não podem ser assumidos.");
        if (VendedorId is not null && VendedorId != vendedorId)
            throw new RegraNegocioException("Este pedido já foi assumido por outro vendedor.");
        VendedorId = vendedorId;
        AssumidoEm ??= DateTime.UtcNow;
    }
}

/// <summary>Endereço copiado para o pedido (não muda se o cliente editar o cadastro).</summary>
public class EnderecoEntrega
{
    public string Destinatario { get; set; } = "";
    public string Cep { get; set; } = "";
    public string Logradouro { get; set; } = "";
    public string Numero { get; set; } = "";
    public string? Complemento { get; set; }
    public string Bairro { get; set; } = "";
    public string Cidade { get; set; } = "";
    public string Uf { get; set; } = "";
}

public class PedidoItem : Entidade
{
    public Guid PedidoId { get; set; }
    public Guid ProdutoId { get; set; }
    public Guid? VariacaoId { get; set; }
    public string NomeProduto { get; set; } = "";
    public string? DescricaoVariacao { get; set; }
    public string? Personalizacao { get; set; }
    public decimal PrecoUnitario { get; set; }
    public int Quantidade { get; set; }
    public int PrazoProducaoDias { get; set; }
    public decimal Total => PrecoUnitario * Quantidade;
}

public class Pagamento : Entidade
{
    public Guid PedidoId { get; set; }
    public MetodoPagamento Metodo { get; set; }
    public StatusPagamento Status { get; set; } = StatusPagamento.Pendente;
    public decimal Valor { get; set; }
    public int Parcelas { get; set; } = 1;
    public string? GatewayId { get; set; }       // id do pagamento no Mercado Pago
    public string? GatewayStatus { get; set; }
    public DateTime? PagoEm { get; set; }
    public Guid? ConfirmadoPorId { get; set; }   // preenchido na confirmação manual

    /// <summary>Taxa cobrada pelo provedor, quando informada.</summary>
    public decimal? TaxaGateway { get; set; }

    /// <summary>Valor previsto para cair na conta (valor - taxa - estornos).</summary>
    public decimal? ValorLiquido { get; set; }
    public decimal ValorEstornado { get; set; }

    /// <summary>"teste", "producao" ou "simulado", conforme o ambiente em que a cobrança foi criada.</summary>
    public string? Ambiente { get; set; }
}

public class PedidoHistorico : Entidade
{
    public Guid PedidoId { get; set; }
    public StatusPedido StatusAnterior { get; set; }
    public StatusPedido StatusNovo { get; set; }
    public Guid? UsuarioId { get; set; }
    public string? Comentario { get; set; }
}
