using LojaAmanhecer.Domain.Comum;

namespace LojaAmanhecer.Domain.Clientes;

public class Endereco : Entidade
{
    public Guid UsuarioId { get; set; }
    public string Apelido { get; set; } = "Casa";
    public string Destinatario { get; set; } = "";
    public string Cep { get; set; } = "";
    public string Logradouro { get; set; } = "";
    public string Numero { get; set; } = "";
    public string? Complemento { get; set; }
    public string Bairro { get; set; } = "";
    public string Cidade { get; set; } = "";
    public string Uf { get; set; } = "";
    public bool Principal { get; set; }
}
