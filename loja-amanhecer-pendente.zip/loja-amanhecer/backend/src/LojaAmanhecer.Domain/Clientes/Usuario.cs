using Microsoft.AspNetCore.Identity;

namespace LojaAmanhecer.Domain.Clientes;

/// <summary>Usuário da plataforma (cliente, vendedor ou administrador).</summary>
public class Usuario : IdentityUser<Guid>
{
    public string NomeCompleto { get; set; } = "";
    public string? Cpf { get; set; }
    public DateOnly? DataNascimento { get; set; }
    public bool Ativo { get; set; } = true;

    /// <summary>True quando a senha foi definida pela instalação e precisa ser trocada no primeiro acesso.</summary>
    public bool DeveTrocarSenha { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;

    public List<Endereco> Enderecos { get; set; } = [];
}
