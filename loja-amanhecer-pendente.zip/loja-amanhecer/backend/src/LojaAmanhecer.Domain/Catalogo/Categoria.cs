using LojaAmanhecer.Domain.Comum;

namespace LojaAmanhecer.Domain.Catalogo;

/// <summary>Categoria da loja. Subcategorias usam CategoriaPaiId.</summary>
public class Categoria : Entidade
{
    public string Nome { get; set; } = "";
    public string Slug { get; set; } = "";
    public string? Descricao { get; set; }
    /// <summary>Foto do medalhão exibido na loja (versão otimizada). Nula = usa a ilustração padrão.</summary>
    public string? ImagemUrl { get; set; }
    public string? ImagemMiniaturaUrl { get; set; }   // listas e painel
    public string? ImagemOriginalUrl { get; set; }    // arquivo como veio do celular

    /// <summary>True quando a categoria tem foto própria; senão a loja usa a ilustração padrão.</summary>
    public bool TemFoto => !string.IsNullOrWhiteSpace(ImagemUrl);
    public int Ordem { get; set; }
    public bool Ativa { get; set; } = true;

    public Guid? CategoriaPaiId { get; set; }
    public Categoria? CategoriaPai { get; set; }
    public List<Categoria> Subcategorias { get; set; } = [];
    public List<Produto> Produtos { get; set; } = [];
}
