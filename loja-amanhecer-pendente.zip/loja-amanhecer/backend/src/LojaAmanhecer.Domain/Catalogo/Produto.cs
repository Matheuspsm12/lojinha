using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Enums;

namespace LojaAmanhecer.Domain.Catalogo;

public class Produto : Entidade
{
    public string Nome { get; set; } = "";
    public string Slug { get; set; } = "";
    public string Descricao { get; set; } = "";

    /// <summary>Categoria mais específica (pode ser subcategoria).</summary>
    public Guid CategoriaId { get; set; }
    public Categoria? Categoria { get; set; }

    public decimal Preco { get; set; }

    /// <summary>Estoque usado quando o produto não possui variações.</summary>
    public int Estoque { get; set; }

    // Dados para cálculo de frete (Melhor Envio)
    public int PesoGramas { get; set; }
    public decimal AlturaCm { get; set; }
    public decimal LarguraCm { get; set; }
    public decimal ComprimentoCm { get; set; }

    public TipoDisponibilidade Disponibilidade { get; set; } = TipoDisponibilidade.ProntaEntrega;
    public int PrazoProducaoDias { get; set; }

    // Personalização (ex.: nome bordado)
    public bool PermitePersonalizacao { get; set; }
    public string? RotuloPersonalizacao { get; set; }
    public int? LimiteCaracteresPersonalizacao { get; set; }
    public decimal ValorPersonalizacao { get; set; }

    public bool Ativo { get; set; } = true;
    public bool Destaque { get; set; }

    public List<ProdutoImagem> Imagens { get; set; } = [];
    public List<ProdutoOpcao> Opcoes { get; set; } = [];
    public List<ProdutoVariacao> Variacoes { get; set; } = [];

    public bool PossuiVariacoes => Variacoes.Count > 0;

    public int EstoqueTotal => PossuiVariacoes
        ? Variacoes.Where(v => v.Ativa).Sum(v => v.Estoque)
        : Estoque;

    /// <summary>
    /// Prazo de produção efetivo para uma quantidade: sob encomenda sempre usa o prazo;
    /// pronta entrega só usa o prazo quando a quantidade pedida ultrapassa o estoque.
    /// </summary>
    public int PrazoProducaoPara(int quantidade, ProdutoVariacao? variacao = null)
    {
        if (Disponibilidade == TipoDisponibilidade.SobEncomenda) return PrazoProducaoDias;
        var estoque = variacao?.Estoque ?? Estoque;
        return quantidade <= estoque ? 0 : PrazoProducaoDias;
    }

    public decimal PrecoPara(ProdutoVariacao? variacao) => variacao?.Preco ?? Preco;
}

public class ProdutoImagem : Entidade
{
    public Guid ProdutoId { get; set; }

    /// <summary>Versão usada nos cartões da loja (mantida como URL principal).</summary>
    public string Url { get; set; } = "";
    public string? TextoAlternativo { get; set; }
    public int Ordem { get; set; }

    // Versões geradas automaticamente no envio (nulas nas fotos enviadas antes desta melhoria)
    public string? UrlOriginal { get; set; }    // arquivo como veio do celular
    public string? UrlMiniatura { get; set; }   // listas e painel
    public string? UrlGrande { get; set; }      // página do produto
    public int? Largura { get; set; }
    public int? Altura { get; set; }

    /// <summary>Melhor versão disponível para cada uso, caindo para a URL principal nas fotos antigas.</summary>
    public string Miniatura => UrlMiniatura ?? Url;
    public string Grande => UrlGrande ?? Url;
}

/// <summary>Tipo de opção do produto: Tamanho, Cor, Povo, Falange...</summary>
public class ProdutoOpcao : Entidade
{
    public Guid ProdutoId { get; set; }
    public string Nome { get; set; } = "";
    public int Ordem { get; set; }
    public List<string> Valores { get; set; } = [];
}

/// <summary>Combinação vendável de opções, com estoque e preço próprios.</summary>
public class ProdutoVariacao : Entidade
{
    public Guid ProdutoId { get; set; }
    public string? Sku { get; set; }

    /// <summary>Ex.: { "Tamanho": "M", "Falange": "Magos" } — armazenado em jsonb.</summary>
    public Dictionary<string, string> Atributos { get; set; } = [];

    /// <summary>Preço específico; nulo usa o preço do produto.</summary>
    public decimal? Preco { get; set; }
    public int Estoque { get; set; }
    public bool Ativa { get; set; } = true;

    public string Descricao => string.Join(" / ", Atributos.Select(a => $"{a.Key}: {a.Value}"));
}
