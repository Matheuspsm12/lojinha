namespace LojaAmanhecer.Domain.Servicos;

/// <summary>
/// Regra aprovada: prazo exibido ao cliente = prazo de produção + prazo de transporte.
/// Os itens são produzidos em paralelo, então vale o MAIOR prazo de produção do carrinho.
/// </summary>
public static class CalculadoraPrazo
{
    public static int PrazoProducao(IEnumerable<int> prazosItens) =>
        prazosItens.DefaultIfEmpty(0).Max();

    public static int PrazoTotal(IEnumerable<int> prazosItens, int prazoTransporteDias) =>
        PrazoProducao(prazosItens) + prazoTransporteDias;
}
