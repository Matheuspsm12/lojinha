using LojaAmanhecer.Domain.Seguranca;
using LojaAmanhecer.Infrastructure.Dados;

namespace LojaAmanhecer.Api.Seguranca;

/// <summary>Grava no banco toda tentativa de entrada, com ou sem sucesso.</summary>
public class ServicoAcesso(LojaDbContext db, IHttpContextAccessor acessor, ILogger<ServicoAcesso> log)
{
    public async Task RegistrarAsync(string email, bool sucesso, string motivo, string origem = "painel", Guid? usuarioId = null)
    {
        var ctx = acessor.HttpContext;
        var registro = new RegistroAcesso
        {
            Email = (email ?? "").Trim().ToLowerInvariant(),
            UsuarioId = usuarioId,
            Sucesso = sucesso,
            Motivo = motivo,
            Origem = origem,
            Ip = ctx?.Connection.RemoteIpAddress?.ToString(),
            Navegador = ctx?.Request.Headers.UserAgent.ToString() is { Length: > 0 } ua ? ua[..Math.Min(ua.Length, 300)] : null
        };
        db.RegistrosAcesso.Add(registro);
        await db.SaveChangesAsync();

        if (sucesso) log.LogInformation("Entrada no {Origem}: {Email}", origem, registro.Email);
        else log.LogWarning("Tentativa recusada no {Origem}: {Email} ({Motivo})", origem, registro.Email, motivo);
    }
}
