using System.Security.Claims;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Seguranca;

/// <summary>
/// Quem pode entrar no painel. Hoje a lista tem apenas Administrador, mas ela vem da configuração
/// Painel:PerfisPermitidos — basta acrescentar "Vendedor" ali para liberar os vendedores no futuro,
/// sem mexer em código. A estrutura de vendedores continua inteira no banco e na API.
/// </summary>
public class AcessoPainelRequirement : IAuthorizationRequirement;

public class AcessoPainelHandler(LojaDbContext db, IConfiguration config, IHttpContextAccessor contexto)
    : AuthorizationHandler<AcessoPainelRequirement>
{
    public static string[] PerfisPermitidos(IConfiguration config) =>
        config.GetSection("Painel:PerfisPermitidos").Get<string[]>() ?? [Perfis.Administrador];

    protected override async Task HandleRequirementAsync(AuthorizationHandlerContext ctx, AcessoPainelRequirement requisito)
    {
        var usuario = ctx.User;
        if (usuario.Identity?.IsAuthenticated != true) return;

        var permitidos = PerfisPermitidos(config);
        if (!usuario.Claims.Any(c => c.Type == ClaimTypes.Role && permitidos.Contains(c.Value)))
        {
            Recusar(ctx, "Acesso não autorizado");
            return;
        }

        if (!Guid.TryParse(usuario.FindFirstValue(ClaimTypes.NameIdentifier), out var id)) return;

        // Confere no banco: conta desativada ou senha trocada invalidam o token em uso
        var conta = await db.Users.AsNoTracking()
            .Where(u => u.Id == id)
            .Select(u => new { u.Ativo, u.SecurityStamp })
            .FirstOrDefaultAsync();

        if (conta is null || !conta.Ativo) { Recusar(ctx, "Acesso não autorizado"); return; }

        var carimbo = usuario.FindFirstValue(ClaimsPainel.Carimbo);
        if (!string.IsNullOrEmpty(conta.SecurityStamp) && carimbo != conta.SecurityStamp)
        {
            Recusar(ctx, "Sessão encerrada. Entre novamente.");
            return;
        }

        ctx.Succeed(requisito);
    }

    private void Recusar(AuthorizationHandlerContext ctx, string mensagem)
    {
        if (contexto.HttpContext is not null) contexto.HttpContext.Items["motivoRecusa"] = mensagem;
        ctx.Fail(new AuthorizationFailureReason(this, mensagem));
    }
}

public static class ClaimsPainel
{
    /// <summary>Carimbo de segurança do usuário; muda ao trocar a senha ou ao sair de todos os aparelhos.</summary>
    public const string Carimbo = "carimbo";
}
