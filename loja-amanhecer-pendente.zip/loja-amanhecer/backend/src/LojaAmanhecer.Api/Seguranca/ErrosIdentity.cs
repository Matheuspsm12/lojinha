using Microsoft.AspNetCore.Identity;

namespace LojaAmanhecer.Api.Seguranca;

/// <summary>Traduz as mensagens do ASP.NET Identity, que vêm em inglês.</summary>
public static class ErrosIdentity
{
    private static readonly Dictionary<string, string> Mensagens = new()
    {
        ["DefaultError"] = "Não foi possível concluir a operação.",
        ["DuplicateEmail"] = "Já existe uma conta com este e-mail.",
        ["DuplicateUserName"] = "Já existe uma conta com este e-mail.",
        ["InvalidEmail"] = "Informe um e-mail válido.",
        ["InvalidToken"] = "Link inválido ou expirado. Peça um novo.",
        ["PasswordMismatch"] = "Senha atual incorreta.",
        ["PasswordRequiresDigit"] = "A senha precisa ter pelo menos um número.",
        ["PasswordRequiresLower"] = "A senha precisa ter pelo menos uma letra minúscula.",
        ["PasswordRequiresUpper"] = "A senha precisa ter pelo menos uma letra maiúscula.",
        ["PasswordRequiresNonAlphanumeric"] = "A senha precisa ter pelo menos um símbolo.",
        ["PasswordRequiresUniqueChars"] = "A senha precisa ter caracteres mais variados.",
        ["PasswordTooShort"] = "A senha precisa ter pelo menos 8 caracteres.",
        ["UserAlreadyHasPassword"] = "Esta conta já tem senha cadastrada.",
        ["UserLockedOut"] = "Conta bloqueada temporariamente. Tente novamente em alguns minutos."
    };

    public static string Traduzir(IEnumerable<IdentityError> erros) =>
        string.Join(" ", erros.Select(e => Mensagens.GetValueOrDefault(e.Code, e.Description)).Distinct());
}
