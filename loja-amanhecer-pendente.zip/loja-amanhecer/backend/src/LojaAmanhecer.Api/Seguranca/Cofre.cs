using System.Security.Cryptography;
using System.Text;

namespace LojaAmanhecer.Api.Seguranca;

/// <summary>
/// Guarda segredos (como o Access Token do Mercado Pago) cifrados com AES-GCM.
/// A chave vem de Seguranca:ChaveCriptografia; sem ela, é derivada da chave do JWT.
/// O texto cifrado pode ficar no banco: sem a chave do servidor, não serve para nada.
/// </summary>
public class Cofre(IConfiguration config)
{
    private byte[] Chave()
    {
        var material = config["Seguranca:ChaveCriptografia"];
        if (string.IsNullOrWhiteSpace(material)) material = config["Jwt:Chave"] + "|cofre";
        return SHA256.HashData(Encoding.UTF8.GetBytes(material));
    }

    public string Cifrar(string texto)
    {
        var nonce = RandomNumberGenerator.GetBytes(12);
        var dados = Encoding.UTF8.GetBytes(texto);
        var cifrado = new byte[dados.Length];
        var marca = new byte[16];
        using var aes = new AesGcm(Chave(), 16);
        aes.Encrypt(nonce, dados, cifrado, marca);
        return $"v1.{Convert.ToBase64String(nonce)}.{Convert.ToBase64String(cifrado)}.{Convert.ToBase64String(marca)}";
    }

    public string? Decifrar(string? guardado)
    {
        if (string.IsNullOrWhiteSpace(guardado)) return null;
        var partes = guardado.Split('.');
        if (partes.Length != 4 || partes[0] != "v1") return null;
        try
        {
            var nonce = Convert.FromBase64String(partes[1]);
            var cifrado = Convert.FromBase64String(partes[2]);
            var marca = Convert.FromBase64String(partes[3]);
            var dados = new byte[cifrado.Length];
            using var aes = new AesGcm(Chave(), 16);
            aes.Decrypt(nonce, cifrado, marca, dados);
            return Encoding.UTF8.GetString(dados);
        }
        catch (CryptographicException) { return null; }   // chave trocada ou dado corrompido
    }

    /// <summary>Forma segura de mostrar uma credencial na tela: só o prefixo e os 4 últimos.</summary>
    public static string Mascarar(string? token)
    {
        if (string.IsNullOrWhiteSpace(token)) return "";
        var limpo = token.Trim();
        var prefixo = limpo.StartsWith("APP_USR-") ? "APP_USR-" : limpo.StartsWith("TEST-") ? "TEST-" : "";
        var fim = limpo.Length >= 4 ? limpo[^4..] : "****";
        return $"{prefixo}••••••••{fim}";
    }
}
