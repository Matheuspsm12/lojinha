using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Configuracoes;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Controllers.Admin;

public record AparenciaDto(string? BannerUrl, string? BannerMediaUrl, string? BannerOriginalUrl, bool UsandoPadrao);

/// <summary>
/// Imagem do banner da página inicial. A arte que veio com a loja é o padrão;
/// o administrador pode trocar por outra a qualquer momento, sem mexer em código.
/// </summary>
[ApiController]
[Route("api/admin/aparencia")]
[Authorize(Policy = Politicas.Administrador)]
public class AparenciaAdminController(
    LojaDbContext db, IProcessadorImagens imagens, IArmazenamentoArquivos arquivos,
    IConfiguration configuracao, ILogger<AparenciaAdminController> log) : ControllerBase
{
    public const string ChaveBanner = "loja.banner_url";
    public const string ChaveBannerMedia = "loja.banner_url_media";
    public const string ChaveBannerOriginal = "loja.banner_original_url";

    [HttpGet]
    public async Task<AparenciaDto> Obter() => await MontarAsync();

    /// <summary>
    /// Envia a arte do banner. Aceita os mesmos formatos das fotos de produto (inclusive HEIC),
    /// corrige a orientação e gera as versões otimizadas, mantendo a proporção original.
    /// </summary>
    [HttpPost("banner")]
    [RequestSizeLimit(long.MaxValue)]
    [RequestFormLimits(MultipartBodyLengthLimit = long.MaxValue)]
    public async Task<ActionResult<AparenciaDto>> EnviarBanner(IFormFile arte, CancellationToken ct)
    {
        if (arte is null || arte.Length == 0) throw new RegraNegocioException("Selecione a imagem do banner.");
        var limiteMb = configuracao.GetValue("Imagens:TamanhoMaximoMb", 60);
        if (arte.Length > limiteMb * 1024L * 1024L)
            throw new RegraNegocioException($"A imagem tem {arte.Length / 1048576.0:F0} MB e passa do limite de {limiteMb} MB.");
        if (!imagens.Aceita(arte.FileName, arte.ContentType))
            throw new RegraNegocioException("Formato não aceito. Use JPG, PNG, WEBP, AVIF ou HEIC.");

        var anteriores = await UrlsAtuaisAsync();

        await using var conteudo = arte.OpenReadStream();
        var r = await imagens.ProcessarAsync(conteudo, arte.FileName, ct);   // mantém a proporção, só reduz

        await GravarAsync(ChaveBanner, r.UrlGrande, "Banner da página inicial (versão grande)");
        await GravarAsync(ChaveBannerMedia, r.UrlCatalogo, "Banner da página inicial (versão para celular)");
        await GravarAsync(ChaveBannerOriginal, r.UrlOriginal, "Banner da página inicial (arquivo original)");
        await db.SaveChangesAsync(ct);

        foreach (var url in anteriores.Where(u => !string.IsNullOrWhiteSpace(u))) await arquivos.RemoverAsync(url!, ct);
        log.LogInformation("Banner da página inicial trocado ({L}x{A})", r.Largura, r.Altura);
        return await MontarAsync();
    }

    /// <summary>Remove a arte enviada: a loja volta ao banner que veio na instalação.</summary>
    [HttpDelete("banner")]
    public async Task<AparenciaDto> RemoverBanner(CancellationToken ct)
    {
        var anteriores = await UrlsAtuaisAsync();
        foreach (var chave in new[] { ChaveBanner, ChaveBannerMedia, ChaveBannerOriginal }) await GravarAsync(chave, "");
        await db.SaveChangesAsync(ct);
        foreach (var url in anteriores.Where(u => !string.IsNullOrWhiteSpace(u))) await arquivos.RemoverAsync(url!, ct);
        return await MontarAsync();
    }

    private async Task<string?[]> UrlsAtuaisAsync()
    {
        var atuais = await db.Configuracoes.AsNoTracking()
            .Where(c => c.Chave == ChaveBanner || c.Chave == ChaveBannerMedia || c.Chave == ChaveBannerOriginal)
            .ToDictionaryAsync(c => c.Chave, c => c.Valor);
        return [atuais.GetValueOrDefault(ChaveBanner), atuais.GetValueOrDefault(ChaveBannerMedia), atuais.GetValueOrDefault(ChaveBannerOriginal)];
    }

    private async Task GravarAsync(string chave, string valor, string? descricao = null)
    {
        var atual = await db.Configuracoes.FirstOrDefaultAsync(c => c.Chave == chave);
        if (atual is null) db.Configuracoes.Add(new ConfiguracaoLoja { Chave = chave, Valor = valor, Descricao = descricao });
        else atual.Valor = valor;
    }

    private async Task<AparenciaDto> MontarAsync()
    {
        var urls = await UrlsAtuaisAsync();
        return new AparenciaDto(Vazio(urls[0]), Vazio(urls[1]), Vazio(urls[2]), string.IsNullOrWhiteSpace(urls[0]));
    }

    private static string? Vazio(string? v) => string.IsNullOrWhiteSpace(v) ? null : v;
}

/// <summary>O que a loja precisa saber para montar a página inicial.</summary>
[ApiController]
[Route("api/loja")]
public class AparenciaController(LojaDbContext db) : ControllerBase
{
    [HttpGet("aparencia")]
    public async Task<AparenciaDto> Aparencia()
    {
        var valores = await db.Configuracoes.AsNoTracking()
            .Where(c => c.Chave.StartsWith("loja.banner"))
            .ToDictionaryAsync(c => c.Chave, c => c.Valor);
        string? V(string chave) => valores.GetValueOrDefault(chave) is { Length: > 0 } v ? v : null;
        // sem arte enviada, o frontend usa o banner que veio na instalação
        return new AparenciaDto(V(AparenciaAdminController.ChaveBanner), V(AparenciaAdminController.ChaveBannerMedia), null,
            V(AparenciaAdminController.ChaveBanner) is null);
    }
}
