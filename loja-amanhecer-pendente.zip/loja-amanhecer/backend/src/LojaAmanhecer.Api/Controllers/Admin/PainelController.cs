using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Controllers.Admin;

[ApiController]
[Route("api/admin/painel")]
[Authorize(Policy = Politicas.Equipe)]
public class PainelController(LojaDbContext db) : ControllerBase
{
    /// <summary>Números do painel inicial.</summary>
    [HttpGet("resumo")]
    public async Task<PainelResumoDto> Resumo()
    {
        var inicioMes = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1, 0, 0, 0, DateTimeKind.Utc);
        var alerta = int.TryParse((await db.Configuracoes.FindAsync("estoque.alerta_minimo"))?.Valor, out var a) ? a : 3;

        var porStatus = await db.Pedidos.GroupBy(p => p.Status)
            .Select(g => new { g.Key, Qtd = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.Qtd);
        int Qtd(StatusPedido s) => porStatus.GetValueOrDefault(s);

        var pagosMes = db.Pedidos.Where(p => p.CriadoEm >= inicioMes && p.Status != StatusPedido.Cancelado
            && p.Status != StatusPedido.PedidoRecebido && p.Status != StatusPedido.AguardandoPagamento);

        return new PainelResumoDto(
            PedidosNovos: await db.Pedidos.CountAsync(p => p.VendedorId == null && p.Status != StatusPedido.Cancelado),
            AguardandoPagamento: Qtd(StatusPedido.AguardandoPagamento),
            EmProducao: Qtd(StatusPedido.EmProducao),
            Enviados: Qtd(StatusPedido.Enviado),
            VendasMes: await pagosMes.SumAsync(p => p.Subtotal + p.ValorFrete - p.Desconto),
            PedidosMes: await pagosMes.CountAsync(),
            ProdutosAtivos: await db.Produtos.CountAsync(p => p.Ativo),
            ProdutosEstoqueBaixo: await db.Produtos.CountAsync(p => p.Ativo && p.Disponibilidade == TipoDisponibilidade.ProntaEntrega
                && (p.Variacoes.Any() ? p.Variacoes.Sum(v => v.Estoque) : p.Estoque) <= alerta));
    }
}
