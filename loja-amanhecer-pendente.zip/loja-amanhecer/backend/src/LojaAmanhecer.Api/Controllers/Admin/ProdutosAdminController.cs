using ClosedXML.Excel;
using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Catalogo;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Controllers.Admin;

[ApiController]
[Route("api/admin/produtos")]
[Authorize(Policy = Politicas.Equipe)]
public class ProdutosAdminController(
    LojaDbContext db, IArmazenamentoArquivos arquivos, IProcessadorImagens imagens,
    IConfiguration configuracao, LojaAmanhecer.Api.Seguranca.ServicoAcesso acessos,
    ILogger<ProdutosAdminController> log) : ControllerBase
{
    [HttpGet]
    public async Task<PaginaDto<ProdutoResumoDto>> Listar([FromQuery] string? busca, [FromQuery] Guid? categoriaId,
        [FromQuery] bool? ativo, [FromQuery] int pagina = 1, [FromQuery] int tamanho = 50)
    {
        var q = db.Produtos.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(busca)) q = q.Where(p => EF.Functions.ILike(p.Nome, $"%{busca}%"));
        if (categoriaId is not null) q = q.Where(p => p.CategoriaId == categoriaId || p.Categoria!.CategoriaPaiId == categoriaId);
        if (ativo is not null) q = q.Where(p => p.Ativo == ativo);

        var total = await q.CountAsync();
        var itens = await q.OrderBy(p => p.Nome).Skip((pagina - 1) * tamanho).Take(tamanho)
            .Select(p => new ProdutoResumoDto(p.Id, p.Nome, p.Slug, p.Categoria!.Nome, p.Preco,
                p.Imagens.OrderBy(i => i.Ordem).Select(i => i.Url).FirstOrDefault(),
                p.Disponibilidade, p.PrazoProducaoDias,
                p.Variacoes.Any() ? p.Variacoes.Where(v => v.Ativa).Sum(v => v.Estoque) : p.Estoque,
                p.Ativo, p.Destaque, null))   // o painel não usa a lista de fotos
            .ToListAsync();
        return new PaginaDto<ProdutoResumoDto>(itens, pagina, tamanho, total);
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<ProdutoDetalheDto>> Obter(Guid id)
    {
        var p = await CarregarAsync(id, rastrear: false);
        return p is null ? NotFound() : p.ParaDetalhe();
    }

    [HttpPost]
    public async Task<ActionResult<ProdutoDetalheDto>> Criar(SalvarProdutoDto dto)
    {
        Validar(dto);
        var p = new Produto();
        await AplicarAsync(p, dto);
        p.Slug = await SlugUnicoAsync(dto.Nome, null);
        db.Produtos.Add(p);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(Obter), new { id = p.Id }, (await CarregarAsync(p.Id, false))!.ParaDetalhe());
    }

    [HttpPut("{id:guid}")]
    public async Task<ActionResult<ProdutoDetalheDto>> Atualizar(Guid id, SalvarProdutoDto dto)
    {
        Validar(dto);
        var p = await CarregarAsync(id, rastrear: true);
        if (p is null) return NotFound();
        await AplicarAsync(p, dto);
        await db.SaveChangesAsync();
        return (await CarregarAsync(id, false))!.ParaDetalhe();
    }

    /// <summary>Ativa ou inativa sem abrir o formulário.</summary>
    [HttpPatch("{id:guid}/ativo")]
    public async Task<IActionResult> AlterarAtivo(Guid id, [FromQuery] bool ativo)
    {
        var n = await db.Produtos.Where(p => p.Id == id)
            .ExecuteUpdateAsync(s => s.SetProperty(p => p.Ativo, ativo).SetProperty(p => p.AtualizadoEm, DateTime.UtcNow));
        return n == 0 ? NotFound() : NoContent();
    }

    /// <summary>
    /// Envia uma ou mais fotos direto do celular ou do computador (JPG, JPEG, PNG, WEBP, AVIF e HEIC/HEIF).
    /// O original é guardado como veio; a orientação é corrigida e as versões de miniatura,
    /// catálogo e página do produto são geradas automaticamente em WebP/AVIF.
    /// </summary>
    [HttpPost("{id:guid}/imagens")]
    [RequestSizeLimit(long.MaxValue)]
    [RequestFormLimits(MultipartBodyLengthLimit = long.MaxValue)]
    public async Task<ActionResult<List<ProdutoImagemDto>>> EnviarImagens(Guid id, [FromForm] List<IFormFile> fotos, CancellationToken ct)
    {
        var p = await db.Produtos.Include(x => x.Imagens).FirstOrDefaultAsync(x => x.Id == id, ct);
        if (p is null) return NotFound();
        if (fotos is null || fotos.Count == 0) throw new RegraNegocioException("Selecione pelo menos uma foto.");

        var limiteMb = configuracao.GetValue("Imagens:TamanhoMaximoMb", 40);
        var ordem = p.Imagens.Count == 0 ? 0 : p.Imagens.Max(i => i.Ordem) + 1;

        foreach (var f in fotos)
        {
            if (f.Length > limiteMb * 1024L * 1024L)
                throw new RegraNegocioException($"A foto {f.FileName} tem {f.Length / 1048576.0:F0} MB e passa do limite de {limiteMb} MB.");
            if (!imagens.Aceita(f.FileName, f.ContentType))
                throw new RegraNegocioException($"O arquivo {f.FileName} não é uma imagem aceita. Use JPG, PNG, WEBP, AVIF ou HEIC.");

            await using var conteudo = f.OpenReadStream();
            var r = await imagens.ProcessarAsync(conteudo, f.FileName, ct);
            db.ProdutoImagens.Add(new ProdutoImagem
            {
                ProdutoId = id, Url = r.UrlCatalogo, TextoAlternativo = p.Nome, Ordem = ordem++,
                UrlOriginal = r.UrlOriginal, UrlMiniatura = r.UrlMiniatura, UrlGrande = r.UrlGrande,
                Largura = r.Largura, Altura = r.Altura
            });
        }
        await db.SaveChangesAsync(ct);

        var lista = await db.ProdutoImagens.Where(i => i.ProdutoId == id).OrderBy(i => i.Ordem).ToListAsync(ct);
        return lista.Select(i => i.ParaDto()).ToList();
    }

    /// <summary>Define a ordem das fotos; a primeira é a foto principal.</summary>
    [HttpPut("{id:guid}/imagens/ordem")]
    [Authorize(Policy = Politicas.Administrador)]
    public async Task<IActionResult> OrdenarImagens(Guid id, List<Guid> idsNaOrdem)
    {
        var imgs = await db.ProdutoImagens.Where(i => i.ProdutoId == id).ToListAsync();
        if (imgs.Count == 0) return NotFound();
        foreach (var img in imgs) img.Ordem = idsNaOrdem.IndexOf(img.Id) is var i and >= 0 ? i : 999;
        Renumerar(imgs.OrderBy(i => i.Ordem).ToList());
        await db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Escolhe qual foto é a capa do produto; as outras continuam na mesma sequência.</summary>
    [HttpPatch("{id:guid}/imagens/{imagemId:guid}/principal")]
    [Authorize(Policy = Politicas.Administrador)]
    public async Task<ActionResult<List<ProdutoImagemDto>>> DefinirPrincipal(Guid id, Guid imagemId)
    {
        var imgs = await db.ProdutoImagens.Where(i => i.ProdutoId == id).OrderBy(i => i.Ordem).ToListAsync();
        var escolhida = imgs.FirstOrDefault(i => i.Id == imagemId);
        if (escolhida is null) return NotFound();

        imgs.Remove(escolhida);
        imgs.Insert(0, escolhida);
        Renumerar(imgs);
        await db.SaveChangesAsync();

        log.LogInformation("Foto {Foto} virou a capa do produto {Produto} (por {Usuario})", imagemId, id, User.EmailUsuario());
        return imgs.Select(i => i.ParaDto()).ToList();
    }

    /// <summary>
    /// Troca o arquivo de uma foto já cadastrada, mantendo a posição dela na galeria.
    /// As versões antigas saem do armazenamento (disco local ou S3).
    /// </summary>
    [HttpPost("{id:guid}/imagens/{imagemId:guid}/substituir")]
    [Authorize(Policy = Politicas.Administrador)]
    [RequestSizeLimit(long.MaxValue)]
    [RequestFormLimits(MultipartBodyLengthLimit = long.MaxValue)]
    public async Task<ActionResult<List<ProdutoImagemDto>>> SubstituirImagem(Guid id, Guid imagemId, IFormFile foto, CancellationToken ct)
    {
        var produto = await db.Produtos.FirstOrDefaultAsync(p => p.Id == id, ct);
        if (produto is null) return NotFound();
        var img = await db.ProdutoImagens.FirstOrDefaultAsync(i => i.Id == imagemId && i.ProdutoId == id, ct);
        if (img is null) return NotFound();
        if (foto is null || foto.Length == 0) throw new RegraNegocioException("Selecione a foto que vai substituir a atual.");

        var limiteMb = configuracao.GetValue("Imagens:TamanhoMaximoMb", 60);
        if (foto.Length > limiteMb * 1024L * 1024L)
            throw new RegraNegocioException($"A foto {foto.FileName} tem {foto.Length / 1048576.0:F0} MB e passa do limite de {limiteMb} MB.");
        if (!imagens.Aceita(foto.FileName, foto.ContentType))
            throw new RegraNegocioException($"O arquivo {foto.FileName} não é uma imagem aceita. Use JPG, PNG, WEBP, AVIF ou HEIC.");

        var antigas = ArquivosDe(img);

        await using var conteudo = foto.OpenReadStream();
        var r = await imagens.ProcessarAsync(conteudo, foto.FileName, ct);
        img.Url = r.UrlCatalogo; img.UrlMiniatura = r.UrlMiniatura; img.UrlGrande = r.UrlGrande;
        img.UrlOriginal = r.UrlOriginal; img.Largura = r.Largura; img.Altura = r.Altura;
        img.TextoAlternativo ??= produto.Nome;
        await db.SaveChangesAsync(ct);

        await ApagarArquivosAsync(antigas, ct);
        await acessos.RegistrarAsync(User.EmailUsuario(), true, "FotoSubstituida", "painel", User.UsuarioId());
        log.LogInformation("Foto {Foto} do produto {Produto} substituída por {Usuario}", imagemId, id, User.EmailUsuario());

        return (await db.ProdutoImagens.Where(i => i.ProdutoId == id).OrderBy(i => i.Ordem).ToListAsync(ct))
            .Select(i => i.ParaDto()).ToList();
    }

    /// <summary>
    /// Exclui uma foto do produto. Só sai essa foto: o produto e as outras imagens continuam como estavam.
    /// Se a excluída era a capa, a próxima da fila assume. Os arquivos gerados também são apagados
    /// do armazenamento (disco local ou S3), para não deixar arquivo abandonado.
    /// </summary>
    [HttpDelete("{id:guid}/imagens/{imagemId:guid}")]
    [Authorize(Policy = Politicas.Administrador)]
    public async Task<ActionResult<List<ProdutoImagemDto>>> RemoverImagem(Guid id, Guid imagemId, CancellationToken ct)
    {
        var imgs = await db.ProdutoImagens.Where(i => i.ProdutoId == id).OrderBy(i => i.Ordem).ToListAsync(ct);
        var img = imgs.FirstOrDefault(i => i.Id == imagemId);
        if (img is null) return NotFound();

        var eraCapa = imgs[0].Id == img.Id;
        var arquivosAntigos = ArquivosDe(img);

        db.ProdutoImagens.Remove(img);
        imgs.Remove(img);
        Renumerar(imgs);                      // a próxima foto vira a capa automaticamente
        await db.SaveChangesAsync(ct);

        await ApagarArquivosAsync(arquivosAntigos, ct);
        await acessos.RegistrarAsync(User.EmailUsuario(), true, "FotoRemovida", "painel", User.UsuarioId());
        log.LogInformation("Foto {Foto} do produto {Produto} excluída por {Usuario}{Capa}",
            imagemId, id, User.EmailUsuario(), eraCapa ? " (era a capa)" : "");

        return imgs.Select(i => i.ParaDto()).ToList();
    }

    // ---------- apoio das fotos ----------

    private static string?[] ArquivosDe(ProdutoImagem img) => [img.Url, img.UrlMiniatura, img.UrlGrande, img.UrlOriginal];

    /// <summary>Numera as fotos de 0 em diante, na ordem em que estão na lista.</summary>
    private static void Renumerar(List<ProdutoImagem> imagens)
    {
        for (var i = 0; i < imagens.Count; i++) imagens[i].Ordem = i;
    }

    private async Task ApagarArquivosAsync(IEnumerable<string?> urls, CancellationToken ct)
    {
        foreach (var url in urls.Where(u => !string.IsNullOrWhiteSpace(u)))
        {
            try { await arquivos.RemoverAsync(url!, ct); }
            catch (Exception ex) { log.LogWarning(ex, "Não foi possível apagar o arquivo {Url}", url); }
        }
    }

    /// <summary>Exporta o catálogo para Excel.</summary>
    [HttpGet("exportar")]
    public async Task<IActionResult> Exportar()
    {
        var produtos = await db.Produtos.AsNoTracking().Include(p => p.Categoria).Include(p => p.Variacoes)
            .OrderBy(p => p.Categoria!.Nome).ThenBy(p => p.Nome).ToListAsync();

        using var wb = new XLWorkbook();
        var ws = wb.AddWorksheet("Produtos");
        string[] cab = ["Nome", "Categoria", "Preço", "Estoque", "Disponibilidade", "Prazo produção (dias)", "Peso (g)", "A x L x C (cm)", "Variações", "Ativo"];
        for (var i = 0; i < cab.Length; i++) ws.Cell(1, i + 1).Value = cab[i];

        var linha = 2;
        foreach (var p in produtos)
        {
            ws.Cell(linha, 1).Value = p.Nome;
            ws.Cell(linha, 2).Value = p.Categoria?.Nome;
            ws.Cell(linha, 3).Value = p.Preco;
            ws.Cell(linha, 3).Style.NumberFormat.Format = "R$ #,##0.00";
            ws.Cell(linha, 4).Value = p.EstoqueTotal;
            ws.Cell(linha, 5).Value = p.Disponibilidade == TipoDisponibilidade.SobEncomenda ? "Sob encomenda" : "Pronta entrega";
            ws.Cell(linha, 6).Value = p.PrazoProducaoDias;
            ws.Cell(linha, 7).Value = p.PesoGramas;
            ws.Cell(linha, 8).Value = $"{p.AlturaCm} x {p.LarguraCm} x {p.ComprimentoCm}";
            ws.Cell(linha, 9).Value = p.Variacoes.Count;
            ws.Cell(linha, 10).Value = p.Ativo ? "Sim" : "Não";
            linha++;
        }
        ws.Row(1).Style.Font.Bold = true;
        ws.Columns().AdjustToContents();

        var ms = new MemoryStream();
        wb.SaveAs(ms);
        ms.Position = 0;
        return File(ms, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"produtos-{DateTime.Now:yyyyMMdd}.xlsx");
    }

    // ---------- auxiliares ----------

    private Task<Produto?> CarregarAsync(Guid id, bool rastrear)
    {
        var q = db.Produtos.Include(p => p.Categoria).ThenInclude(c => c!.CategoriaPai)
            .Include(p => p.Imagens).Include(p => p.Opcoes).Include(p => p.Variacoes).AsSplitQuery();
        return (rastrear ? q : q.AsNoTracking()).FirstOrDefaultAsync(p => p.Id == id);
    }

    private static void Validar(SalvarProdutoDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Nome)) throw new RegraNegocioException("Informe o nome do produto.");
        if (dto.Preco <= 0) throw new RegraNegocioException("O preço deve ser maior que zero.");
        if (dto.PesoGramas <= 0 || dto.AlturaCm <= 0 || dto.LarguraCm <= 0 || dto.ComprimentoCm <= 0)
            throw new RegraNegocioException("Peso e dimensões são obrigatórios para o cálculo do frete.");
        if (dto.Disponibilidade == TipoDisponibilidade.SobEncomenda && dto.PrazoProducaoDias <= 0)
            throw new RegraNegocioException("Produtos sob encomenda precisam de prazo de produção.");
        if (dto.PermitePersonalizacao && string.IsNullOrWhiteSpace(dto.RotuloPersonalizacao))
            throw new RegraNegocioException("Informe o rótulo da personalização (ex.: Nome bordado).");
        if (dto.Estoque < 0 || dto.Variacoes.Any(v => v.Estoque < 0))
            throw new RegraNegocioException("O estoque não pode ser negativo.");
    }

    private async Task AplicarAsync(Produto p, SalvarProdutoDto dto)
    {
        var categoria = await db.Categorias.AsNoTracking().FirstOrDefaultAsync(c => c.Id == dto.CategoriaId)
            ?? throw new RegraNegocioException("Categoria não encontrada.");

        // Categoria desativada só continua valendo para o produto que já estava nela:
        // assim um produto antigo não perde o vínculo, mas ninguém escolhe uma categoria fora do ar.
        if (!categoria.Ativa && p.CategoriaId != dto.CategoriaId)
            throw new RegraNegocioException($"A categoria \"{categoria.Nome}\" está desativada. Ative-a ou escolha outra.");

        p.Nome = dto.Nome.Trim(); p.Descricao = dto.Descricao; p.CategoriaId = dto.CategoriaId;
        p.Preco = dto.Preco; p.Estoque = dto.Estoque;
        p.PesoGramas = dto.PesoGramas; p.AlturaCm = dto.AlturaCm; p.LarguraCm = dto.LarguraCm; p.ComprimentoCm = dto.ComprimentoCm;
        p.Disponibilidade = dto.Disponibilidade; p.PrazoProducaoDias = dto.PrazoProducaoDias;
        p.PermitePersonalizacao = dto.PermitePersonalizacao; p.RotuloPersonalizacao = dto.RotuloPersonalizacao;
        p.LimiteCaracteresPersonalizacao = dto.LimiteCaracteresPersonalizacao; p.ValorPersonalizacao = dto.ValorPersonalizacao;
        p.Ativo = dto.Ativo; p.Destaque = dto.Destaque;

        // Opções: substitui a lista inteira
        db.ProdutoOpcoes.RemoveRange(p.Opcoes);
        p.Opcoes = dto.Opcoes.Select(o => new ProdutoOpcao { Nome = o.Nome.Trim(), Ordem = o.Ordem, Valores = o.Valores }).ToList();

        // Variações: atualiza as existentes (preserva o Id, usado nos pedidos), cria novas e remove as ausentes
        var idsRecebidos = dto.Variacoes.Where(v => v.Id is not null).Select(v => v.Id!.Value).ToHashSet();
        db.ProdutoVariacoes.RemoveRange(p.Variacoes.Where(v => !idsRecebidos.Contains(v.Id)));
        foreach (var v in dto.Variacoes)
        {
            var existente = v.Id is null ? null : p.Variacoes.FirstOrDefault(x => x.Id == v.Id);
            if (existente is null)
                p.Variacoes.Add(new ProdutoVariacao { Sku = v.Sku, Atributos = v.Atributos, Preco = v.Preco, Estoque = v.Estoque, Ativa = v.Ativa });
            else
            {
                existente.Sku = v.Sku; existente.Atributos = v.Atributos; existente.Preco = v.Preco;
                existente.Estoque = v.Estoque; existente.Ativa = v.Ativa;
            }
        }
    }

    private async Task<string> SlugUnicoAsync(string nome, Guid? ignorarId)
    {
        var baseSlug = Slug.Gerar(nome); var slug = baseSlug; var n = 2;
        while (await db.Produtos.AnyAsync(p => p.Slug == slug && p.Id != ignorarId)) slug = $"{baseSlug}-{n++}";
        return slug;
    }
}
