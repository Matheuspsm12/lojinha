using ClosedXML.Excel;
using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Api.Servicos;
using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Domain.Pedidos;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Controllers.Admin;

public record PedidoListaDto(long Numero, string NumeroFormatado, DateTime CriadoEm, string Cliente,
    StatusPedido Status, string StatusTexto, decimal Total, string? Vendedor, bool SemVendedor, string FormaEntrega);

[ApiController]
[Route("api/admin/pedidos")]
[Authorize(Policy = Politicas.Equipe)]
public class PedidosAdminController(LojaDbContext db, ServicoCheckout checkout, IServicoFrete frete, UserManager<Domain.Clientes.Usuario> usuarios) : ControllerBase
{
    private async Task<bool> SouAdminAsync() =>
        await usuarios.IsInRoleAsync((await usuarios.FindByIdAsync(User.UsuarioId().ToString()))!, Perfis.Administrador);

    /// <summary>Lista com filtros: status, "sem-vendedor", "meus" e busca por número ou cliente.</summary>
    [HttpGet]
    public async Task<PaginaDto<PedidoListaDto>> Listar([FromQuery] string? filtro, [FromQuery] StatusPedido? status,
        [FromQuery] string? busca, [FromQuery] int pagina = 1, [FromQuery] int tamanho = 30)
    {
        tamanho = Math.Clamp(tamanho, 1, 100);
        var eu = User.UsuarioId();
        var q = db.Pedidos.AsNoTracking().AsQueryable();

        if (filtro == "sem-vendedor") q = q.Where(p => p.VendedorId == null && p.Status != StatusPedido.Cancelado);
        else if (filtro == "meus") q = q.Where(p => p.VendedorId == eu);
        else if (filtro == "abertos") q = q.Where(p => p.Status != StatusPedido.Entregue && p.Status != StatusPedido.Cancelado);
        if (status is not null) q = q.Where(p => p.Status == status);
        if (!string.IsNullOrWhiteSpace(busca))
        {
            var termo = $"%{busca.Trim()}%";
            q = long.TryParse(new string(busca.Where(char.IsDigit).ToArray()), out var numero)
                ? q.Where(p => p.Numero == numero)
                : q.Where(p => db.Users.Any(u => u.Id == p.ClienteId && EF.Functions.ILike(EF.Functions.Unaccent(u.NomeCompleto), EF.Functions.Unaccent(termo))));
        }

        var total = await q.CountAsync();
        var itens = await q.OrderByDescending(p => p.Numero).Skip((pagina - 1) * tamanho).Take(tamanho)
            .Select(p => new
            {
                p.Numero, p.CriadoEm, p.Status, p.Subtotal, p.ValorFrete, p.Desconto, p.FormaEntrega, p.VendedorId,
                Cliente = db.Users.Where(u => u.Id == p.ClienteId).Select(u => u.NomeCompleto).FirstOrDefault(),
                Vendedor = db.Users.Where(u => u.Id == p.VendedorId).Select(u => u.NomeCompleto).FirstOrDefault()
            }).ToListAsync();

        return new PaginaDto<PedidoListaDto>(itens.Select(p => new PedidoListaDto(
            p.Numero, $"VA-{p.Numero:D6}", p.CriadoEm, p.Cliente ?? "", p.Status, p.Status.Texto(),
            p.Subtotal + p.ValorFrete - p.Desconto, p.Vendedor, p.VendedorId is null, p.FormaEntrega)).ToList(), pagina, tamanho, total);
    }

    [HttpGet("{numero:long}")]
    public async Task<ActionResult<PedidoAdminDto>> Obter(long numero)
    {
        var p = await CarregarAsync(numero, rastrear: false);
        if (p is null) return NotFound();
        var cliente = await db.Users.AsNoTracking().FirstAsync(u => u.Id == p.ClienteId);
        var vendedor = p.VendedorId is null ? null : await db.Users.AsNoTracking().Where(u => u.Id == p.VendedorId).Select(u => u.NomeCompleto).FirstOrDefaultAsync();
        var proximos = Enum.GetValues<StatusPedido>().Where(p.PodeMudarPara);
        return p.ParaAdminDto(cliente, vendedor, proximos);
    }

    /// <summary>O vendedor assume a ordem de compra.</summary>
    [HttpPost("{numero:long}/assumir")]
    public async Task<IActionResult> Assumir(long numero)
    {
        var p = await CarregarAsync(numero, rastrear: true);
        if (p is null) return NotFound();
        if (await SouAdminAsync() && p.VendedorId is not null && p.VendedorId != User.UsuarioId()) p.VendedorId = null; // admin pode redirecionar
        p.Assumir(User.UsuarioId());
        await db.SaveChangesAsync();
        return NoContent();
    }

    [HttpPatch("{numero:long}/status")]
    public async Task<IActionResult> Status(long numero, MudarStatusDto dto)
    {
        var p = await CarregarAsync(numero, rastrear: true);
        if (p is null) return NotFound();
        await GarantirResponsavelAsync(p);
        await checkout.MudarStatusAsync(p, dto.Status, User.UsuarioId(), dto.Comentario);
        return NoContent();
    }

    [HttpPut("{numero:long}/rastreio")]
    public async Task<IActionResult> Rastreio(long numero, RastreioDto dto)
    {
        var p = await CarregarAsync(numero, rastrear: true);
        if (p is null) return NotFound();
        await GarantirResponsavelAsync(p);
        if (string.IsNullOrWhiteSpace(dto.CodigoRastreio)) throw new RegraNegocioException("Informe o código de rastreamento.");
        p.CodigoRastreio = dto.CodigoRastreio.Trim().ToUpperInvariant();
        await db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Gera a etiqueta no Melhor Envio e guarda o rastreio quando disponível.</summary>
    [HttpPost("{numero:long}/etiqueta")]
    public async Task<ActionResult<object>> Etiqueta(long numero)
    {
        var p = await CarregarAsync(numero, rastrear: true);
        if (p is null) return NotFound();
        await GarantirResponsavelAsync(p);
        if (p.ServicoFreteId is null) throw new RegraNegocioException("Este pedido é retirada no local: não tem etiqueta.");
        if (p.Status is StatusPedido.PedidoRecebido or StatusPedido.AguardandoPagamento)
            throw new RegraNegocioException("Confirme o pagamento antes de gerar a etiqueta.");

        p.EtiquetaId = await frete.GerarEtiquetaAsync(p);
        p.CodigoRastreio ??= await frete.ObterRastreioAsync(p.EtiquetaId);
        await db.SaveChangesAsync();
        return Ok(new { p.EtiquetaId, p.CodigoRastreio });
    }

    /// <summary>Confirmação manual (transferência, dinheiro ou máquina de cartão).</summary>
    [HttpPost("{numero:long}/confirmar-pagamento")]
    public async Task<IActionResult> ConfirmarPagamento(long numero, [FromQuery] string? observacao)
    {
        var p = await CarregarAsync(numero, rastrear: true);
        if (p is null) return NotFound();
        await GarantirResponsavelAsync(p);

        var pg = p.Pagamentos.OrderByDescending(x => x.CriadoEm).FirstOrDefault();
        if (pg is null) { pg = new Pagamento { PedidoId = p.Id, Metodo = MetodoPagamento.Manual, Valor = p.Total }; db.Pagamentos.Add(pg); p.Pagamentos.Add(pg); }
        pg.Status = StatusPagamento.Aprovado;
        pg.PagoEm = DateTime.UtcNow;
        pg.ConfirmadoPorId = User.UsuarioId();
        pg.TaxaGateway ??= 0m;                      // recebimento manual não tem taxa de gateway
        pg.ValorLiquido ??= pg.Valor;
        await checkout.MudarStatusAsync(p, StatusPedido.PagamentoConfirmado, User.UsuarioId(), observacao ?? "Pagamento confirmado manualmente");
        return NoContent();
    }

    [HttpPut("{numero:long}/observacao")]
    public async Task<IActionResult> Observacao(long numero, [FromBody] string texto)
    {
        var n = await db.Pedidos.Where(p => p.Numero == numero)
            .ExecuteUpdateAsync(s => s.SetProperty(p => p.ObservacaoInterna, texto).SetProperty(p => p.AtualizadoEm, DateTime.UtcNow));
        return n == 0 ? NotFound() : NoContent();
    }

    /// <summary>Planilha Excel dos pedidos.</summary>
    [HttpGet("exportar")]
    public async Task<IActionResult> Exportar([FromQuery] DateTime? de, [FromQuery] DateTime? ate)
    {
        var inicio = (de ?? DateTime.UtcNow.AddDays(-90)).ToUniversalTime();
        var fim = (ate?.ToUniversalTime() ?? DateTime.UtcNow).AddDays(1);
        var pedidos = await db.Pedidos.AsNoTracking().Include(p => p.Itens).Include(p => p.Pagamentos)
            .Where(p => p.CriadoEm >= inicio && p.CriadoEm < fim).OrderBy(p => p.Numero).AsSplitQuery().ToListAsync();
        var nomes = await db.Users.AsNoTracking().ToDictionaryAsync(u => u.Id, u => u.NomeCompleto);

        using var wb = new XLWorkbook();
        var ws = wb.AddWorksheet("Pedidos");
        string[] cab = ["Pedido", "Data", "Cliente", "Status", "Vendedor", "Itens", "Subtotal", "Frete", "Total", "Pagamento", "Situação do pagamento", "Entrega", "Rastreio", "Cidade/UF"];
        for (var i = 0; i < cab.Length; i++) ws.Cell(1, i + 1).Value = cab[i];

        var linha = 2;
        foreach (var p in pedidos)
        {
            var pg = p.Pagamentos.OrderByDescending(x => x.CriadoEm).FirstOrDefault();
            ws.Cell(linha, 1).Value = p.NumeroFormatado;
            ws.Cell(linha, 2).Value = p.CriadoEm.ToLocalTime();
            ws.Cell(linha, 2).Style.DateFormat.Format = "dd/MM/yyyy HH:mm";
            ws.Cell(linha, 3).Value = nomes.GetValueOrDefault(p.ClienteId);
            ws.Cell(linha, 4).Value = p.Status.Texto();
            ws.Cell(linha, 5).Value = p.VendedorId is null ? "" : nomes.GetValueOrDefault(p.VendedorId.Value);
            ws.Cell(linha, 6).Value = string.Join(" | ", p.Itens.Select(i => $"{i.Quantidade}x {i.NomeProduto}"));
            ws.Cell(linha, 7).Value = p.Subtotal;
            ws.Cell(linha, 8).Value = p.ValorFrete;
            ws.Cell(linha, 9).Value = p.Total;
            ws.Range(linha, 7, linha, 9).Style.NumberFormat.Format = "R$ #,##0.00";
            ws.Cell(linha, 10).Value = pg?.Metodo.ToString();
            ws.Cell(linha, 11).Value = pg?.Status.ToString();
            ws.Cell(linha, 12).Value = p.FormaEntrega;
            ws.Cell(linha, 13).Value = p.CodigoRastreio;
            ws.Cell(linha, 14).Value = $"{p.EnderecoEntrega.Cidade}/{p.EnderecoEntrega.Uf}";
            linha++;
        }
        ws.Row(1).Style.Font.Bold = true;
        ws.Columns().AdjustToContents();
        ws.Column(6).Width = 40;

        var ms = new MemoryStream();
        wb.SaveAs(ms);
        ms.Position = 0;
        return File(ms, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"pedidos-{DateTime.Now:yyyyMMdd}.xlsx");
    }

    private Task<Pedido?> CarregarAsync(long numero, bool rastrear)
    {
        var q = db.Pedidos.Include(p => p.Itens).Include(p => p.Pagamentos).Include(p => p.Historico).AsSplitQuery();
        return (rastrear ? q : q.AsNoTracking()).FirstOrDefaultAsync(p => p.Numero == numero);
    }

    /// <summary>Só o vendedor que assumiu (ou um administrador) mexe no pedido.</summary>
    private async Task GarantirResponsavelAsync(Pedido p)
    {
        if (p.VendedorId == User.UsuarioId()) return;
        if (await SouAdminAsync()) return;
        throw new RegraNegocioException(p.VendedorId is null
            ? "Assuma o pedido antes de atualizá-lo."
            : "Este pedido está com outro vendedor.");
    }
}
