using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Api.Seguranca;
using LojaAmanhecer.Api.Servicos;
using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Controllers.Admin;

/// <summary>
/// Pagamentos e recebimentos. Área exclusiva da conta administradora.
/// O Access Token nunca sai daqui: o painel só recebe a versão mascarada e o estado da conexão.
/// </summary>
[ApiController]
[Route("api/admin/pagamentos")]
[Authorize(Policy = Politicas.Administrador)]
public class PagamentosAdminController(
    LojaDbContext db,
    ConfiguracaoPagamento configuracao,
    IServicoPagamento gateway,
    Cofre cofre,
    ServicoAcesso acessos,
    ILogger<PagamentosAdminController> log) : ControllerBase
{
    // ---------------- configuração ----------------

    [HttpGet("configuracao")]
    public async Task<ConfiguracaoPagamentoDto> Configuracao() => await MontarConfiguracaoAsync();

    /// <summary>Formas de pagamento, parcelamento e taxas de referência. Não mexe na credencial.</summary>
    [HttpPut("configuracao")]
    public async Task<ConfiguracaoPagamentoDto> Salvar(SalvarConfiguracaoPagamentoDto dto)
    {
        if (!dto.PixAtivo && !dto.CartaoAtivo && !dto.BoletoAtivo)
            throw new RegraNegocioException("Deixe pelo menos uma forma de pagamento ativa.");
        if (dto.MaximoParcelas is < 1 or > 24)
            throw new RegraNegocioException("O número máximo de parcelas deve ficar entre 1 e 24.");
        if (dto.ValorMinimoParcela < 0) throw new RegraNegocioException("O valor mínimo da parcela não pode ser negativo.");
        if (dto.Ambiente is not ("teste" or "producao")) throw new RegraNegocioException("Ambiente deve ser \"teste\" ou \"producao\".");

        await configuracao.GravarAsync(ConfiguracaoPagamento.ChavePix, dto.PixAtivo.ToString(), "Pix ativo na loja");
        await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveCartao, dto.CartaoAtivo.ToString(), "Cartão de crédito ativo na loja");
        await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveBoleto, dto.BoletoAtivo.ToString(), "Boleto ativo na loja");
        await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveMaxParcelas, dto.MaximoParcelas.ToString(), "Máximo de parcelas no cartão");
        await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveJuros, dto.ParcelamentoComJuros.ToString(), "Parcelamento com juros do comprador");
        await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveMinimoParcela, Numero(dto.ValorMinimoParcela), "Valor mínimo de cada parcela");
        await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveAmbiente, dto.Ambiente, "Ambiente do Mercado Pago: teste ou producao");
        await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveTaxaPix, Numero(dto.TaxaPix), "Taxa estimada do Pix (%)");
        await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveTaxaCartao, Numero(dto.TaxaCartao), "Taxa estimada do cartão (%)");
        await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveTaxaBoleto, Numero(dto.TaxaBoleto), "Taxa estimada do boleto (%)");
        await db.SaveChangesAsync();

        log.LogInformation("Configuração de pagamentos alterada por {Usuario}", User.Identity?.Name);
        return await MontarConfiguracaoAsync();
    }

    /// <summary>Conecta a conta do Mercado Pago. O token é cifrado antes de ir para o banco.</summary>
    [HttpPut("credencial")]
    public async Task<ActionResult<ConfiguracaoPagamentoDto>> SalvarCredencial(SalvarCredencialDto dto)
    {
        var token = dto.AccessToken?.Trim() ?? "";
        if (token.Length < 20) throw new RegraNegocioException("Access Token inválido. Copie o token completo do painel do Mercado Pago.");

        var ambiente = dto.Ambiente ?? (token.StartsWith("TEST-") ? "teste" : "producao");
        if (ambiente is not ("teste" or "producao")) throw new RegraNegocioException("Ambiente deve ser \"teste\" ou \"producao\".");

        // guarda antes de testar, para o teste usar a credencial nova, e desfaz se não passar
        var anterior = await configuracao.TextoAsync(ConfiguracaoPagamento.ChaveToken);
        var ambienteAnterior = await configuracao.TextoAsync(ConfiguracaoPagamento.ChaveAmbiente, "teste");
        await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveToken, cofre.Cifrar(token), "Access Token do Mercado Pago (cifrado)");
        await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveAmbiente, ambiente);
        await db.SaveChangesAsync();

        if (dto.TestarAntes)
        {
            var (ok, detalhe) = await TestarAsync();
            if (!ok)
            {
                await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveToken, anterior);
                await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveAmbiente, ambienteAnterior);
                await db.SaveChangesAsync();
                throw new RegraNegocioException($"Credencial não aceita: {detalhe} Nada foi salvo.");
            }
        }

        await acessos.RegistrarAsync(User.Identity?.Name ?? "", true, "CredencialPagamentoAlterada", "painel", User.UsuarioId());
        return await MontarConfiguracaoAsync();
    }

    /// <summary>Desconecta a conta: a loja volta ao modo simulado.</summary>
    [HttpDelete("credencial")]
    public async Task<ConfiguracaoPagamentoDto> RemoverCredencial()
    {
        await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveToken, "");
        await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveApelido, "");
        await db.SaveChangesAsync();
        await acessos.RegistrarAsync(User.Identity?.Name ?? "", true, "CredencialPagamentoRemovida", "painel", User.UsuarioId());
        return await MontarConfiguracaoAsync();
    }

    /// <summary>Testa a conexão com a conta conectada, sem alterar nada.</summary>
    [HttpPost("testar-conexao")]
    public async Task<TesteConexaoDto> TestarConexao()
    {
        var (ok, detalhe) = await TestarAsync();
        return new TesteConexaoDto(ok, detalhe, !await configuracao.ConectadoAsync());
    }

    private async Task<(bool Ok, string Detalhe)> TestarAsync()
    {
        try
        {
            var (ok, detalhe) = await gateway.TestarConexaoAsync();
            await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveUltimoTeste, $"{DateTime.UtcNow:O}|{(ok ? "ok" : "falhou")}|{detalhe}");
            if (ok && detalhe.Contains("conta ")) await configuracao.GravarAsync(ConfiguracaoPagamento.ChaveApelido, detalhe);
            await db.SaveChangesAsync();
            return (ok, detalhe);
        }
        catch (RegraNegocioException ex) { return (false, ex.Message); }
        catch (Exception ex)
        {
            log.LogWarning(ex, "Falha ao testar a conexão com o Mercado Pago");
            return (false, "Não foi possível falar com o Mercado Pago agora.");
        }
    }

    // ---------------- recebimentos ----------------

    [HttpGet]
    public async Task<List<PagamentoAdminDto>> Listar([FromQuery] StatusPagamento? status, [FromQuery] string? busca, [FromQuery] int dias = 90)
    {
        var inicio = DateTime.UtcNow.AddDays(-Math.Clamp(dias, 1, 730));
        var q = from pg in db.Pagamentos.AsNoTracking()
                join p in db.Pedidos.AsNoTracking() on pg.PedidoId equals p.Id
                join u in db.Users.AsNoTracking() on p.ClienteId equals u.Id
                where pg.CriadoEm >= inicio
                select new { pg, p.Numero, Cliente = u.NomeCompleto, Email = u.Email };

        if (status is not null) q = q.Where(x => x.pg.Status == status);
        if (!string.IsNullOrWhiteSpace(busca))
        {
            var termo = $"%{busca.Trim()}%";
            q = long.TryParse(new string(busca.Where(char.IsDigit).ToArray()), out var numero)
                ? q.Where(x => x.Numero == numero)
                : q.Where(x => EF.Functions.ILike(EF.Functions.Unaccent(x.Cliente), EF.Functions.Unaccent(termo)));
        }

        var linhas = await q.OrderByDescending(x => x.pg.CriadoEm).Take(300).ToListAsync();
        var taxas = new Dictionary<MetodoPagamento, decimal>();
        foreach (var metodo in Enum.GetValues<MetodoPagamento>()) taxas[metodo] = await configuracao.TaxaAsync(metodo);

        return linhas.Select(x =>
        {
            var taxa = x.pg.TaxaGateway ?? Math.Round(x.pg.Valor * taxas[x.pg.Metodo] / 100m, 2);
            var liquido = x.pg.ValorLiquido ?? Math.Round(x.pg.Valor - taxa - x.pg.ValorEstornado, 2);
            return new PagamentoAdminDto(
                x.pg.Id, x.Numero, $"VA-{x.Numero:D6}", x.Cliente, x.Email ?? "",
                x.pg.Metodo, x.pg.Status, Texto(x.pg.Status),
                x.pg.Valor, taxa, liquido, x.pg.ValorEstornado,
                x.pg.CriadoEm, x.pg.PagoEm, Mascarar(x.pg.GatewayId), x.pg.Ambiente,
                x.pg.Status == StatusPagamento.Aprovado && x.pg.ValorEstornado < x.pg.Valor);
        }).ToList();
    }

    [HttpGet("resumo")]
    public async Task<ResumoRecebimentosDto> Resumo([FromQuery] int dias = 90)
    {
        var inicio = DateTime.UtcNow.AddDays(-Math.Clamp(dias, 1, 730));
        var pagamentos = await db.Pagamentos.AsNoTracking().Where(p => p.CriadoEm >= inicio).ToListAsync();
        var taxas = new Dictionary<MetodoPagamento, decimal>();
        foreach (var metodo in Enum.GetValues<MetodoPagamento>()) taxas[metodo] = await configuracao.TaxaAsync(metodo);

        decimal Taxa(Domain.Pedidos.Pagamento p) => p.TaxaGateway ?? Math.Round(p.Valor * taxas[p.Metodo] / 100m, 2);
        var aprovados = pagamentos.Where(p => p.Status == StatusPagamento.Aprovado).ToList();

        return new ResumoRecebimentosDto(
            Aprovados: aprovados.Count,
            Pendentes: pagamentos.Count(p => p.Status == StatusPagamento.Pendente),
            Recusados: pagamentos.Count(p => p.Status == StatusPagamento.Recusado),
            Estornados: pagamentos.Count(p => p.Status == StatusPagamento.Estornado),
            Cancelados: pagamentos.Count(p => p.Status == StatusPagamento.Expirado),
            TotalAprovado: aprovados.Sum(p => p.Valor),
            TotalTaxas: aprovados.Sum(Taxa),
            LiquidoPrevisto: aprovados.Sum(p => p.ValorLiquido ?? p.Valor - Taxa(p) - p.ValorEstornado),
            TotalEstornado: pagamentos.Sum(p => p.ValorEstornado),
            TotalPendente: pagamentos.Where(p => p.Status == StatusPagamento.Pendente).Sum(p => p.Valor),
            Simulado: !await configuracao.ConectadoAsync());
    }

    /// <summary>Estorno total (sem valor) ou parcial.</summary>
    [HttpPost("{id:guid}/estornar")]
    public async Task<ActionResult<PagamentoAdminDto>> Estornar(Guid id, EstornarDto dto)
    {
        var pg = await db.Pagamentos.FirstOrDefaultAsync(p => p.Id == id);
        if (pg is null) return NotFound();
        if (pg.Status != StatusPagamento.Aprovado) throw new RegraNegocioException("Só é possível estornar um pagamento aprovado.");

        var disponivel = pg.Valor - pg.ValorEstornado;
        var valor = dto.Valor;
        if (valor is <= 0) throw new RegraNegocioException("O valor do estorno deve ser maior que zero.");
        if (valor > disponivel) throw new RegraNegocioException($"O máximo que ainda pode ser estornado é {disponivel:C}.");

        var resultado = await gateway.EstornarAsync(pg.GatewayId ?? "", valor, default);
        var devolvido = resultado.ValorEstornado > 0 ? resultado.ValorEstornado : valor ?? disponivel;

        pg.ValorEstornado = Math.Round(pg.ValorEstornado + devolvido, 2);
        if (pg.ValorEstornado >= pg.Valor) pg.Status = StatusPagamento.Estornado;
        if (pg.ValorLiquido is not null) pg.ValorLiquido = Math.Round(pg.ValorLiquido.Value - devolvido, 2);

        var pedido = await db.Pedidos.Include(p => p.Itens).Include(p => p.Historico).FirstAsync(p => p.Id == pg.PedidoId);
        pedido.ObservacaoInterna = $"{pedido.ObservacaoInterna}\nEstorno de {devolvido:C} em {DateTime.Now:g}: {dto.Motivo ?? "sem motivo informado"}".Trim();
        await db.SaveChangesAsync();

        log.LogInformation("Estorno de {Valor} no pagamento {Id} do pedido {Pedido}", devolvido, id, pedido.NumeroFormatado);
        var lista = await Listar(null, pedido.Numero.ToString(), 730);
        return lista.First(x => x.Id == id);
    }

    // ---------------- apoio ----------------

    private static string Numero(decimal v) => v.ToString(System.Globalization.CultureInfo.InvariantCulture);

    private static string Texto(StatusPagamento s) => s switch
    {
        StatusPagamento.Pendente => "Pendente",
        StatusPagamento.Aprovado => "Aprovado",
        StatusPagamento.Recusado => "Recusado",
        StatusPagamento.Estornado => "Estornado",
        _ => "Cancelado"
    };

    /// <summary>O id da cobrança no gateway também aparece parcialmente, para não vazar dado de cobrança.</summary>
    private static string? Mascarar(string? gatewayId) =>
        string.IsNullOrWhiteSpace(gatewayId) ? null : gatewayId.Length <= 6 ? gatewayId : $"•••{gatewayId[^6..]}";

    private async Task<ConfiguracaoPagamentoDto> MontarConfiguracaoAsync()
    {
        var credencial = await configuracao.CredencialAsync();
        var teste = (await configuracao.TextoAsync(ConfiguracaoPagamento.ChaveUltimoTeste)).Split('|');
        DateTime? testeEm = teste.Length == 3 && DateTime.TryParse(teste[0], null, System.Globalization.DateTimeStyles.RoundtripKind, out var d) ? d : null;

        return new ConfiguracaoPagamentoDto(
            Conectado: credencial.AccessToken is { Length: > 0 },
            Simulado: credencial.AccessToken is null or "",
            Ambiente: credencial.Sandbox ? "teste" : "producao",
            FonteCredencial: credencial.Fonte switch
            {
                FonteCredencial.VariavelDeAmbiente => "Variável de ambiente do servidor",
                FonteCredencial.Painel => "Cadastrada no painel (guardada cifrada)",
                _ => "Nenhuma credencial cadastrada"
            },
            TokenMascarado: Cofre.Mascarar(credencial.AccessToken),
            Conta: await configuracao.TextoAsync(ConfiguracaoPagamento.ChaveApelido) is { Length: > 0 } c ? c : null,
            UltimoTesteEm: testeEm,
            UltimoTesteDetalhe: teste.Length == 3 ? teste[2] : null,
            PixAtivo: await configuracao.BoolAsync(ConfiguracaoPagamento.ChavePix, true),
            CartaoAtivo: await configuracao.BoolAsync(ConfiguracaoPagamento.ChaveCartao, true),
            BoletoAtivo: await configuracao.BoolAsync(ConfiguracaoPagamento.ChaveBoleto, true),
            MaximoParcelas: await configuracao.InteiroAsync(ConfiguracaoPagamento.ChaveMaxParcelas, 3),
            ParcelamentoComJuros: await configuracao.BoolAsync(ConfiguracaoPagamento.ChaveJuros, false),
            ValorMinimoParcela: await configuracao.DecimalAsync(ConfiguracaoPagamento.ChaveMinimoParcela, 30m),
            TaxaPix: await configuracao.TaxaAsync(MetodoPagamento.Pix),
            TaxaCartao: await configuracao.TaxaAsync(MetodoPagamento.CartaoCredito),
            TaxaBoleto: await configuracao.TaxaAsync(MetodoPagamento.Boleto));
    }
}
