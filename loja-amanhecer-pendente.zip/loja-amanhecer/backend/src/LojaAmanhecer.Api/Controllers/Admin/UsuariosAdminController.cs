using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Domain.Clientes;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Controllers.Admin;

public record UsuarioResumoDto(Guid Id, string Nome, string Email, string? Telefone, bool Ativo, DateTime CriadoEm, IList<string> Perfis);
public record CriarEquipeDto(string NomeCompleto, string Email, string SenhaInicial, string? Telefone, string Perfil);

[ApiController]
[Route("api/admin/usuarios")]
[Authorize(Policy = Politicas.Equipe)]
public class UsuariosAdminController(LojaDbContext db, UserManager<Usuario> usuarios) : ControllerBase
{
    [HttpGet("clientes")]
    public async Task<List<UsuarioResumoDto>> Clientes([FromQuery] string? busca)
    {
        var lista = await usuarios.GetUsersInRoleAsync(Perfis.Cliente);
        return lista.Where(u => busca is null || u.NomeCompleto.Contains(busca, StringComparison.OrdinalIgnoreCase) || u.Email!.Contains(busca, StringComparison.OrdinalIgnoreCase))
            .OrderBy(u => u.NomeCompleto)
            .Select(u => new UsuarioResumoDto(u.Id, u.NomeCompleto, u.Email!, u.PhoneNumber, u.Ativo, u.CriadoEm, [Perfis.Cliente]))
            .ToList();
    }

    [HttpGet("equipe")]
    [Authorize(Policy = Politicas.Administrador)]
    public async Task<List<UsuarioResumoDto>> Equipe()
    {
        var admins = await usuarios.GetUsersInRoleAsync(Perfis.Administrador);
        var vendedores = await usuarios.GetUsersInRoleAsync(Perfis.Vendedor);
        return admins.Select(u => (u, Perfis.Administrador)).Concat(vendedores.Select(u => (u, Perfis.Vendedor)))
            .Select(x => new UsuarioResumoDto(x.u.Id, x.u.NomeCompleto, x.u.Email!, x.u.PhoneNumber, x.u.Ativo, x.u.CriadoEm, [x.Item2]))
            .ToList();
    }

    /// <summary>Cadastra vendedor ou administrador.</summary>
    [HttpPost("equipe")]
    [Authorize(Policy = Politicas.Administrador)]
    public async Task<IActionResult> CriarEquipe(CriarEquipeDto dto)
    {
        if (dto.Perfil is not (Perfis.Vendedor or Perfis.Administrador))
            throw new RegraNegocioException("Perfil deve ser Vendedor ou Administrador.");
        var u = new Usuario { UserName = dto.Email, Email = dto.Email, EmailConfirmed = true, NomeCompleto = dto.NomeCompleto, PhoneNumber = dto.Telefone };
        var r = await usuarios.CreateAsync(u, dto.SenhaInicial);
        if (!r.Succeeded) throw new RegraNegocioException(LojaAmanhecer.Api.Seguranca.ErrosIdentity.Traduzir(r.Errors));
        await usuarios.AddToRoleAsync(u, dto.Perfil);
        return Ok(new { u.Id });
    }

    [HttpPatch("{id:guid}/ativo")]
    [Authorize(Policy = Politicas.Administrador)]
    public async Task<IActionResult> AlterarAtivo(Guid id, [FromQuery] bool ativo)
    {
        if (id == User.UsuarioId()) throw new RegraNegocioException("Você não pode desativar o próprio usuário.");
        var n = await db.Users.Where(u => u.Id == id).ExecuteUpdateAsync(s => s.SetProperty(u => u.Ativo, ativo));
        return n == 0 ? NotFound() : NoContent();
    }
}
