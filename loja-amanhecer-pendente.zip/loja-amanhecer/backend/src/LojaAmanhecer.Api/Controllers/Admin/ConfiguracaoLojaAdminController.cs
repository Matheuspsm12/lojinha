using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Configuracoes;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Controllers.Admin;

public record ConfiguracaoLojaDto(string Nome, string Whatsapp, string? Email, string? Instagram);
public record SalvarConfiguracaoLojaDto(string Nome, string Whatsapp, string? Email, string? Instagram);

/// <summary>
/// Nome, WhatsApp, e-mail de contato e Instagram da loja: o que aparece no cabeçalho, no rodapé
/// e nos links de "Falar no WhatsApp". Área exclusiva da conta administradora.
/// </summary>
[ApiController]
[Route("api/admin/loja")]
[Authorize(Policy = Politicas.Administrador)]
public class ConfiguracaoLojaAdminController(LojaDbContext db) : ControllerBase
{
    public const string ChaveNome = "loja.nome";
    public const string ChaveWhatsapp = "loja.whatsapp";
    public const string ChaveEmail = "loja.email";
    public const string ChaveInstagram = "loja.instagram";

    [HttpGet]
    public async Task<ConfiguracaoLojaDto> Obter() => await MontarAsync();

    [HttpPut]
    public async Task<ConfiguracaoLojaDto> Salvar(SalvarConfiguracaoLojaDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Nome)) throw new RegraNegocioException("Informe o nome da loja.");

        var whatsapp = new string(dto.Whatsapp.Where(char.IsDigit).ToArray());
        if (whatsapp.Length is < 10 or > 15) throw new RegraNegocioException("Informe o WhatsApp com DDI e DDD, só números.");

        var instagram = dto.Instagram?.Trim();
        if (!string.IsNullOrWhiteSpace(instagram) && !instagram.StartsWith("http://") && !instagram.StartsWith("https://"))
            throw new RegraNegocioException("Informe o link completo do Instagram (começando com https://).");

        await GravarAsync(ChaveNome, dto.Nome.Trim());
        await GravarAsync(ChaveWhatsapp, whatsapp);
        await GravarAsync(ChaveEmail, dto.Email?.Trim() ?? "");
        await GravarAsync(ChaveInstagram, instagram ?? "");
        await db.SaveChangesAsync();
        return await MontarAsync();
    }

    private async Task GravarAsync(string chave, string valor)
    {
        var atual = await db.Configuracoes.FirstOrDefaultAsync(c => c.Chave == chave);
        if (atual is null) db.Configuracoes.Add(new ConfiguracaoLoja { Chave = chave, Valor = valor });
        else atual.Valor = valor;
    }

    private async Task<ConfiguracaoLojaDto> MontarAsync()
    {
        var valores = await db.Configuracoes.AsNoTracking()
            .Where(c => c.Chave == ChaveNome || c.Chave == ChaveWhatsapp || c.Chave == ChaveEmail || c.Chave == ChaveInstagram)
            .ToDictionaryAsync(c => c.Chave, c => c.Valor);
        string? V(string chave) => valores.GetValueOrDefault(chave) is { Length: > 0 } v ? v : null;
        return new ConfiguracaoLojaDto(V(ChaveNome) ?? "Lojinha Do Vale", V(ChaveWhatsapp) ?? "", V(ChaveEmail), V(ChaveInstagram));
    }
}

/// <summary>O que a loja precisa saber para montar o cabeçalho e o rodapé.</summary>
[ApiController]
[Route("api/loja")]
public class LojaInfoController(LojaDbContext db) : ControllerBase
{
    [HttpGet("info")]
    public async Task<ConfiguracaoLojaDto> Info()
    {
        var valores = await db.Configuracoes.AsNoTracking()
            .Where(c => c.Chave == ConfiguracaoLojaAdminController.ChaveNome || c.Chave == ConfiguracaoLojaAdminController.ChaveWhatsapp
                     || c.Chave == ConfiguracaoLojaAdminController.ChaveEmail || c.Chave == ConfiguracaoLojaAdminController.ChaveInstagram)
            .ToDictionaryAsync(c => c.Chave, c => c.Valor);
        string? V(string chave) => valores.GetValueOrDefault(chave) is { Length: > 0 } v ? v : null;
        return new ConfiguracaoLojaDto(
            V(ConfiguracaoLojaAdminController.ChaveNome) ?? "Lojinha Do Vale",
            V(ConfiguracaoLojaAdminController.ChaveWhatsapp) ?? "",
            V(ConfiguracaoLojaAdminController.ChaveEmail),
            V(ConfiguracaoLojaAdminController.ChaveInstagram));
    }
}
