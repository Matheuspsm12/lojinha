using ClosedXML.Excel;
using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Controllers.Admin;

[ApiController]
[Route("api/admin/relatorios")]
[Authorize(Policy = Politicas.Equipe)]
public class RelatoriosController(LojaDbContext db) : ControllerBase
{
    // Pedidos que já viraram venda (pagos e não cancelados)
    private static readonly StatusPedido[] NaoContam = [StatusPedido.Cancelado, StatusPedido.PedidoRecebido, StatusPedido.AguardandoPagamento];

    [HttpGet("vendas")]
    public async Task<RelatorioVendasDto> Vendas([FromQuery] int dias = 30)
    {
        dias = Math.Clamp(dias, 1, 365);
        var inicio = DateTime.UtcNow.Date.AddDays(-dias + 1);

        var pedidos = await db.Pedidos.AsNoTracking().Include(p => p.Itens)
            .Where(p => p.CriadoEm >= inicio && !NaoContam.Contains(p.Status)).AsSplitQuery().ToListAsync();
        var faturamento = pedidos.Sum(p => p.Total);

        var nomes = await db.Users.AsNoTracking().ToDictionaryAsync(u => u.Id, u => u.NomeCompleto);
        var categorias = await db.Produtos.AsNoTracking().Include(p => p.Categoria).ThenInclude(c => c!.CategoriaPai)
            .ToDictionaryAsync(p => p.Id, p => p.Categoria!.CategoriaPai?.Nome ?? p.Categoria!.Nome);

        var itens = pedidos.SelectMany(p => p.Itens).ToList();

        return new RelatorioVendasDto(
            Faturamento: faturamento,
            Pedidos: pedidos.Count,
            TicketMedio: pedidos.Count == 0 ? 0 : Math.Round(faturamento / pedidos.Count, 2),
            ClientesNovos: await db.Users.CountAsync(u => u.CriadoEm >= inicio),
            PorDia: pedidos.GroupBy(p => DateOnly.FromDateTime(p.CriadoEm.ToLocalTime()))
                .OrderBy(g => g.Key).Select(g => new VendaPorDiaDto(g.Key, g.Sum(p => p.Total), g.Count())).ToList(),
            PorCategoria: itens.GroupBy(i => categorias.GetValueOrDefault(i.ProdutoId, "Outros"))
                .Select(g => new VendaPorCategoriaDto(g.Key, g.Sum(i => i.Total), g.Sum(i => i.Quantidade)))
                .OrderByDescending(x => x.Valor).ToList(),
            MaisVendidos: itens.GroupBy(i => i.NomeProduto)
                .Select(g => new ProdutoVendidoDto(g.Key, g.Sum(i => i.Quantidade), g.Sum(i => i.Total)))
                .OrderByDescending(x => x.Unidades).Take(10).ToList(),
            PorVendedor: pedidos.Where(p => p.VendedorId is not null).GroupBy(p => p.VendedorId!.Value)
                .Select(g => new VendaPorVendedorDto(nomes.GetValueOrDefault(g.Key, "—"), g.Count(), g.Sum(p => p.Total)))
                .OrderByDescending(x => x.Valor).ToList());
    }

    /// <summary>
    /// Cliques (visitas à página do produto) e vendas, lado a lado — o "mapa de calor" do catálogo:
    /// quanto mais clique, mais escura a linha; dá pra ver de cara o que atrai olhar mas não vende.
    /// Cliques somam desde sempre (não têm data); vendas respeitam o período pedido.
    /// </summary>
    [HttpGet("desempenho-produtos")]
    public async Task<List<ProdutoDesempenhoDto>> DesempenhoProdutos([FromQuery] int dias = 30)
    {
        dias = Math.Clamp(dias, 1, 365);
        var inicio = DateTime.UtcNow.Date.AddDays(-dias + 1);

        // Nome vem do próprio item do pedido (como no "Mais vendidos"): sobrevive a produto renomeado ou removido depois.
        // Agrupa em memória (como em Vendas(), acima): "g.First()" após GroupBy não é garantido traduzir para SQL.
        var itensVendidos = await db.Pedidos.AsNoTracking()
            .Where(p => p.CriadoEm >= inicio && !NaoContam.Contains(p.Status))
            .SelectMany(p => p.Itens)
            .ToListAsync();
        var vendas = itensVendidos.GroupBy(i => i.ProdutoId)
            .ToDictionary(g => g.Key, g => (Nome: g.First().NomeProduto, Unidades: g.Sum(i => i.Quantidade), Valor: g.Sum(i => i.Total)));

        var cliquesConfig = await db.Configuracoes.AsNoTracking()
            .Where(c => c.Chave.StartsWith(CatalogoController.PrefixoCliquesProduto)).ToListAsync();
        var cliques = new Dictionary<Guid, int>();
        foreach (var c in cliquesConfig)
            if (Guid.TryParse(c.Chave[CatalogoController.PrefixoCliquesProduto.Length..], out var id) && int.TryParse(c.Valor, out var n))
                cliques[id] = n;

        // Só para dar nome aos cliques de produto que nunca vendeu (sem venda, não tem NomeProduto salvo em lugar nenhum)
        var nomesAtivos = await db.Produtos.AsNoTracking().Where(p => p.Ativo).ToDictionaryAsync(p => p.Id, p => p.Nome);

        var todosIds = nomesAtivos.Keys.Union(vendas.Keys).Union(cliques.Keys).Distinct();
        return todosIds
            .Select(id =>
            {
                var temVenda = vendas.TryGetValue(id, out var v);
                var nome = temVenda ? v.Nome : nomesAtivos.GetValueOrDefault(id, "(produto removido)");
                return new ProdutoDesempenhoDto(nome, cliques.GetValueOrDefault(id, 0), temVenda ? v.Unidades : 0, temVenda ? v.Valor : 0);
            })
            .Where(x => x.Cliques > 0 || x.Unidades > 0)
            .OrderByDescending(x => x.Cliques).ThenByDescending(x => x.Unidades)
            .Take(40)
            .ToList();
    }

    /// <summary>Relatório de vendas em Excel, com uma aba por visão.</summary>
    [HttpGet("vendas/exportar")]
    public async Task<IActionResult> Exportar([FromQuery] int dias = 30)
    {
        var r = await Vendas(dias);
        using var wb = new XLWorkbook();

        var resumo = wb.AddWorksheet("Resumo");
        resumo.Cell(1, 1).Value = "Período (dias)"; resumo.Cell(1, 2).Value = dias;
        resumo.Cell(2, 1).Value = "Faturamento"; resumo.Cell(2, 2).Value = r.Faturamento;
        resumo.Cell(3, 1).Value = "Pedidos"; resumo.Cell(3, 2).Value = r.Pedidos;
        resumo.Cell(4, 1).Value = "Ticket médio"; resumo.Cell(4, 2).Value = r.TicketMedio;
        resumo.Cell(5, 1).Value = "Clientes novos"; resumo.Cell(5, 2).Value = r.ClientesNovos;
        resumo.Range(2, 2, 2, 2).Style.NumberFormat.Format = "R$ #,##0.00";
        resumo.Range(4, 2, 4, 2).Style.NumberFormat.Format = "R$ #,##0.00";
        resumo.Column(1).Style.Font.Bold = true;

        void Aba(string nome, string[] cabecalho, IEnumerable<object[]> linhas)
        {
            var ws = wb.AddWorksheet(nome);
            for (var i = 0; i < cabecalho.Length; i++) ws.Cell(1, i + 1).Value = cabecalho[i];
            var l = 2;
            foreach (var linha in linhas)
            {
                for (var c = 0; c < linha.Length; c++) ws.Cell(l, c + 1).Value = XLCellValue.FromObject(linha[c]);
                l++;
            }
            ws.Row(1).Style.Font.Bold = true;
            ws.Columns().AdjustToContents();
        }

        Aba("Por dia", ["Dia", "Pedidos", "Valor"], r.PorDia.Select(x => new object[] { x.Dia.ToString("dd/MM/yyyy"), x.Pedidos, x.Valor }));
        Aba("Por categoria", ["Categoria", "Unidades", "Valor"], r.PorCategoria.Select(x => new object[] { x.Categoria, x.Unidades, x.Valor }));
        Aba("Mais vendidos", ["Produto", "Unidades", "Valor"], r.MaisVendidos.Select(x => new object[] { x.Produto, x.Unidades, x.Valor }));
        Aba("Por vendedor", ["Vendedor", "Pedidos", "Valor"], r.PorVendedor.Select(x => new object[] { x.Vendedor, x.Pedidos, x.Valor }));

        var ms = new MemoryStream();
        wb.SaveAs(ms);
        ms.Position = 0;
        return File(ms, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"vendas-{DateTime.Now:yyyyMMdd}.xlsx");
    }
}
