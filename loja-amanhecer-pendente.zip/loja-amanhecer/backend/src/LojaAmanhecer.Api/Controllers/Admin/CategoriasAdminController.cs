using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Domain.Catalogo;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Controllers.Admin;

[ApiController]
[Route("api/admin/categorias")]
[Authorize(Policy = Politicas.Equipe)]
public class CategoriasAdminController(LojaDbContext db, IProcessadorImagens imagens, IArmazenamentoArquivos arquivos, IConfiguration configuracao) : ControllerBase
{
    /// <summary>Todas as categorias (inclusive inativas) em árvore.</summary>
    [HttpGet]
    public async Task<List<CategoriaDto>> Listar()
    {
        var todas = await db.Categorias.AsNoTracking().OrderBy(c => c.Ordem).ToListAsync();
        foreach (var c in todas) c.Subcategorias = todas.Where(s => s.CategoriaPaiId == c.Id).ToList();
        return todas.Where(c => c.CategoriaPaiId is null).Select(c => c.ParaDto()).ToList();
    }

    /// <summary>
    /// Lista pronta para o campo de categoria do cadastro de produtos: categorias e subcategorias
    /// ativas, já na ordem e com o caminho montado ("Coletes › Colete de Apará").
    /// Ao editar um produto, passe o id da categoria atual em <c>incluirId</c>: ela entra na lista
    /// mesmo desativada, para o produto não perder o vínculo.
    /// </summary>
    [HttpGet("opcoes")]
    public async Task<List<CategoriaOpcaoDto>> Opcoes([FromQuery] Guid? incluirId)
    {
        var todas = await db.Categorias.AsNoTracking().OrderBy(c => c.Ordem).ThenBy(c => c.Nome).ToListAsync();
        var produtos = await db.Produtos.AsNoTracking()
            .GroupBy(p => p.CategoriaId).Select(g => new { g.Key, Qtd = g.Count() })
            .ToDictionaryAsync(x => x.Key, x => x.Qtd);

        var opcoes = new List<CategoriaOpcaoDto>();
        foreach (var pai in todas.Where(c => c.CategoriaPaiId is null))
        {
            var subs = todas.Where(s => s.CategoriaPaiId == pai.Id).ToList();
            if (Mostrar(pai)) opcoes.Add(Montar(pai, null));
            foreach (var sub in subs.Where(Mostrar)) opcoes.Add(Montar(sub, pai));
        }
        return opcoes;

        bool Mostrar(Categoria c) => c.Ativa || c.Id == incluirId;
        CategoriaOpcaoDto Montar(Categoria c, Categoria? pai) => new(
            c.Id, c.Nome, pai?.Nome,
            pai is null ? c.Nome : $"{pai.Nome} › {c.Nome}",
            c.Ativa, pai is not null, produtos.GetValueOrDefault(c.Id));
    }

    [HttpPost]
    public async Task<ActionResult<CategoriaDto>> Criar(SalvarCategoriaDto dto)
    {
        await ValidarPaiAsync(null, dto.CategoriaPaiId);
        var c = new Categoria
        {
            Nome = dto.Nome.Trim(), Descricao = dto.Descricao, ImagemUrl = dto.ImagemUrl,
            Ordem = dto.Ordem, Ativa = dto.Ativa, CategoriaPaiId = dto.CategoriaPaiId,
            Slug = await SlugUnicoAsync(dto.Nome, dto.CategoriaPaiId)
        };
        db.Categorias.Add(c);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(Listar), c.ParaDto());
    }

    [HttpPut("{id:guid}")]
    public async Task<ActionResult<CategoriaDto>> Atualizar(Guid id, SalvarCategoriaDto dto)
    {
        var c = await db.Categorias.FindAsync(id);
        if (c is null) return NotFound();
        await ValidarPaiAsync(id, dto.CategoriaPaiId);
        c.Nome = dto.Nome.Trim(); c.Descricao = dto.Descricao;
        // a foto é gerenciada pelos endpoints /imagem; o formulário não a apaga sem querer
        if (!string.IsNullOrWhiteSpace(dto.ImagemUrl)) c.ImagemUrl = dto.ImagemUrl;
        c.Ordem = dto.Ordem; c.Ativa = dto.Ativa; c.CategoriaPaiId = dto.CategoriaPaiId;
        await db.SaveChangesAsync();
        return c.ParaDto();
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Excluir(Guid id)
    {
        var c = await db.Categorias.FindAsync(id);
        if (c is null) return NotFound();
        if (await db.Categorias.AnyAsync(x => x.CategoriaPaiId == id))
            throw new RegraNegocioException("Remova ou mova as subcategorias antes de excluir.");
        if (await db.Produtos.AnyAsync(p => p.CategoriaId == id))
            throw new RegraNegocioException("Há produtos nesta categoria. Mova-os ou apenas desative a categoria.");
        db.Categorias.Remove(c);
        await db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>
    /// Envia a foto da categoria ou subcategoria. Aceita as mesmas fotos de produto (inclusive HEIC do celular),
    /// corrige a orientação, recorta no enquadramento escolhido e gera a versão quadrada do medalhão.
    /// Enviar de novo troca a foto e apaga a anterior.
    /// </summary>
    [HttpPost("{id:guid}/imagem")]
    [RequestSizeLimit(long.MaxValue)]
    [RequestFormLimits(MultipartBodyLengthLimit = long.MaxValue)]
    public async Task<ActionResult<CategoriaDto>> EnviarImagem(Guid id, IFormFile foto,
        [FromForm] int? recorteX, [FromForm] int? recorteY, [FromForm] int? recorteLargura, [FromForm] int? recorteAltura,
        CancellationToken ct)
    {
        var c = await db.Categorias.Include(x => x.Subcategorias).FirstOrDefaultAsync(x => x.Id == id, ct);
        if (c is null) return NotFound();
        if (foto is null || foto.Length == 0) throw new RegraNegocioException("Selecione uma foto.");

        var limiteMb = configuracao.GetValue("Imagens:TamanhoMaximoMb", 60);
        if (foto.Length > limiteMb * 1024L * 1024L)
            throw new RegraNegocioException($"A foto tem {foto.Length / 1048576.0:F0} MB e passa do limite de {limiteMb} MB.");
        if (!imagens.Aceita(foto.FileName, foto.ContentType))
            throw new RegraNegocioException("Formato não aceito. Use JPG, PNG, WEBP, AVIF ou HEIC.");

        Recorte? recorte = recorteLargura is > 0 && recorteAltura is > 0
            ? new Recorte(recorteX ?? 0, recorteY ?? 0, recorteLargura.Value, recorteAltura.Value)
            : null;

        var anteriores = new[] { c.ImagemUrl, c.ImagemMiniaturaUrl, c.ImagemOriginalUrl };

        await using var conteudo = foto.OpenReadStream();
        var r = await imagens.ProcessarQuadradoAsync(conteudo, foto.FileName, recorte, ct);
        c.ImagemUrl = r.UrlCatalogo;
        c.ImagemMiniaturaUrl = r.UrlMiniatura;
        c.ImagemOriginalUrl = r.UrlOriginal;
        await db.SaveChangesAsync(ct);

        await ApagarArquivosAsync(anteriores, ct);
        return c.ParaDto();
    }

    /// <summary>Remove a foto: a loja volta a exibir a ilustração padrão da categoria.</summary>
    [HttpDelete("{id:guid}/imagem")]
    public async Task<IActionResult> RemoverImagem(Guid id, CancellationToken ct)
    {
        var c = await db.Categorias.FirstOrDefaultAsync(x => x.Id == id, ct);
        if (c is null) return NotFound();
        var anteriores = new[] { c.ImagemUrl, c.ImagemMiniaturaUrl, c.ImagemOriginalUrl };
        c.ImagemUrl = null; c.ImagemMiniaturaUrl = null; c.ImagemOriginalUrl = null;
        await db.SaveChangesAsync(ct);
        await ApagarArquivosAsync(anteriores, ct);
        return NoContent();
    }

    private async Task ApagarArquivosAsync(IEnumerable<string?> urls, CancellationToken ct)
    {
        foreach (var url in urls.Where(u => !string.IsNullOrWhiteSpace(u)))
            await arquivos.RemoverAsync(url!, ct);
    }

    // Apenas 2 níveis: categoria → subcategoria
    private async Task ValidarPaiAsync(Guid? id, Guid? paiId)
    {
        if (paiId is null) return;
        if (paiId == id) throw new RegraNegocioException("A categoria não pode ser pai dela mesma.");
        var pai = await db.Categorias.AsNoTracking().FirstOrDefaultAsync(c => c.Id == paiId)
                  ?? throw new RegraNegocioException("Categoria pai não encontrada.");
        if (pai.CategoriaPaiId is not null) throw new RegraNegocioException("Subcategorias não podem ter subcategorias.");
    }

    private async Task<string> SlugUnicoAsync(string nome, Guid? paiId)
    {
        var pai = paiId is null ? null : await db.Categorias.AsNoTracking().FirstAsync(c => c.Id == paiId);
        var baseSlug = Slug.Gerar(pai is null ? nome : $"{pai.Nome}-{nome}");
        var slug = baseSlug; var n = 2;
        while (await db.Categorias.AnyAsync(c => c.Slug == slug)) slug = $"{baseSlug}-{n++}";
        return slug;
    }
}
