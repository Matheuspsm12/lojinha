using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Api.Seguranca;
using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Clientes;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Domain.Seguranca;
using LojaAmanhecer.Infrastructure.Dados;
using LojaAmanhecer.Infrastructure.Dados.Seed;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Controllers;

/// <summary>
/// Entrada do painel administrativo. Só quem tem um dos perfis de Painel:PerfisPermitidos
/// (hoje, apenas Administrador) recebe token. Todas as tentativas ficam registradas.
/// </summary>
[ApiController]
[Route("api/painel/auth")]
public class PainelAuthController(
    LojaDbContext db,
    UserManager<Usuario> usuarios,
    GeradorToken tokens,
    ServicoAcesso acessos,
    IConfiguration config) : ControllerBase
{
    private const string NaoAutorizado = "Acesso não autorizado";

    [HttpPost("login")]
    public async Task<ActionResult<TokenDto>> Login(LoginDto dto)
    {
        var email = dto.Email.Trim();
        var u = await usuarios.FindByEmailAsync(email);

        if (u is null)
        {
            await acessos.RegistrarAsync(email, false, MotivosAcesso.UsuarioInexistente);
            return Unauthorized(new { detalhe = NaoAutorizado });
        }
        if (await usuarios.IsLockedOutAsync(u))
        {
            await acessos.RegistrarAsync(email, false, MotivosAcesso.ContaBloqueada, usuarioId: u.Id);
            var minutos = config.GetValue("Seguranca:MinutosDeBloqueio", 15);
            return Unauthorized(new { detalhe = $"Conta bloqueada por {minutos} minutos após várias senhas incorretas." });
        }
        if (!u.Ativo)
        {
            await acessos.RegistrarAsync(email, false, MotivosAcesso.ContaInativa, usuarioId: u.Id);
            return Unauthorized(new { detalhe = NaoAutorizado });
        }
        if (!await usuarios.CheckPasswordAsync(u, dto.Senha))
        {
            await usuarios.AccessFailedAsync(u);
            await acessos.RegistrarAsync(email, false, MotivosAcesso.SenhaIncorreta, usuarioId: u.Id);
            return Unauthorized(new { detalhe = NaoAutorizado });
        }

        var perfis = await usuarios.GetRolesAsync(u);
        if (!perfis.Intersect(AcessoPainelHandler.PerfisPermitidos(config)).Any())
        {
            // Senha certa, mas o perfil não tem acesso ao painel (ex.: cliente ou vendedor)
            await acessos.RegistrarAsync(email, false, MotivosAcesso.SemPermissao, usuarioId: u.Id);
            return StatusCode(StatusCodes.Status403Forbidden, new { detalhe = NaoAutorizado });
        }

        await usuarios.ResetAccessFailedCountAsync(u);
        await acessos.RegistrarAsync(email, true, MotivosAcesso.Ok, usuarioId: u.Id);
        return Ok(await tokens.GerarAsync(u));
    }

    /// <summary>Dados da sessão atual; o painel usa para saber se o token ainda vale.</summary>
    [HttpGet("eu")]
    [Authorize(Policy = Politicas.Equipe)]
    public async Task<ActionResult<SessaoDto>> Eu()
    {
        var u = await usuarios.FindByIdAsync(User.UsuarioId().ToString());
        if (u is null) return Unauthorized(new { detalhe = NaoAutorizado });
        var expira = DateTime.UtcNow.AddHours(config.GetValue("Jwt:HorasValidadePainel", 8));
        return new SessaoDto(u.Id, u.NomeCompleto, u.Email!, await usuarios.GetRolesAsync(u), u.DeveTrocarSenha, expira);
    }

    /// <summary>Sair da conta: troca o carimbo de segurança, o que invalida os tokens emitidos.</summary>
    [HttpPost("sair")]
    [Authorize(Policy = Politicas.Equipe)]
    public async Task<IActionResult> Sair()
    {
        var u = await usuarios.FindByIdAsync(User.UsuarioId().ToString());
        if (u is null) return NoContent();
        await usuarios.UpdateSecurityStampAsync(u);
        await acessos.RegistrarAsync(u.Email!, true, MotivosAcesso.Saida, usuarioId: u.Id);
        return NoContent();
    }

    /// <summary>Tentativas de acesso registradas, para o administrador acompanhar.</summary>
    [HttpGet("/api/admin/acessos")]
    [Authorize(Policy = Politicas.Administrador)]
    public async Task<List<RegistroAcessoDto>> Acessos([FromQuery] int dias = 30, [FromQuery] bool somenteRecusados = false, [FromQuery] int limite = 200)
    {
        var inicio = DateTime.UtcNow.AddDays(-Math.Clamp(dias, 1, 365));
        var q = db.RegistrosAcesso.AsNoTracking().Where(r => r.CriadoEm >= inicio);
        if (somenteRecusados) q = q.Where(r => !r.Sucesso);
        return await q.OrderByDescending(r => r.CriadoEm).Take(Math.Clamp(limite, 1, 500))
            .Select(r => new RegistroAcessoDto(r.CriadoEm, r.Email, r.Sucesso, r.Motivo, r.Origem, r.Ip, r.Navegador))
            .ToListAsync();
    }
}

/// <summary>Criação da primeira conta administradora, só enquanto não existir nenhuma.</summary>
[ApiController]
[Route("api/instalacao")]
public class InstalacaoController(
    LojaDbContext db,
    UserManager<Usuario> usuarios,
    GeradorToken tokens,
    ServicoAcesso acessos) : ControllerBase
{
    [HttpGet("situacao")]
    public async Task<SituacaoInstalacaoDto> Situacao() =>
        new(!(await usuarios.GetUsersInRoleAsync(Perfis.Administrador)).Any());

    [HttpPost("administrador")]
    public async Task<ActionResult<TokenDto>> CriarPrimeiroAdministrador(CriarPrimeiroAdminDto dto)
    {
        if ((await usuarios.GetUsersInRoleAsync(Perfis.Administrador)).Any())
            throw new RegraNegocioException("Já existe uma conta administradora. Use a tela de entrada do painel.");

        var guardado = await db.Configuracoes.FindAsync(SemeadorInicial.ChaveTokenInstalacao);
        if (guardado is null || string.IsNullOrWhiteSpace(guardado.Valor))
            throw new RegraNegocioException("Nenhum token de instalação ativo. Reinicie a API para gerar um novo.");

        var informado = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(
            System.Text.Encoding.UTF8.GetBytes(dto.TokenInstalacao.Trim())));
        if (!System.Security.Cryptography.CryptographicOperations.FixedTimeEquals(
                System.Text.Encoding.UTF8.GetBytes(informado), System.Text.Encoding.UTF8.GetBytes(guardado.Valor)))
        {
            await acessos.RegistrarAsync(dto.Email, false, MotivosAcesso.SemPermissao, "instalacao");
            return Unauthorized(new { detalhe = "Token de instalação inválido." });
        }

        var u = new Usuario { UserName = dto.Email.Trim(), Email = dto.Email.Trim(), EmailConfirmed = true, NomeCompleto = dto.NomeCompleto.Trim() };
        var r = await usuarios.CreateAsync(u, dto.Senha);
        if (!r.Succeeded) throw new RegraNegocioException(ErrosIdentity.Traduzir(r.Errors));
        await usuarios.AddToRoleAsync(u, Perfis.Administrador);

        guardado.Valor = "";   // token de uso único: queima depois de usado
        await db.SaveChangesAsync();

        await acessos.RegistrarAsync(u.Email!, true, MotivosAcesso.PrimeiroAdministrador, "instalacao", u.Id);
        return Ok(await tokens.GerarAsync(u));
    }
}
