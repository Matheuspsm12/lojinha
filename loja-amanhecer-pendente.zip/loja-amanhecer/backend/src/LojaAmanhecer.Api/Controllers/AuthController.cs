using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Clientes;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Domain.Seguranca;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace LojaAmanhecer.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController(UserManager<Usuario> usuarios, GeradorToken tokens, LojaAmanhecer.Api.Seguranca.ServicoAcesso acessos,
    IServicoLoginGoogle loginGoogle) : ControllerBase
{
    /// <summary>Cria a conta do cliente e já devolve o token de acesso.</summary>
    [HttpPost("registrar")]
    public async Task<ActionResult<TokenDto>> Registrar(RegistrarDto dto)
    {
        var u = new Usuario
        {
            UserName = dto.Email.Trim(), Email = dto.Email.Trim(),
            NomeCompleto = dto.NomeCompleto.Trim(), PhoneNumber = dto.Telefone, Cpf = dto.Cpf
        };
        var r = await usuarios.CreateAsync(u, dto.Senha);
        if (!r.Succeeded)
            throw new LojaAmanhecer.Domain.Comum.RegraNegocioException(LojaAmanhecer.Api.Seguranca.ErrosIdentity.Traduzir(r.Errors));

        await usuarios.AddToRoleAsync(u, Perfis.Cliente);
        return Ok(await tokens.GerarAsync(u));
    }

    [HttpPost("login")]
    public async Task<ActionResult<TokenDto>> Login(LoginDto dto)
    {
        var email = dto.Email.Trim();
        var u = await usuarios.FindByEmailAsync(email);
        if (u is null || !u.Ativo)
        {
            await acessos.RegistrarAsync(email, false, u is null ? MotivosAcesso.UsuarioInexistente : MotivosAcesso.ContaInativa, "loja", u?.Id);
            return Unauthorized(new { detalhe = "E-mail ou senha incorretos." });
        }
        if (await usuarios.IsLockedOutAsync(u))
        {
            await acessos.RegistrarAsync(email, false, MotivosAcesso.ContaBloqueada, "loja", u.Id);
            return Unauthorized(new { detalhe = "Conta bloqueada temporariamente. Tente em alguns minutos." });
        }
        if (!await usuarios.CheckPasswordAsync(u, dto.Senha))
        {
            await usuarios.AccessFailedAsync(u);
            await acessos.RegistrarAsync(email, false, MotivosAcesso.SenhaIncorreta, "loja", u.Id);
            return Unauthorized(new { detalhe = "E-mail ou senha incorretos." });
        }
        await usuarios.ResetAccessFailedCountAsync(u);
        await acessos.RegistrarAsync(email, true, MotivosAcesso.Ok, "loja", u.Id);
        return Ok(await tokens.GerarAsync(u));
    }

    /// <summary>
    /// Login (ou cadastro automático, no primeiro acesso) com o token do botão "Continuar com o Google".
    /// O identificador do Google fica ligado à conta (tabela de logins externos do Identity), então
    /// os próximos acessos não dependem mais do e-mail continuar o mesmo.
    /// </summary>
    [HttpPost("google")]
    public async Task<ActionResult<TokenDto>> LoginComGoogle(LoginGoogleDto dto)
    {
        var info = await loginGoogle.ValidarAsync(dto.Credencial);
        if (info is null)
            return Unauthorized(new { detalhe = "Não foi possível confirmar a conta do Google." });
        if (!info.EmailVerificado)
            return Unauthorized(new { detalhe = "O e-mail da conta do Google ainda não foi verificado." });

        var u = await usuarios.FindByLoginAsync("Google", info.IdentificadorGoogle);

        if (u is null)
        {
            u = await usuarios.FindByEmailAsync(info.Email);
            if (u is null)
            {
                // Primeiro acesso por este e-mail: cadastro automático, sem senha (só entra pelo Google)
                u = new Usuario { UserName = info.Email, Email = info.Email, NomeCompleto = info.Nome, EmailConfirmed = true };
                var criar = await usuarios.CreateAsync(u);
                if (!criar.Succeeded)
                    throw new LojaAmanhecer.Domain.Comum.RegraNegocioException(LojaAmanhecer.Api.Seguranca.ErrosIdentity.Traduzir(criar.Errors));
                await usuarios.AddToRoleAsync(u, Perfis.Cliente);
            }

            // Liga a conta do Google à conta (recém-criada ou já existente por senha), para os próximos acessos
            await usuarios.AddLoginAsync(u, new UserLoginInfo("Google", info.IdentificadorGoogle, "Google"));
        }

        if (!u.Ativo)
        {
            await acessos.RegistrarAsync(info.Email, false, MotivosAcesso.ContaInativa, "loja", u.Id);
            return Unauthorized(new { detalhe = "Conta inativa." });
        }

        await acessos.RegistrarAsync(info.Email, true, MotivosAcesso.Ok, "loja", u.Id);
        return Ok(await tokens.GerarAsync(u));
    }
}
