using System.Web;
using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Api.Seguranca;
using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Clientes;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Seguranca;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace LojaAmanhecer.Api.Controllers;

/// <summary>Troca e recuperação de senha, para o painel e para a loja.</summary>
[ApiController]
[Route("api")]
public class SenhaController(
    UserManager<Usuario> usuarios,
    GeradorToken tokens,
    IServicoEmail email,
    ServicoAcesso acessos,
    IConfiguration config,
    ILogger<SenhaController> log) : ControllerBase
{
    /// <summary>Troca a senha de quem está logado. Ao trocar, as sessões antigas deixam de valer.</summary>
    [HttpPost("conta/senha")]
    [Authorize]
    public async Task<ActionResult<TokenDto>> Alterar(AlterarSenhaDto dto)
    {
        var u = await usuarios.FindByIdAsync(User.UsuarioId().ToString());
        if (u is null) return Unauthorized();

        var r = await usuarios.ChangePasswordAsync(u, dto.SenhaAtual, dto.NovaSenha);
        if (!r.Succeeded) throw new RegraNegocioException(ErrosIdentity.Traduzir(r.Errors));

        if (u.DeveTrocarSenha) { u.DeveTrocarSenha = false; await usuarios.UpdateAsync(u); }
        await usuarios.UpdateSecurityStampAsync(u);
        await acessos.RegistrarAsync(u.Email!, true, MotivosAcesso.SenhaAlterada, usuarioId: u.Id);

        // devolve um token novo para a pessoa continuar usando o sistema sem entrar de novo
        return Ok(await tokens.GerarAsync(await usuarios.FindByIdAsync(u.Id.ToString()) ?? u));
    }

    /// <summary>
    /// Pede o link de recuperação por e-mail. A resposta é sempre a mesma, exista a conta ou não,
    /// para não revelar quais e-mails estão cadastrados.
    /// </summary>
    [HttpPost("auth/senha/esqueci")]
    public async Task<IActionResult> Esqueci(EsqueciSenhaDto dto)
    {
        var resposta = Ok(new { detalhe = "Se este e-mail estiver cadastrado, enviaremos o link de recuperação em instantes." });
        var u = await usuarios.FindByEmailAsync(dto.Email.Trim());
        if (u is null || !u.Ativo) { log.LogInformation("Recuperação pedida para e-mail sem conta ativa"); return resposta; }

        var token = await usuarios.GeneratePasswordResetTokenAsync(u);
        var painel = dto.Origem == "painel";
        var baseUrl = (painel ? config["Urls:Painel"] ?? $"{config["Urls:Loja"]}/painel" : config["Urls:Loja"]) ?? "http://localhost:3000";
        var link = $"{baseUrl.TrimEnd('/')}/redefinir-senha?email={HttpUtility.UrlEncode(u.Email)}&token={HttpUtility.UrlEncode(token)}";

        await email.EnviarAsync(u.Email!, "Recuperação de senha", $@"
<div style=""font-family:Arial,Helvetica,sans-serif;background:#F4F0FC;padding:24px"">
  <div style=""max-width:520px;margin:auto;background:#fff;border-radius:14px;padding:24px;color:#2B2140"">
    <h2 style=""color:#3E2A6E;margin-top:0"">Recuperação de senha</h2>
    <p>Recebemos um pedido para criar uma senha nova para esta conta.</p>
    <p><a href=""{link}"" style=""background:#3E2A6E;color:#fff;padding:12px 20px;border-radius:99px;text-decoration:none;display:inline-block"">Criar nova senha</a></p>
    <p style=""font-size:13px;color:#6A5F80"">O link vale por algumas horas e só pode ser usado uma vez. Se não foi você quem pediu, ignore este e-mail: nada muda.</p>
  </div>
</div>");

        await acessos.RegistrarAsync(u.Email!, true, "RecuperacaoSolicitada", painel ? "painel" : "loja", u.Id);
        return resposta;
    }

    /// <summary>Redefine a senha com o token recebido por e-mail.</summary>
    [HttpPost("auth/senha/redefinir")]
    public async Task<IActionResult> Redefinir(RedefinirSenhaDto dto)
    {
        var u = await usuarios.FindByEmailAsync(dto.Email.Trim());
        if (u is null) throw new RegraNegocioException("Não foi possível redefinir a senha. Peça um link novo.");

        var r = await usuarios.ResetPasswordAsync(u, dto.Token, dto.NovaSenha);
        if (!r.Succeeded) throw new RegraNegocioException(ErrosIdentity.Traduzir(r.Errors));

        if (u.DeveTrocarSenha) { u.DeveTrocarSenha = false; }
        await usuarios.SetLockoutEndDateAsync(u, null);
        await usuarios.ResetAccessFailedCountAsync(u);
        await usuarios.UpdateSecurityStampAsync(u);
        await acessos.RegistrarAsync(u.Email!, true, MotivosAcesso.SenhaRedefinida, usuarioId: u.Id);
        return Ok(new { detalhe = "Senha alterada. Entre com a nova senha." });
    }
}
