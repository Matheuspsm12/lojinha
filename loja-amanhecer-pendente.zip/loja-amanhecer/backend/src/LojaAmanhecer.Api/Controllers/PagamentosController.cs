using LojaAmanhecer.Api.Servicos;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Controllers;

[ApiController]
[Route("api/pagamentos")]
public class PagamentosController(LojaDbContext db, IServicoPagamento gateway, ServicoCheckout checkout, LojaAmanhecer.Api.Servicos.ConfiguracaoPagamento configuracaoPagamento, ILogger<PagamentosController> log) : ControllerBase
{
    /// <summary>
    /// Aviso do Mercado Pago. A situação é sempre conferida na API do gateway antes de mudar o pedido.
    /// Responde 200 mesmo quando ignora o aviso, para o gateway não ficar reenviando.
    /// </summary>
    [HttpPost("webhook")]
    public async Task<IActionResult> Webhook()
    {
        using var leitor = new StreamReader(Request.Body);
        var corpo = await leitor.ReadToEndAsync();
        var cabecalhos = Request.Headers.ToDictionary(h => h.Key, h => h.Value.ToString());

        var aviso = await gateway.LerAvisoAsync(corpo, cabecalhos);
        if (aviso is null) return Ok();

        var pagamento = await db.Pagamentos.FirstOrDefaultAsync(p => p.GatewayId == aviso.GatewayId);
        if (pagamento is null) { log.LogWarning("Aviso de pagamento desconhecido: {Id}", aviso.GatewayId); return Ok(); }

        pagamento.Status = aviso.Status;
        pagamento.GatewayStatus = aviso.StatusOriginal;
        if (aviso.Status == StatusPagamento.Aprovado) pagamento.PagoEm ??= DateTime.UtcNow;

        // Taxa e líquido informados pelo provedor; sem eles, usa a taxa de referência da configuração
        var detalhe = await gateway.ConsultarAsync(aviso.GatewayId);
        var taxa = detalhe?.Taxa ?? Math.Round(pagamento.Valor * await configuracaoPagamento.TaxaAsync(pagamento.Metodo) / 100m, 2);
        pagamento.TaxaGateway = taxa;
        pagamento.ValorLiquido = detalhe?.Liquido ?? Math.Round(pagamento.Valor - taxa, 2);
        if (detalhe is not null && detalhe.ValorEstornado > 0) pagamento.ValorEstornado = detalhe.ValorEstornado;
        await db.SaveChangesAsync();

        var pedido = await db.Pedidos.Include(p => p.Itens).Include(p => p.Historico).FirstAsync(p => p.Id == pagamento.PedidoId);
        if (aviso.Status == StatusPagamento.Aprovado && pedido.PodeMudarPara(StatusPedido.PagamentoConfirmado))
            await checkout.MudarStatusAsync(pedido, StatusPedido.PagamentoConfirmado, pedido.ClienteId, "Confirmado pelo Mercado Pago");

        return Ok();
    }
}
