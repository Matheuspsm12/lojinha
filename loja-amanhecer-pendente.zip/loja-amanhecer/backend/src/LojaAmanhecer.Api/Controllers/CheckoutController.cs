using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Api.Servicos;
using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Clientes;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Controllers;

[ApiController]
[Route("api")]
public class CheckoutController(LojaDbContext db, ServicoCheckout checkout, IServicoCep cep,
    LojaAmanhecer.Api.Seguranca.ServicoAcesso acessos) : ControllerBase
{
    /// <summary>Endereço a partir do CEP (ViaCEP).</summary>
    [HttpGet("cep/{numero}")]
    public async Task<ActionResult<EnderecoCep>> Cep(string numero)
    {
        var r = await cep.ConsultarAsync(numero);
        return r is null ? NotFound(new { detalhe = "CEP não encontrado." }) : Ok(r);
    }

    /// <summary>Cotação de frete com prazo total (produção + transporte).</summary>
    [HttpPost("frete/cotar")]
    public async Task<ActionResult<List<OpcaoEntregaDto>>> Cotar(CotarFreteDto dto)
    {
        var itens = await checkout.ConferirItensAsync(dto.Itens);
        return await checkout.CotarAsync(dto.Cep, itens);
    }

    /// <summary>Formas de pagamento ativas e regras de parcelamento, para a loja montar o checkout.</summary>
    [HttpGet("pagamentos/opcoes")]
    public async Task<OpcoesPagamentoDto> OpcoesPagamento() => await checkout.OpcoesPagamentoAsync();

    /// <summary>Fecha o pedido e gera a cobrança.</summary>
    [HttpPost("pedidos")]
    [Authorize]
    public async Task<ActionResult<PedidoDto>> Criar(CriarPedidoDto dto)
    {
        var cliente = await db.Users.FirstOrDefaultAsync(u => u.Id == User.UsuarioId())
            ?? throw new RegraNegocioException("Faça login novamente para finalizar o pedido.");
        var (pedido, cobranca) = await checkout.CriarPedidoAsync(cliente, dto);
        return CreatedAtAction(nameof(Obter), new { numero = pedido.Numero }, pedido.ParaDto(cobranca));
    }

    /// <summary>Pedidos do cliente logado.</summary>
    [HttpGet("pedidos")]
    [Authorize]
    public async Task<List<PedidoDto>> Meus()
    {
        var id = User.UsuarioId();
        var pedidos = await db.Pedidos.AsNoTracking().Include(p => p.Itens).Include(p => p.Pagamentos).Include(p => p.Historico)
            .Where(p => p.ClienteId == id).OrderByDescending(p => p.Numero).AsSplitQuery().ToListAsync();
        return pedidos.Select(p => p.ParaDto()).ToList();
    }

    /// <summary>
    /// Detalhe de um pedido do próprio cliente. O dono vem sempre da conta autenticada:
    /// trocar o número na URL não abre o pedido de outra pessoa — a resposta é 404, igual
    /// à de um pedido inexistente, para não revelar que aquele número existe.
    /// </summary>
    [HttpGet("pedidos/{numero:long}")]
    [Authorize]
    public async Task<ActionResult<PedidoDto>> Obter(long numero)
    {
        var id = User.UsuarioId();
        var p = await db.Pedidos.AsNoTracking().Include(x => x.Itens).Include(x => x.Pagamentos).Include(x => x.Historico)
            .AsSplitQuery().FirstOrDefaultAsync(x => x.Numero == numero && x.ClienteId == id);

        if (p is null)
        {
            // Se o pedido existe mas é de outra conta, fica registrado para auditoria
            if (await db.Pedidos.AnyAsync(x => x.Numero == numero))
                await acessos.RegistrarAsync(User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value ?? "",
                    false, "PedidoDeOutroCliente", "loja", id);
            return NotFound(new { detalhe = "Pedido não encontrado na sua conta." });
        }
        return p.ParaDto();
    }
}

[ApiController]
[Route("api/conta")]
[Authorize]
public class ContaController(LojaDbContext db) : ControllerBase
{
    [HttpGet("dados")]
    public async Task<ActionResult<object>> Dados()
    {
        var u = await db.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == User.UsuarioId());
        return u is null ? NotFound() : Ok(new { u.Id, u.NomeCompleto, u.Email, Telefone = u.PhoneNumber, u.Cpf });
    }

    [HttpPut("dados")]
    public async Task<IActionResult> Atualizar(AtualizarDadosDto dto)
    {
        var u = await db.Users.FirstOrDefaultAsync(x => x.Id == User.UsuarioId());
        if (u is null) return NotFound();
        if (string.IsNullOrWhiteSpace(dto.NomeCompleto)) throw new RegraNegocioException("Informe o nome completo.");
        u.NomeCompleto = dto.NomeCompleto.Trim(); u.PhoneNumber = dto.Telefone; u.Cpf = dto.Cpf;
        await db.SaveChangesAsync();
        return NoContent();
    }

    [HttpGet("enderecos")]
    public async Task<List<EnderecoDto>> Enderecos()
    {
        var id = User.UsuarioId();
        return await db.Enderecos.AsNoTracking().Where(e => e.UsuarioId == id)
            .OrderByDescending(e => e.Principal).ThenBy(e => e.Apelido)
            .Select(e => new EnderecoDto(e.Id, e.Apelido, e.Destinatario, e.Cep, e.Logradouro, e.Numero, e.Complemento, e.Bairro, e.Cidade, e.Uf, e.Principal))
            .ToListAsync();
    }

    [HttpPost("enderecos")]
    public async Task<ActionResult<EnderecoDto>> Criar(EnderecoDto dto)
    {
        var id = User.UsuarioId();
        Validar(dto);
        var e = new Endereco
        {
            UsuarioId = id, Apelido = dto.Apelido, Destinatario = dto.Destinatario, Cep = dto.Cep, Logradouro = dto.Logradouro,
            Numero = dto.Numero, Complemento = dto.Complemento, Bairro = dto.Bairro, Cidade = dto.Cidade, Uf = dto.Uf.ToUpperInvariant(),
            Principal = dto.Principal || !await db.Enderecos.AnyAsync(x => x.UsuarioId == id)
        };
        if (e.Principal) await db.Enderecos.Where(x => x.UsuarioId == id).ExecuteUpdateAsync(s => s.SetProperty(x => x.Principal, false));
        db.Enderecos.Add(e);
        await db.SaveChangesAsync();
        return dto with { Id = e.Id, Principal = e.Principal };
    }

    [HttpPut("enderecos/{id:guid}")]
    public async Task<IActionResult> Atualizar(Guid id, EnderecoDto dto)
    {
        Validar(dto);
        var usuario = User.UsuarioId();
        var e = await db.Enderecos.FirstOrDefaultAsync(x => x.Id == id && x.UsuarioId == usuario);
        if (e is null) return NotFound();
        if (dto.Principal && !e.Principal) await db.Enderecos.Where(x => x.UsuarioId == usuario).ExecuteUpdateAsync(s => s.SetProperty(x => x.Principal, false));
        e.Apelido = dto.Apelido; e.Destinatario = dto.Destinatario; e.Cep = dto.Cep; e.Logradouro = dto.Logradouro;
        e.Numero = dto.Numero; e.Complemento = dto.Complemento; e.Bairro = dto.Bairro; e.Cidade = dto.Cidade;
        e.Uf = dto.Uf.ToUpperInvariant(); e.Principal = dto.Principal || e.Principal;
        await db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("enderecos/{id:guid}")]
    public async Task<IActionResult> Excluir(Guid id)
    {
        var usuario = User.UsuarioId();
        var n = await db.Enderecos.Where(x => x.Id == id && x.UsuarioId == usuario).ExecuteDeleteAsync();
        return n == 0 ? NotFound() : NoContent();
    }

    private static void Validar(EnderecoDto e)
    {
        if (new string(e.Cep.Where(char.IsDigit).ToArray()).Length != 8) throw new RegraNegocioException("Informe um CEP válido.");
        if (string.IsNullOrWhiteSpace(e.Logradouro) || string.IsNullOrWhiteSpace(e.Numero)
            || string.IsNullOrWhiteSpace(e.Cidade) || e.Uf?.Length != 2)
            throw new RegraNegocioException("Preencha rua, número, cidade e UF.");
    }
}
