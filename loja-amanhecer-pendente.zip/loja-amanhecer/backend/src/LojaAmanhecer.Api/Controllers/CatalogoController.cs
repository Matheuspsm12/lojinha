using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Controllers;

/// <summary>Endpoints públicos da loja (vitrine).</summary>
[ApiController]
[Route("api")]
public class CatalogoController(LojaDbContext db, ILogger<CatalogoController> log) : ControllerBase
{
    /// <summary>
    /// Chave usada em "configuracoes" para contar cliques por produto (sem tabela nova: reaproveita a
    /// mesma chave/valor da loja). O incremento é feito com SQL direto (ON CONFLICT) para não perder
    /// contagem quando dois clientes clicam ao mesmo tempo.
    /// </summary>
    public const string PrefixoCliquesProduto = "analytics.cliques_produto.";
    /// <summary>Árvore de categorias ativas.</summary>
    [HttpGet("categorias")]
    public async Task<List<CategoriaDto>> Categorias()
    {
        var todas = await db.Categorias.AsNoTracking().Where(c => c.Ativa).OrderBy(c => c.Ordem).ToListAsync();
        // Monta a árvore em memória (poucas categorias)
        foreach (var c in todas) c.Subcategorias = todas.Where(s => s.CategoriaPaiId == c.Id).ToList();
        return todas.Where(c => c.CategoriaPaiId is null).Select(c => c.ParaDto()).ToList();
    }

    /// <summary>Lista produtos ativos com filtro por categoria (inclui subcategorias) e busca por texto.</summary>
    [HttpGet("produtos")]
    public async Task<PaginaDto<ProdutoResumoDto>> Produtos(
        [FromQuery] string? categoria, [FromQuery] string? busca, [FromQuery] bool? destaque,
        [FromQuery] string ordem = "relevancia", [FromQuery] int pagina = 1, [FromQuery] int tamanho = 24)
    {
        tamanho = Math.Clamp(tamanho, 1, 60);
        var q = db.Produtos.AsNoTracking().Where(p => p.Ativo && p.Categoria!.Ativa);

        if (!string.IsNullOrWhiteSpace(categoria))
            q = q.Where(p => p.Categoria!.Slug == categoria || p.Categoria.CategoriaPai!.Slug == categoria);

        if (!string.IsNullOrWhiteSpace(busca))
        {
            var termo = $"%{busca.Trim()}%";
            q = q.Where(p => EF.Functions.ILike(EF.Functions.Unaccent(p.Nome), EF.Functions.Unaccent(termo))
                          || EF.Functions.ILike(EF.Functions.Unaccent(p.Descricao), EF.Functions.Unaccent(termo))
                          || EF.Functions.ILike(EF.Functions.Unaccent(p.Categoria!.Nome), EF.Functions.Unaccent(termo)));
        }

        if (destaque == true) q = q.Where(p => p.Destaque);

        q = ordem switch
        {
            "menor-preco" => q.OrderBy(p => p.Preco),
            "maior-preco" => q.OrderByDescending(p => p.Preco),
            "novidades" => q.OrderByDescending(p => p.CriadoEm),
            _ => q.OrderByDescending(p => p.Destaque).ThenBy(p => p.Nome)
        };

        var total = await q.CountAsync();
        var itens = await q.Skip((pagina - 1) * tamanho).Take(tamanho)
            .Select(p => new ProdutoResumoDto(p.Id, p.Nome, p.Slug, p.Categoria!.Nome, p.Preco,
                p.Imagens.OrderBy(i => i.Ordem).Select(i => i.Url).FirstOrDefault(),
                p.Disponibilidade, p.PrazoProducaoDias,
                p.Variacoes.Any() ? p.Variacoes.Where(v => v.Ativa).Sum(v => v.Estoque) : p.Estoque,
                p.Ativo, p.Destaque,
                p.Imagens.OrderBy(i => i.Ordem).Select(i => i.Url).ToList()))
            .ToListAsync();

        return new PaginaDto<ProdutoResumoDto>(itens, pagina, tamanho, total);
    }

    [HttpGet("produtos/{slug}")]
    public async Task<ActionResult<ProdutoDetalheDto>> Produto(string slug)
    {
        var p = await db.Produtos.AsNoTracking()
            .Include(x => x.Categoria).ThenInclude(c => c!.CategoriaPai)
            .Include(x => x.Imagens).Include(x => x.Opcoes).Include(x => x.Variacoes)
            .AsSplitQuery()
            .FirstOrDefaultAsync(x => x.Slug == slug && x.Ativo);
        if (p is null) return NotFound();

        await RegistrarCliqueAsync(p.Id);
        return p.ParaDetalhe();
    }

    /// <summary>Conta mais uma visita à página do produto. Nunca derruba a página por causa disso.</summary>
    private async Task RegistrarCliqueAsync(Guid produtoId)
    {
        try
        {
            var chave = PrefixoCliquesProduto + produtoId;
            await db.Database.ExecuteSqlInterpolatedAsync(
                $"""
                INSERT INTO configuracoes (chave, valor, descricao) VALUES ({chave}, '1', 'Cliques no produto (contagem automática)')
                ON CONFLICT (chave) DO UPDATE SET valor = (configuracoes.valor::int + 1)::text
                """);
        }
        catch (Exception ex)
        {
            log.LogWarning(ex, "Não foi possível contar o clique do produto {ProdutoId}", produtoId);
        }
    }
}
