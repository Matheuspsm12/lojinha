using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Domain.Clientes;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Enums;
using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;

namespace LojaAmanhecer.Api.Infra;

public static class Politicas
{
    public const string Equipe = "Equipe";               // administradores e vendedores
    public const string Administrador = "SomenteAdmin";
}

public class GeradorToken(IConfiguration config, UserManager<Usuario> usuarios)
{
    public async Task<TokenDto> GerarAsync(Usuario u)
    {
        var perfis = await usuarios.GetRolesAsync(u);
        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, u.Id.ToString()),
            new(JwtRegisteredClaimNames.Email, u.Email!),
            new(ClaimTypes.NameIdentifier, u.Id.ToString()),
            new(ClaimTypes.Name, u.NomeCompleto),
            new(LojaAmanhecer.Api.Seguranca.ClaimsPainel.Carimbo, u.SecurityStamp ?? "")
        };
        claims.AddRange(perfis.Select(p => new Claim(ClaimTypes.Role, p)));

        // Sessão do painel dura menos que a da loja
        var ehEquipe = perfis.Any(p => p is Perfis.Administrador or Perfis.Vendedor);
        var horas = ehEquipe ? config.GetValue("Jwt:HorasValidadePainel", 8) : config.GetValue("Jwt:HorasValidade", 12);
        var expira = DateTime.UtcNow.AddHours(horas);
        var chave = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Chave"]!));
        var token = new JwtSecurityToken(config["Jwt:Emissor"], config["Jwt:Publico"], claims,
            expires: expira, signingCredentials: new SigningCredentials(chave, SecurityAlgorithms.HmacSha256));

        return new TokenDto(new JwtSecurityTokenHandler().WriteToken(token), expira, u.NomeCompleto, u.Email!, perfis, u.DeveTrocarSenha);
    }
}

/// <summary>Converte exceções em respostas padronizadas (ProblemDetails).</summary>
public class TratamentoErros(RequestDelegate next, ILogger<TratamentoErros> log)
{
    public async Task InvokeAsync(HttpContext ctx)
    {
        try { await next(ctx); }
        catch (RegraNegocioException ex)
        {
            ctx.Response.StatusCode = StatusCodes.Status422UnprocessableEntity;
            await ctx.Response.WriteAsJsonAsync(new { titulo = "Regra de negócio", detalhe = ex.Message });
        }
        catch (Exception ex)
        {
            log.LogError(ex, "Erro não tratado");
            ctx.Response.StatusCode = StatusCodes.Status500InternalServerError;
            await ctx.Response.WriteAsJsonAsync(new { titulo = "Erro interno", detalhe = "Ocorreu um erro inesperado. Tente novamente." });
        }
    }
}

public static class ClaimsExtensoes
{
    public static Guid UsuarioId(this ClaimsPrincipal u) =>
        Guid.Parse(u.FindFirstValue(ClaimTypes.NameIdentifier)!);

    /// <summary>E-mail de quem está logado, usado nos registros de auditoria.</summary>
    public static string EmailUsuario(this ClaimsPrincipal u) =>
        u.FindFirstValue(ClaimTypes.Email) ?? u.FindFirstValue(JwtRegisteredClaimNames.Email) ?? "";
}
