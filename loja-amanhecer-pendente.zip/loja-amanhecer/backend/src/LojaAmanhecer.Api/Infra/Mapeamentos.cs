using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Domain.Catalogo;

namespace LojaAmanhecer.Api.Infra;

public static class Mapeamentos
{
    public static ProdutoImagemDto ParaDto(this Domain.Catalogo.ProdutoImagem i) =>
        new(i.Id, i.Url, i.TextoAlternativo, i.Ordem, i.Miniatura, i.Grande, i.UrlOriginal, i.Largura, i.Altura);

    public static CategoriaDto ParaDto(this Categoria c) => new(
        c.Id, c.Nome, c.Slug, c.Descricao, c.ImagemUrl, c.Ordem, c.Ativa, c.CategoriaPaiId,
        c.Subcategorias.OrderBy(s => s.Ordem).Select(s => s.ParaDto()).ToList(),
        c.ImagemMiniaturaUrl ?? c.ImagemUrl, c.ImagemOriginalUrl, c.TemFoto);

    public static ProdutoDetalheDto ParaDetalhe(this Produto p) => new(
        p.Id, p.Nome, p.Slug, p.Descricao,
        p.CategoriaId, p.Categoria?.Nome ?? "", p.Categoria?.CategoriaPaiId, p.Categoria?.CategoriaPai?.Nome,
        p.Preco, p.Estoque, p.EstoqueTotal,
        p.PesoGramas, p.AlturaCm, p.LarguraCm, p.ComprimentoCm,
        p.Disponibilidade, p.PrazoProducaoDias,
        p.PermitePersonalizacao, p.RotuloPersonalizacao, p.LimiteCaracteresPersonalizacao, p.ValorPersonalizacao,
        p.Ativo, p.Destaque,
        p.Imagens.OrderBy(i => i.Ordem).Select(i => i.ParaDto()).ToList(),
        p.Opcoes.OrderBy(o => o.Ordem).Select(o => new ProdutoOpcaoDto(o.Nome, o.Ordem, o.Valores)).ToList(),
        p.Variacoes.Select(v => new ProdutoVariacaoDto(v.Id, v.Sku, v.Atributos, v.Preco, v.Estoque, v.Ativa)).ToList());
}

public static class MapeamentosPedido
{
    public static string Texto(this Domain.Enums.StatusPedido s) => LojaAmanhecer.Infrastructure.Integracoes.ModelosEmail.Texto(s);

    public static EnderecoEntregaDto ParaDto(this Domain.Pedidos.EnderecoEntrega e) =>
        new(e.Destinatario, e.Cep, e.Logradouro, e.Numero, e.Complemento, e.Bairro, e.Cidade, e.Uf);

    public static List<PedidoItemDto> ItensDto(this Domain.Pedidos.Pedido p) =>
        p.Itens.Select(i => new PedidoItemDto(i.NomeProduto, i.DescricaoVariacao, i.Personalizacao, i.PrecoUnitario, i.Quantidade, i.Total)).ToList();

    public static PagamentoDto? PagamentoDto(this Domain.Pedidos.Pedido p, CobrancaCriada? cobranca = null)
    {
        var pg = p.Pagamentos.OrderByDescending(x => x.CriadoEm).FirstOrDefault();
        if (pg is null) return null;
        return new PagamentoDto(pg.Metodo, pg.Status, pg.Valor, cobranca?.QrCodePix, cobranca?.QrCodeBase64, cobranca?.LinkBoleto, cobranca?.LinkCheckout);
    }

    public static List<HistoricoDto> HistoricoDto(this Domain.Pedidos.Pedido p) =>
        p.Historico.OrderBy(h => h.CriadoEm).Select(h => new HistoricoDto(h.StatusNovo, h.CriadoEm, h.Comentario)).ToList();

    public static PedidoDto ParaDto(this Domain.Pedidos.Pedido p, CobrancaCriada? cobranca = null) => new(
        p.Id, p.Numero, p.NumeroFormatado, p.Status, p.Status.Texto(), p.CriadoEm, p.Subtotal, p.ValorFrete, p.Total,
        p.FormaEntrega, p.PrazoProducaoDias, p.PrazoTransporteDias, p.PrazoTotalDias, p.CodigoRastreio, p.ObservacaoCliente,
        p.EnderecoEntrega.ParaDto(), p.ItensDto(), p.PagamentoDto(cobranca), p.HistoricoDto());

    public static PedidoAdminDto ParaAdminDto(this Domain.Pedidos.Pedido p, Domain.Clientes.Usuario cliente, string? vendedor, IEnumerable<Domain.Enums.StatusPedido> proximos) => new(
        p.Id, p.Numero, p.NumeroFormatado, p.Status, p.Status.Texto(), p.CriadoEm,
        cliente.NomeCompleto, cliente.Email ?? "", cliente.PhoneNumber, p.VendedorId, vendedor,
        p.Subtotal, p.ValorFrete, p.Total, p.FormaEntrega, p.PrazoProducaoDias, p.PrazoTransporteDias,
        p.CodigoRastreio, p.EtiquetaId, p.ObservacaoCliente, p.ObservacaoInterna,
        p.EnderecoEntrega.ParaDto(), p.ItensDto(), p.PagamentoDto(), p.HistoricoDto(), proximos.ToList());
}
