using System.Security.Claims;
using System.Text;
using System.Text.Json.Serialization;
using LojaAmanhecer.Api.Infra;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Infrastructure;
using LojaAmanhecer.Infrastructure.Dados;
using LojaAmanhecer.Infrastructure.Dados.Seed;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);
var config = builder.Configuration;

builder.Services.AdicionarInfraestrutura(config);
builder.Services.AddScoped<GeradorToken>();
builder.Services.AddScoped<LojaAmanhecer.Api.Servicos.ServicoCheckout>();
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<LojaAmanhecer.Api.Seguranca.ServicoAcesso>();
builder.Services.AddSingleton<LojaAmanhecer.Api.Seguranca.Cofre>();
builder.Services.AddScoped<LojaAmanhecer.Api.Servicos.ConfiguracaoPagamento>();
builder.Services.AddScoped<LojaAmanhecer.Application.Integracoes.IFonteCredencialPagamento>(sp =>
    sp.GetRequiredService<LojaAmanhecer.Api.Servicos.ConfiguracaoPagamento>());
builder.Services.AddScoped<LojaAmanhecer.Application.Integracoes.IServicoPagamento, LojaAmanhecer.Api.Servicos.ServicoPagamentoDinamico>();
builder.Services.AddScoped<Microsoft.AspNetCore.Authorization.IAuthorizationHandler, LojaAmanhecer.Api.Seguranca.AcessoPainelHandler>();

// Fotos grandes de celular: libera o tamanho do envio (o limite real é conferido no controller)
builder.Services.Configure<Microsoft.AspNetCore.Http.Features.FormOptions>(o =>
{
    o.MultipartBodyLengthLimit = long.MaxValue;
    o.ValueLengthLimit = int.MaxValue;
    o.MemoryBufferThreshold = 1024 * 1024;   // acima disso, o upload vai para disco em vez de memória
});
builder.WebHost.ConfigureKestrel(o => o.Limits.MaxRequestBodySize = null);

builder.Services.AddControllers()
    .AddJsonOptions(o => o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));

// Autenticação JWT
var chaveJwt = config["Jwt:Chave"] ?? throw new InvalidOperationException("Configure Jwt:Chave");
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(o =>
    {
        o.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true, ValidIssuer = config["Jwt:Emissor"],
            ValidateAudience = true, ValidAudience = config["Jwt:Publico"],
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(chaveJwt)),
            ClockSkew = TimeSpan.FromMinutes(1)
        };
        // Respostas padronizadas: o painel usa isso para mandar de volta ao login
        o.Events = new JwtBearerEvents
        {
            // Confere no banco a CADA requisição autenticada (loja e painel): conta desativada ou senha
            // trocada/redefinida derrubam o token na hora, mesmo que ele ainda não tenha expirado.
            // Antes, essa conferência só existia nas rotas do painel (AcessoPainelHandler); um token da
            // loja roubado continuava valendo até expirar sozinho mesmo depois do cliente trocar a senha.
            OnTokenValidated = async ctx =>
            {
                var principal = ctx.Principal;
                if (principal is null || !Guid.TryParse(principal.FindFirstValue(ClaimTypes.NameIdentifier), out var id))
                {
                    ctx.Fail("Token inválido.");
                    return;
                }

                var db = ctx.HttpContext.RequestServices.GetRequiredService<LojaDbContext>();
                var conta = await db.Users.AsNoTracking().Where(u => u.Id == id)
                    .Select(u => new { u.Ativo, u.SecurityStamp }).FirstOrDefaultAsync();
                if (conta is null || !conta.Ativo) { ctx.Fail("Conta inativa."); return; }

                var carimbo = principal.FindFirstValue(LojaAmanhecer.Api.Seguranca.ClaimsPainel.Carimbo);
                if (!string.IsNullOrEmpty(conta.SecurityStamp) && carimbo != conta.SecurityStamp)
                    ctx.Fail("Sessão encerrada. Entre novamente.");
            },
            OnChallenge = async ctx =>
            {
                ctx.HandleResponse();
                ctx.Response.StatusCode = StatusCodes.Status401Unauthorized;
                ctx.Response.ContentType = "application/json";
                await ctx.Response.WriteAsJsonAsync(new { detalhe = "Faça login para continuar.", entrarEm = "/painel" });
            },
            OnForbidden = async ctx =>
            {
                ctx.Response.StatusCode = StatusCodes.Status403Forbidden;
                ctx.Response.ContentType = "application/json";
                var motivo = ctx.HttpContext.Items["motivoRecusa"] as string ?? "Acesso não autorizado";
                await ctx.Response.WriteAsJsonAsync(new { detalhe = motivo });
            }
        };
    });

// Acesso ao painel: hoje só Administrador (Painel:PerfisPermitidos).
// Os perfis e as telas de vendedor continuam existindo, prontos para serem liberados depois.
builder.Services.AddAuthorizationBuilder()
    .AddPolicy(Politicas.Equipe, p => p.AddRequirements(new LojaAmanhecer.Api.Seguranca.AcessoPainelRequirement()))
    .AddPolicy(Politicas.Administrador, p =>
    {
        p.RequireRole(Perfis.Administrador);
        p.AddRequirements(new LojaAmanhecer.Api.Seguranca.AcessoPainelRequirement());
    });

builder.Services.AddCors(o => o.AddDefaultPolicy(p => p
    .WithOrigins(config.GetSection("Cors:Origens").Get<string[]>() ?? ["http://localhost:3000"])
    .AllowAnyHeader().AllowAnyMethod()));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Loja Amanhecer API", Version = "v1" });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Type = SecuritySchemeType.Http, Scheme = "bearer", BearerFormat = "JWT",
        Description = "Cole o token retornado em /api/auth/login"
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        [new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } }] = []
    });
});

var app = builder.Build();

// Migrações e dados iniciais na subida (controlado por configuração)
if (config.GetValue("Banco:AplicarMigracoesAoIniciar", true))
{
    using var escopo = app.Services.CreateScope();
    await escopo.ServiceProvider.GetRequiredService<LojaDbContext>().Database.MigrateAsync();
    await escopo.ServiceProvider.GetRequiredService<SemeadorInicial>().ExecutarAsync();
}

LojaAmanhecer.Infrastructure.InjecaoDependencia.AvisarIntegracoesSimuladas(config, app.Services.GetRequiredService<ILoggerFactory>().CreateLogger("Integracoes"));

app.UseMiddleware<TratamentoErros>();

if (app.Environment.IsDevelopment() || config.GetValue("Swagger:Habilitado", false))
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

var pastaUploads = Path.GetFullPath(config["Armazenamento:PastaLocal"] ?? "uploads");
Directory.CreateDirectory(pastaUploads);
app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(pastaUploads),
    RequestPath = "/uploads",
    // cada versão gerada tem nome único, então pode ficar em cache no navegador
    OnPrepareResponse = ctx => ctx.Context.Response.Headers.CacheControl = "public,max-age=31536000,immutable"
});

app.UseCors();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapGet("/api/saude", () => Results.Ok(new { status = "ok", horario = DateTime.UtcNow }));

app.Run();


/// <summary>Torna a API acessível aos testes de integração.</summary>
public partial class Program;
