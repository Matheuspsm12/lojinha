using LojaAmanhecer.Api.Seguranca;
using LojaAmanhecer.Domain.Configuracoes;
using LojaAmanhecer.Infrastructure.Dados;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Servicos;

/// <summary>De onde veio a credencial em uso.</summary>
public enum FonteCredencial { Nenhuma, VariavelDeAmbiente, Painel }

public record CredencialPagamento(string? AccessToken, bool Sandbox, FonteCredencial Fonte);

/// <summary>
/// Configuração de pagamentos guardada na tabela de configurações da loja.
/// O Access Token fica cifrado; a ordem de preferência é:
/// 1. variável de ambiente / appsettings (MercadoPago:AccessToken) — ideal em produção;
/// 2. credencial cadastrada pelo administrador no painel (cifrada no banco);
/// 3. nenhuma: a loja segue no modo simulado.
/// </summary>
public class ConfiguracaoPagamento(LojaDbContext db, IConfiguration config, Cofre cofre) : LojaAmanhecer.Application.Integracoes.IFonteCredencialPagamento
{
    public const string ChaveToken = "pagamento.mp.access_token";
    public const string ChaveAmbiente = "pagamento.mp.ambiente";           // "teste" ou "producao"
    public const string ChaveApelido = "pagamento.mp.conta";               // e-mail/apelido da conta conectada
    public const string ChavePix = "pagamento.metodo.pix";
    public const string ChaveCartao = "pagamento.metodo.cartao";
    public const string ChaveBoleto = "pagamento.metodo.boleto";
    public const string ChaveMaxParcelas = "pagamento.parcelas.maximo";
    public const string ChaveJuros = "pagamento.parcelas.com_juros";
    public const string ChaveMinimoParcela = "pagamento.parcelas.valor_minimo";
    public const string ChaveTaxaPix = "pagamento.taxa.pix";
    public const string ChaveTaxaCartao = "pagamento.taxa.cartao";
    public const string ChaveTaxaBoleto = "pagamento.taxa.boleto";
    public const string ChaveUltimoTeste = "pagamento.mp.ultimo_teste";

    private Dictionary<string, string>? _cache;

    private async Task<Dictionary<string, string>> ValoresAsync()
        => _cache ??= await db.Configuracoes.AsNoTracking()
            .Where(c => c.Chave.StartsWith("pagamento."))
            .ToDictionaryAsync(c => c.Chave, c => c.Valor);

    public async Task<string> TextoAsync(string chave, string padrao = "")
        => (await ValoresAsync()).GetValueOrDefault(chave) is { Length: > 0 } v ? v : padrao;

    public async Task<bool> BoolAsync(string chave, bool padrao) =>
        bool.TryParse(await TextoAsync(chave), out var b) ? b : padrao;

    public async Task<int> InteiroAsync(string chave, int padrao) =>
        int.TryParse(await TextoAsync(chave), out var n) ? n : padrao;

    public async Task<decimal> DecimalAsync(string chave, decimal padrao) =>
        decimal.TryParse(await TextoAsync(chave), System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture, out var d) ? d : padrao;

    public async Task GravarAsync(string chave, string valor, string? descricao = null)
    {
        var atual = await db.Configuracoes.FirstOrDefaultAsync(c => c.Chave == chave);
        if (atual is null) db.Configuracoes.Add(new ConfiguracaoLoja { Chave = chave, Valor = valor, Descricao = descricao });
        else { atual.Valor = valor; if (descricao is not null) atual.Descricao = descricao; }
        _cache = null;
    }

    /// <summary>Credencial em uso, já decifrada. Nunca sai da API.</summary>
    public async Task<CredencialPagamento> CredencialAsync()
    {
        var doAmbiente = config["MercadoPago:AccessToken"];
        var ambiente = await TextoAsync(ChaveAmbiente, config["MercadoPago:Sandbox"] == "false" ? "producao" : "teste");
        var sandbox = ambiente != "producao";

        if (!string.IsNullOrWhiteSpace(doAmbiente))
            return new CredencialPagamento(doAmbiente, sandbox, FonteCredencial.VariavelDeAmbiente);

        var guardado = cofre.Decifrar(await TextoAsync(ChaveToken));
        return string.IsNullOrWhiteSpace(guardado)
            ? new CredencialPagamento(null, sandbox, FonteCredencial.Nenhuma)
            : new CredencialPagamento(guardado, sandbox, FonteCredencial.Painel);
    }

    public async Task<(string? AccessToken, bool Sandbox)> ObterAsync(CancellationToken ct = default)
    {
        var c = await CredencialAsync();
        return (c.AccessToken, c.Sandbox);
    }

    public async Task<bool> ConectadoAsync() => (await CredencialAsync()).AccessToken is { Length: > 0 };

    /// <summary>Taxa estimada do provedor para o método, em % do valor.</summary>
    public async Task<decimal> TaxaAsync(Domain.Enums.MetodoPagamento metodo) => metodo switch
    {
        Domain.Enums.MetodoPagamento.Pix => await DecimalAsync(ChaveTaxaPix, 0.99m),
        Domain.Enums.MetodoPagamento.CartaoCredito => await DecimalAsync(ChaveTaxaCartao, 4.98m),
        Domain.Enums.MetodoPagamento.Boleto => await DecimalAsync(ChaveTaxaBoleto, 3.49m),
        _ => 0m
    };
}
