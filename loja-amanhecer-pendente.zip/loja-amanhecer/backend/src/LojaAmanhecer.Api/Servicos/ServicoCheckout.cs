using LojaAmanhecer.Application.Dtos;
using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Catalogo;
using LojaAmanhecer.Domain.Clientes;
using LojaAmanhecer.Domain.Comum;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Domain.Pedidos;
using LojaAmanhecer.Domain.Servicos;
using LojaAmanhecer.Infrastructure.Dados;
using LojaAmanhecer.Infrastructure.Integracoes;
using Microsoft.EntityFrameworkCore;

namespace LojaAmanhecer.Api.Servicos;

/// <summary>Item do carrinho já conferido contra o catálogo.</summary>
public record ItemConferido(Produto Produto, ProdutoVariacao? Variacao, int Quantidade, string? Personalizacao, decimal PrecoUnitario, int PrazoProducaoDias)
{
    public decimal Total => PrecoUnitario * Quantidade;
}

/// <summary>Regras do carrinho, do frete e da criação do pedido.</summary>
public class ServicoCheckout(LojaDbContext db, IServicoFrete frete, IServicoPagamento pagamentos, IServicoEmail email, ConfiguracaoPagamento configuracaoPagamento, ILogger<ServicoCheckout> log)
{
    public const int ServicoRetirada = 0;

    public async Task<string> ConfiguracaoAsync(string chave, string padrao = "") =>
        (await db.Configuracoes.AsNoTracking().FirstOrDefaultAsync(c => c.Chave == chave))?.Valor ?? padrao;

    /// <summary>Confere os itens contra o catálogo e calcula preços e prazos (nunca confia nos valores do cliente).</summary>
    public async Task<List<ItemConferido>> ConferirItensAsync(List<ItemCarrinhoDto> itens)
    {
        if (itens is null || itens.Count == 0) throw new RegraNegocioException("O carrinho está vazio.");

        var ids = itens.Select(i => i.ProdutoId).Distinct().ToList();
        var produtos = await db.Produtos.Include(p => p.Variacoes).Where(p => ids.Contains(p.Id)).ToListAsync();
        var conferidos = new List<ItemConferido>();

        foreach (var item in itens)
        {
            if (item.Quantidade < 1) throw new RegraNegocioException("A quantidade precisa ser pelo menos 1.");
            var produto = produtos.FirstOrDefault(p => p.Id == item.ProdutoId)
                ?? throw new RegraNegocioException("Um dos produtos do carrinho não existe mais.");
            if (!produto.Ativo) throw new RegraNegocioException($"O produto \"{produto.Nome}\" não está mais disponível.");

            ProdutoVariacao? variacao = null;
            if (produto.Variacoes.Count > 0)
            {
                if (item.VariacaoId is null) throw new RegraNegocioException($"Escolha uma opção para \"{produto.Nome}\".");
                variacao = produto.Variacoes.FirstOrDefault(v => v.Id == item.VariacaoId && v.Ativa)
                    ?? throw new RegraNegocioException($"A opção escolhida para \"{produto.Nome}\" não está mais disponível.");
            }

            var personalizacao = item.Personalizacao?.Trim();
            if (!string.IsNullOrEmpty(personalizacao))
            {
                if (!produto.PermitePersonalizacao) throw new RegraNegocioException($"O produto \"{produto.Nome}\" não aceita personalização.");
                if (produto.LimiteCaracteresPersonalizacao is int limite && personalizacao.Length > limite)
                    throw new RegraNegocioException($"A personalização de \"{produto.Nome}\" aceita até {limite} caracteres.");
            }
            else personalizacao = null;

            var preco = produto.PrecoPara(variacao) + (personalizacao is null ? 0 : produto.ValorPersonalizacao);
            conferidos.Add(new ItemConferido(produto, variacao, item.Quantidade, personalizacao, preco,
                produto.PrazoProducaoPara(item.Quantidade, variacao)));
        }
        return conferidos;
    }

    /// <summary>Opções de entrega com o prazo já somado: produção + transporte.</summary>
    public async Task<List<OpcaoEntregaDto>> CotarAsync(string cep, List<ItemConferido> itens)
    {
        if (new string(cep.Where(char.IsDigit).ToArray()).Length != 8)
            throw new RegraNegocioException("Informe um CEP válido, com 8 números.");

        var producao = CalculadoraPrazo.PrazoProducao(itens.Select(i => i.PrazoProducaoDias));
        var pacotes = itens.Select(i => new PacoteFrete(i.Produto.PesoGramas, i.Produto.AlturaCm, i.Produto.LarguraCm,
            i.Produto.ComprimentoCm, i.Total, i.Quantidade));

        var opcoes = (await frete.CotarAsync(cep, pacotes))
            .Select(o => new OpcaoEntregaDto(o.ServicoId, $"{o.Transportadora} {o.Servico}".Trim(), o.Valor,
                o.PrazoDias, producao, producao + o.PrazoDias, null))
            .ToList();

        if ((await ConfiguracaoAsync("frete.retirada_habilitada", "false")).Equals("true", StringComparison.OrdinalIgnoreCase))
            opcoes.Add(new OpcaoEntregaDto(ServicoRetirada, "Retirada no local", 0, 0, producao, producao,
                await ConfiguracaoAsync("frete.retirada_endereco", "Combine o horário pelo WhatsApp")));

        if (opcoes.Count == 0) throw new RegraNegocioException("Nenhuma transportadora atende este CEP no momento.");
        return opcoes.OrderBy(o => o.Valor).ToList();
    }

    /// <summary>Formas de pagamento ativas, definidas pelo administrador em Pagamentos e recebimentos.</summary>
    public async Task<OpcoesPagamentoDto> OpcoesPagamentoAsync() => new(
        Pix: await configuracaoPagamento.BoolAsync(ConfiguracaoPagamento.ChavePix, true),
        Cartao: await configuracaoPagamento.BoolAsync(ConfiguracaoPagamento.ChaveCartao, true),
        Boleto: await configuracaoPagamento.BoolAsync(ConfiguracaoPagamento.ChaveBoleto, true),
        MaximoParcelas: await configuracaoPagamento.InteiroAsync(ConfiguracaoPagamento.ChaveMaxParcelas, 3),
        ComJuros: await configuracaoPagamento.BoolAsync(ConfiguracaoPagamento.ChaveJuros, false),
        ValorMinimoParcela: await configuracaoPagamento.DecimalAsync(ConfiguracaoPagamento.ChaveMinimoParcela, 30m));

    private async Task GarantirMetodoAtivoAsync(MetodoPagamento metodo)
    {
        var o = await OpcoesPagamentoAsync();
        var ativo = metodo switch
        {
            MetodoPagamento.Pix => o.Pix,
            MetodoPagamento.CartaoCredito => o.Cartao,
            MetodoPagamento.Boleto => o.Boleto,
            _ => true   // confirmação manual continua valendo para o vendedor
        };
        if (!ativo) throw new RegraNegocioException("Esta forma de pagamento não está disponível no momento. Escolha outra.");
    }

    /// <summary>Cria o pedido, gera a cobrança e avisa cliente e equipe.</summary>
    public async Task<(Pedido Pedido, CobrancaCriada Cobranca)> CriarPedidoAsync(Usuario cliente, CriarPedidoDto dto)
    {
        await GarantirMetodoAtivoAsync(dto.MetodoPagamento);
        var itens = await ConferirItensAsync(dto.Itens);
        var endereco = await ResolverEnderecoAsync(cliente, dto);
        var opcoes = await CotarAsync(endereco.Cep, itens);
        var escolhida = opcoes.FirstOrDefault(o => o.ServicoId == dto.ServicoFreteId)
            ?? throw new RegraNegocioException("A forma de entrega escolhida não está mais disponível. Recalcule o frete.");

        var pedido = new Pedido
        {
            ClienteId = cliente.Id,
            Subtotal = itens.Sum(i => i.Total),
            ValorFrete = escolhida.Valor,
            FormaEntrega = escolhida.Nome,
            ServicoFreteId = escolhida.ServicoId == ServicoRetirada ? null : escolhida.ServicoId,
            PrazoProducaoDias = escolhida.PrazoProducaoDias,
            PrazoTransporteDias = escolhida.PrazoTransporteDias,
            ObservacaoCliente = string.IsNullOrWhiteSpace(dto.Observacao) ? null : dto.Observacao.Trim(),
            EnderecoEntrega = new EnderecoEntrega
            {
                Destinatario = endereco.Destinatario, Cep = endereco.Cep, Logradouro = endereco.Logradouro,
                Numero = endereco.Numero, Complemento = endereco.Complemento, Bairro = endereco.Bairro,
                Cidade = endereco.Cidade, Uf = endereco.Uf
            },
            Itens = itens.Select(i => new PedidoItem
            {
                ProdutoId = i.Produto.Id, VariacaoId = i.Variacao?.Id, NomeProduto = i.Produto.Nome,
                DescricaoVariacao = i.Variacao?.Descricao, Personalizacao = i.Personalizacao,
                PrecoUnitario = i.PrecoUnitario, Quantidade = i.Quantidade, PrazoProducaoDias = i.PrazoProducaoDias
            }).ToList()
        };

        // Baixa do estoque de quem é pronta entrega (reserva para o cliente)
        await BaixarEstoqueAsync(itens);

        db.Pedidos.Add(pedido);
        pedido.AlterarStatus(StatusPedido.AguardandoPagamento, cliente.Id, "Pedido registrado pela loja");
        await db.SaveChangesAsync();   // grava para obter o número da sequência

        var cobranca = await pagamentos.CriarCobrancaAsync(pedido, cliente.Email!, cliente.NomeCompleto, dto.MetodoPagamento);
        var pagamento = new Pagamento
        {
            PedidoId = pedido.Id, Metodo = dto.MetodoPagamento, Valor = pedido.Total,
            GatewayId = cobranca.GatewayId, GatewayStatus = cobranca.Status,
            Status = ServicoPagamentoMercadoPago.Converter(cobranca.Status),
            Ambiente = await configuracaoPagamento.ConectadoAsync()
                ? (await configuracaoPagamento.CredencialAsync()).Sandbox ? "teste" : "producao"
                : "simulado"
        };
        pedido.Pagamentos.Add(pagamento);
        db.Entry(pagamento).State = EntityState.Added;   // o Id já vem preenchido pela entidade
        await db.SaveChangesAsync();

        await AvisarNovoPedidoAsync(pedido, cliente);
        return (pedido, cobranca);
    }

    /// <summary>
    /// Baixa atômica no banco (UPDATE ... GREATEST(estoque - quantidade, 0)), não em memória: dois pedidos
    /// do mesmo produto ao mesmo tempo não se perdem (cada UPDATE parte do valor atual na linha, não de uma
    /// cópia lida antes). Pedir mais que o estoque pronto continua permitido de propósito — vira prazo de
    /// produção para a diferença (ver Produto.PrazoProducaoPara) — então o estoque só é "piso zero", nunca recusa.
    /// </summary>
    private async Task BaixarEstoqueAsync(List<ItemConferido> itens)
    {
        foreach (var i in itens.Where(x => x.Produto.Disponibilidade == TipoDisponibilidade.ProntaEntrega))
        {
            if (i.Variacao is not null)
                await db.Database.ExecuteSqlInterpolatedAsync(
                    $"UPDATE produto_variacoes SET estoque = GREATEST(estoque - {i.Quantidade}, 0) WHERE id = {i.Variacao.Id}");
            else
                await db.Database.ExecuteSqlInterpolatedAsync(
                    $"UPDATE produtos SET estoque = GREATEST(estoque - {i.Quantidade}, 0) WHERE id = {i.Produto.Id}");
        }
    }

    private async Task<Endereco> ResolverEnderecoAsync(Usuario cliente, CriarPedidoDto dto)
    {
        if (dto.EnderecoId is Guid id)
            return await db.Enderecos.FirstOrDefaultAsync(e => e.Id == id && e.UsuarioId == cliente.Id)
                ?? throw new RegraNegocioException("Endereço de entrega não encontrado.");

        if (dto.NovoEndereco is null) throw new RegraNegocioException("Informe o endereço de entrega.");
        var e = dto.NovoEndereco;
        if (new string(e.Cep.Where(char.IsDigit).ToArray()).Length != 8 || string.IsNullOrWhiteSpace(e.Logradouro)
            || string.IsNullOrWhiteSpace(e.Numero) || string.IsNullOrWhiteSpace(e.Cidade) || e.Uf.Length != 2)
            throw new RegraNegocioException("Preencha CEP, rua, número, cidade e UF do endereço.");

        var novo = new Endereco
        {
            UsuarioId = cliente.Id, Apelido = string.IsNullOrWhiteSpace(e.Apelido) ? "Endereço" : e.Apelido,
            Destinatario = string.IsNullOrWhiteSpace(e.Destinatario) ? cliente.NomeCompleto : e.Destinatario,
            Cep = e.Cep, Logradouro = e.Logradouro, Numero = e.Numero, Complemento = e.Complemento,
            Bairro = e.Bairro, Cidade = e.Cidade, Uf = e.Uf.ToUpperInvariant(),
            Principal = !await db.Enderecos.AnyAsync(x => x.UsuarioId == cliente.Id)
        };
        db.Enderecos.Add(novo);
        return novo;
    }

    private async Task AvisarNovoPedidoAsync(Pedido pedido, Usuario cliente)
    {
        var loja = await ConfiguracaoAsync("loja.nome", "Lojinha Do Vale");
        var whats = await ConfiguracaoAsync("loja.whatsapp");
        await email.EnviarAsync(cliente.Email!, $"Pedido {pedido.NumeroFormatado} recebido", ModelosEmail.Confirmacao(pedido, loja, whats));

        var equipe = await ConfiguracaoAsync("loja.email");
        if (!string.IsNullOrWhiteSpace(equipe))
            await email.EnviarAsync(equipe, $"Novo pedido {pedido.NumeroFormatado}",
                ModelosEmail.NovoPedidoParaEquipe(pedido, cliente.NomeCompleto, loja, await ConfiguracaoAsync("loja.url_painel", "")));
        log.LogInformation("Pedido {Numero} criado para {Cliente}", pedido.NumeroFormatado, cliente.Email);
    }

    /// <summary>Muda o status, grava o histórico e avisa o cliente por e-mail.</summary>
    public async Task MudarStatusAsync(Pedido pedido, StatusPedido novo, Guid usuarioId, string? comentario)
    {
        var historicoAntes = pedido.Historico.Count;
        pedido.AlterarStatus(novo, usuarioId, comentario);
        // Entidades com Id preenchido em um agregado já rastreado precisam ser marcadas como novas
        foreach (var h in pedido.Historico.Skip(historicoAntes)) db.Entry(h).State = EntityState.Added;
        if (novo == StatusPedido.Cancelado) await DevolverEstoqueAsync(pedido);
        await db.SaveChangesAsync();

        var cliente = await db.Users.FirstAsync(u => u.Id == pedido.ClienteId);
        await email.EnviarAsync(cliente.Email!, $"Pedido {pedido.NumeroFormatado}: {ModelosEmail.Texto(novo)}",
            ModelosEmail.MudancaStatus(pedido, await ConfiguracaoAsync("loja.nome", "Lojinha Do Vale"), await ConfiguracaoAsync("loja.whatsapp")));
    }

    /// <summary>Devolve com UPDATE direto no banco (não em memória), pelo mesmo motivo da baixa: dois
    /// cancelamentos do mesmo produto ao mesmo tempo não podem fazer um "pisar" na devolução do outro.</summary>
    private async Task DevolverEstoqueAsync(Pedido pedido)
    {
        foreach (var item in pedido.Itens)
        {
            var produto = await db.Produtos.AsNoTracking().FirstOrDefaultAsync(p => p.Id == item.ProdutoId);
            if (produto is null || produto.Disponibilidade != TipoDisponibilidade.ProntaEntrega) continue;
            if (item.VariacaoId is Guid vid)
                await db.Database.ExecuteSqlInterpolatedAsync($"UPDATE produto_variacoes SET estoque = estoque + {item.Quantidade} WHERE id = {vid}");
            else
                await db.Database.ExecuteSqlInterpolatedAsync($"UPDATE produtos SET estoque = estoque + {item.Quantidade} WHERE id = {produto.Id}");
        }
    }
}
