using LojaAmanhecer.Application.Integracoes;
using LojaAmanhecer.Domain.Enums;
using LojaAmanhecer.Domain.Pedidos;
using LojaAmanhecer.Infrastructure.Integracoes;

namespace LojaAmanhecer.Api.Servicos;

/// <summary>
/// Escolhe, a cada chamada, entre o Mercado Pago de verdade e o modo simulado.
/// Basta o administrador conectar a conta no painel (ou definir MercadoPago:AccessToken)
/// para a loja passar a cobrar de verdade — sem mexer em código e sem reiniciar nada.
/// </summary>
public class ServicoPagamentoDinamico(
    ConfiguracaoPagamento configuracao,
    ServicoPagamentoMercadoPago mercadoPago,
    ServicoPagamentoSimulado simulado) : IServicoPagamento
{
    private async Task<IServicoPagamento> EscolherAsync() =>
        await configuracao.ConectadoAsync() ? mercadoPago : simulado;

    public bool Real => configuracao.ConectadoAsync().GetAwaiter().GetResult();

    public async Task<CobrancaCriada> CriarCobrancaAsync(Pedido pedido, string emailPagador, string nomePagador, MetodoPagamento metodo, CancellationToken ct = default)
        => await (await EscolherAsync()).CriarCobrancaAsync(pedido, emailPagador, nomePagador, metodo, ct);

    public async Task<AvisoPagamento?> LerAvisoAsync(string corpo, IDictionary<string, string> cabecalhos, CancellationToken ct = default)
        => await (await EscolherAsync()).LerAvisoAsync(corpo, cabecalhos, ct);

    public async Task<DetalhePagamentoGateway?> ConsultarAsync(string gatewayId, CancellationToken ct = default)
        => await (await EscolherAsync()).ConsultarAsync(gatewayId, ct);

    public async Task<EstornoFeito> EstornarAsync(string gatewayId, decimal? valor, CancellationToken ct = default)
        => await (await EscolherAsync()).EstornarAsync(gatewayId, valor, ct);

    public async Task<(bool Ok, string Detalhe)> TestarConexaoAsync(CancellationToken ct = default)
        => await (await EscolherAsync()).TestarConexaoAsync(ct);
}
