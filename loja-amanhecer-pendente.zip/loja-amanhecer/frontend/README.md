# Frontend (Etapa 2)

A loja e o painel definitivos serão construídos aqui em **Next.js 14 + Tailwind** (Etapa 4), consumindo a API já pronta. O protótipo aprovado (`/prototipo/index.html`) é a especificação de telas, textos e fluxo.

O protótipo aprovado vira a especificação de telas, textos e fluxo. Os tokens de cor e tipografia abaixo serão levados para o `tailwind.config`:

| Token | Cor | Uso |
|---|---|---|
| ametista | `#3E2A6E` | botões principais, títulos, painel |
| ametista-escuro | `#2A1B4D` | rodapé, menu do painel |
| lilás | `#CDBDF0` / `#F4F0FC` | fundos suaves, seleção |
| ouro | `#A8832A` / `#E2C46B` | medalhões, destaques, botão finalizar |
| celeste | `#8FD0EA` / `#E8F6FC` | avisos, horizonte |
| branco | `#FFFFFF` | fundo da loja |

Tipografia: **Cormorant Garamond** (títulos) e **Figtree** (textos e números).

## Marca

A marca da loja está em [`publico/marca/`](publico/marca/), já recortada no círculo, com fundo
transparente e nos tamanhos de 32 a 512 px, em WebP e PNG, mais o `favicon.ico`. Use os mesmos
arquivos na loja, no painel e no ícone do navegador. Detalhes em
[publico/marca/LEIA-ME.md](publico/marca/LEIA-ME.md).
