# Marca da loja

Arquivos gerados a partir do selo "Lojinha Do Vale" enviado pelo cliente, recortada no círculo,
com o fundo removido e transparência nas bordas. Substitui o selo anterior ("Vale do Amanhecer").

| Arquivo | Uso |
|---|---|
| `marca-original.png` | 1242 × 1242, transparente. Fonte para gerar qualquer tamanho novo |
| `marca-512.*` | Ícone do aplicativo (PWA), compartilhamento |
| `marca-192.*` | Cabeçalho e painel em telas de alta densidade; ícone do celular |
| `marca-96.*` / `marca-64.*` | Cabeçalho e telas menores |
| `marca-48.*` / `marca-32.*` | Miniaturas e favicon |
| `favicon.ico` | Ícone do navegador (16, 32, 48 e 64 px no mesmo arquivo) |

Cada tamanho vem em **WebP** (menor, usado por padrão) e em **PNG** (para navegadores antigos).
Todos são quadrados, então a imagem nunca estica: é só definir largura e altura iguais e
`border-radius: 50%`.

No HTML:

```html
<link rel="icon" href="/marca/favicon.ico" sizes="any">
<link rel="apple-touch-icon" href="/marca/marca-192.png">
```

```html
<picture>
  <source srcset="/marca/marca-96.webp 1x, /marca/marca-192.webp 2x" type="image/webp">
  <img src="/marca/marca-96.png" width="38" height="38" alt="Lojinha Do Vale">
</picture>
```

O protótipo (`/prototipo/index.html`) leva a mesma imagem embutida, para continuar funcionando
como arquivo único.

## Banner da página inicial

Arte da **Lojinha do Vale — Artigos Doutrinários O.S.O.E.C.**, extraída do PDF enviado pelo cliente
em alta resolução (3982 × 486, proporção 8,19 : 1).

| Arquivo | Uso |
|---|---|
| `banner-original.png` | 3982 × 486, sem compressão. Fonte para gerar outros tamanhos |
| `banner-1920.*` | Telas grandes |
| `banner-1440.*` | Padrão do computador (é o que vai embutido no protótipo) |
| `banner-1280.*` / `banner-960.*` | Notebooks e tablets |
| `banner-640.*` | Celular |

Cada tamanho vem em **WebP** (menor) e **JPG** progressivo. A proporção é sempre a mesma, então a
arte nunca estica: basta `width: 100%; height: auto` com `aspect-ratio: 3982 / 486`.

```html
<img class="vitrine-arte" src="/marca/banner-1440.webp"
     srcset="/marca/banner-640.webp 640w, /marca/banner-960.webp 960w, /marca/banner-1440.webp 1440w, /marca/banner-1920.webp 1920w"
     sizes="(max-width: 760px) 92vw, min(1180px, 92vw)"
     width="1440" height="176" alt="Lojinha do Vale — Artigos Doutrinários O.S.O.E.C." fetchpriority="high">
```

O administrador troca essa arte pelo painel, em **Aparência**; quando não há arte enviada, a loja usa
os arquivos daqui.
