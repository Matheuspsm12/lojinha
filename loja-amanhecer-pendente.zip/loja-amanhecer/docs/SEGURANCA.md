# Segurança do painel

## Quem entra no painel

Hoje, **somente contas com o perfil `Administrador`**. Clientes e vendedores recebem `Acesso não autorizado`, mesmo com a senha certa.

A lista fica em `Painel:PerfisPermitidos` (arquivo de configuração ou variável de ambiente):

```json
"Painel": { "PerfisPermitidos": [ "Administrador" ] }
```

Para liberar os vendedores no futuro, acrescente `"Vendedor"` nessa lista e reinicie a API. Nada precisa ser reprogramado: o perfil Vendedor, a tela de vendedores, o "assumir pedido" e o histórico de quem atendeu cada ordem continuam inteiros no banco e na API.

## Onde fica o painel

Endereço `/painel`, com tela de entrada própria. Também funciona em um subdomínio separado (ex.: `painel.seudominio.com.br`): basta apontar o subdomínio para o mesmo frontend e ajustar `Urls:Painel`. A loja pública não tem nenhum link para o painel.

## Proteção no servidor, não só na tela

Toda rota `/api/admin/...` e `/api/painel/...` exige token válido **e** perfil permitido. As respostas são padronizadas:

| Situação | Resposta |
|---|---|
| Sem token ou token expirado | `401` com `{"detalhe":"Faça login para continuar.","entrarEm":"/painel"}` |
| Perfil sem acesso (cliente, vendedor) | `403` com `{"detalhe":"Acesso não autorizado"}` |
| Conta desativada | `403` com `{"detalhe":"Acesso não autorizado"}` |
| Senha trocada ou saída da conta | `403` com `{"detalhe":"Sessão encerrada. Entre novamente."}` |

Esconder o botão no frontend não muda nada: a checagem acontece no servidor a cada requisição, inclusive conferindo no banco se a conta continua ativa.

## Primeira conta administradora

Não existe senha padrão em produção. Ao subir a API com o banco vazio:

1. A API gera um **token de instalação de uso único**, grava no log e no arquivo `primeiro-acesso.txt` (ao lado do executável).
2. Abra `/painel`, informe o token, o nome, o e-mail e a senha da conta administradora.
3. O token é queimado no uso. `POST /api/instalacao/administrador` passa a recusar com "Já existe uma conta administradora".

Em desenvolvimento, `appsettings.Development.json` cria `admin@loja.local` / `Admin@12345` já marcado para trocar a senha no primeiro acesso. **Em produção, deixe `AdminInicial` vazio.**

Depois disso, novos administradores e vendedores são criados pelo painel, em Vendedores.

## Senha

- **Trocar a senha:** `POST /api/conta/senha` (senha atual + nova). Ao trocar, as sessões abertas em outros aparelhos deixam de valer e a pessoa recebe um token novo, sem precisar entrar de novo no aparelho em uso.
- **Esqueci minha senha:** `POST /api/auth/senha/esqueci` envia um link por e-mail. A resposta é sempre a mesma, exista a conta ou não, para não revelar quais e-mails estão cadastrados. O link vale algumas horas e serve uma vez só.
- **Redefinir:** `POST /api/auth/senha/redefinir` com o token do e-mail. Redefinir também desbloqueia a conta e encerra as sessões antigas.
- Mínimo de 8 caracteres.

## Bloqueio temporário

Depois de **5 senhas incorretas**, a conta fica bloqueada por **15 minutos**, mesmo que a senha certa seja digitada em seguida. Ajuste em:

```json
"Seguranca": { "TentativasAteBloquear": 5, "MinutosDeBloqueio": 15 }
```

## Registro de acessos

Toda tentativa de entrada é gravada na tabela `registros_acesso`: data e hora, e-mail, se foi permitida, o motivo da recusa (`SenhaIncorreta`, `SemPermissao`, `ContaBloqueada`, `ContaInativa`, `UsuarioInexistente`), a origem (painel ou loja), o IP e o navegador. O administrador vê a lista em **Acessos**, no painel, ou por `GET /api/admin/acessos?dias=30&somenteRecusados=true`.

## Sessão

- O token do painel dura 8 horas (`Jwt:HorasValidadePainel`); o da loja, 12 (`Jwt:HorasValidade`).
- Cada token carrega o carimbo de segurança da conta. Trocar a senha, redefinir a senha ou sair muda esse carimbo e derruba os tokens antigos.
- **Sair da conta:** `POST /api/painel/auth/sair`, disponível no menu do painel.
- Em produção, tudo passa por HTTPS (ver [PUBLICACAO.md](PUBLICACAO.md)).

## Isolamento entre clientes

Cada cliente enxerga apenas a própria conta: seus dados, endereços, pedidos, produtos comprados, pagamentos, prazos, status, códigos de rastreamento e histórico.

A regra é simples e vale para toda a API: **o dono vem sempre da conta autenticada, nunca de um `clienteId` mandado pelo navegador.** Nenhum endpoint da loja aceita identificação de usuário no corpo, na URL ou na query — o servidor lê o id do token e filtra por ele.

| Endpoint | Como fica preso à conta |
|---|---|
| `GET /api/pedidos` | Filtra por `ClienteId` do token |
| `GET /api/pedidos/{numero}` | Filtra por número **e** `ClienteId`; pedido de outra conta responde `404`, igual a um número inexistente |
| `GET/PUT /api/conta/dados` | Lê e grava só o usuário do token |
| `GET/POST/PUT/DELETE /api/conta/enderecos` | Toda consulta e alteração exige `UsuarioId` igual ao do token |
| `POST /api/pedidos` | O cliente do pedido é o do token; `enderecoId` só é aceito se pertencer a ele; preços, frete e prazos são recalculados no servidor |
| `/api/admin/...` e `/api/painel/...` | Exigem perfil Administrador; cliente recebe `403 Acesso não autorizado` |

Escolhas de projeto:

- **404 em vez de 403** ao pedir o pedido de outra pessoa: assim o número não é confirmado nem negado, o que evita descobrir pedidos por tentativa.
- **Tentativas ficam registradas.** Abrir um número que existe mas é de outra conta grava `PedidoDeOutroCliente` em `registros_acesso`, com e-mail, IP e horário.
- **Somente o administrador** vê todos os clientes e pedidos, pelo painel.

### Testes automatizados

O arquivo `backend/tests/LojaAmanhecer.Tests/IsolamentoClientesTests.cs` sobe a API de verdade contra um banco temporário e conversa com ela por HTTP, usando duas contas de cliente e a conta administradora. São 22 testes cobrindo:

1. cada cliente lista apenas os próprios pedidos;
2. nenhum cliente abre o pedido do outro pelo número, nem chutando números na URL;
3. nenhum cliente altera ou apaga dados e endereços do outro, nem compra usando o endereço alheio;
4. nenhum cliente acessa páginas ou APIs administrativas, nem entra no painel com a senha certa;
5. o administrador continua consultando todos os clientes e pedidos.

Para rodar:

```powershell
dotnet test --filter Isolamento
```

## Fotos dos produtos

Enviar, excluir, substituir e reordenar fotos são ações da conta administradora. Toda exclusão e toda substituição ficam registradas em `registros_acesso` com o e-mail de quem fez, a data e o IP, e também no log da API. Os arquivos saem do armazenamento junto com o registro no banco, tanto no disco local quanto no S3.

## Credenciais de pagamento

- O Access Token do Mercado Pago **nunca vai para o navegador**. A tela mostra só o prefixo e os quatro últimos caracteres (`APP_USR-••••••••cdef`) e o estado da conexão.
- Quando informado pelo painel, o token é cifrado com AES-GCM antes de ir para o banco, com chave derivada de `Seguranca:ChaveCriptografia` (ou da chave do JWT). Quem olhar a tabela `configuracoes` vê apenas texto cifrado.
- Em produção, o caminho recomendado é a variável de ambiente `MercadoPago__AccessToken`: a credencial fica só no servidor e nem chega ao banco. Ela tem prioridade sobre a cadastrada no painel.
- Nenhum token é gravado no Git: o `.env` está no `.gitignore` e o `appsettings.json` vai com os campos vazios.
- Só a conta administradora abre ou altera a área de Pagamentos e recebimentos. Conectar e desconectar a conta ficam registrados em `registros_acesso`.
- O id da cobrança no gateway também aparece parcialmente na listagem.

## Recomendações para o dia a dia

- Uma conta administradora por pessoa, nunca compartilhada.
- Apague o `primeiro-acesso.txt` depois de criar a conta.
- Confira os acessos recusados de vez em quando.
- Desative a conta de quem sai da equipe, em vez de excluir, para preservar o histórico dos pedidos.
