# Planejamento por etapas

Cada etapa termina com uma entrega para validação. Nada aprovado é alterado sem comunicação prévia (ver [APROVACOES.md](APROVACOES.md)).

## Etapa 1 — Estrutura, banco, protótipo, catálogo e painel base ✅ concluída · aguardando aprovação

| Item | Situação |
|---|---|
| Repositório Git organizado por etapas | Concluído |
| Solução .NET em camadas (Domínio, Aplicação, Infraestrutura, API) | Concluído |
| Banco PostgreSQL modelado com migração e script SQL (19 tabelas) | Concluído |
| Categorias iniciais criadas automaticamente | Concluído |
| Cadastro de usuários com perfis Administrador, Vendedor e Cliente | Concluído |
| API do catálogo: categorias, listagem, busca sem acento, detalhe | Concluído |
| API do painel: produtos (CRUD, fotos, variações, ativo/inativo), categorias e subcategorias, clientes, vendedores, resumo, exportação Excel | Concluído |
| Regras: prazo = produção + transporte; fluxo de status; assumir pedido | Concluído e testado |
| Protótipo visual navegável (loja, compra, conta, painel) | Aprovado para seguir (ajustes ainda podem ser pedidos) |

## Etapa 2 — Pedidos ponta a ponta na API ✅ concluída

| Item | Situação |
|---|---|
| Cotação de frete com prazo total (produção + transporte) | Concluído |
| Fechamento do pedido com recálculo de preços no servidor | Concluído |
| Baixa de estoque na compra e devolução no cancelamento | Concluído |
| Área do cliente: dados, endereços, pedidos e histórico | Concluído |
| Painel: lista com filtros, detalhe, assumir, status, rastreio, etiqueta, confirmação manual | Concluído |
| Relatórios de vendas e exportações em Excel | Concluído |

## Etapa 3 — Integrações ✅ concluída (falta ligar as contas reais)

| Integração | Situação |
|---|---|
| ViaCEP | Funcionando, sem necessidade de chave |
| Melhor Envio (cotação, etiqueta, rastreio) | Implementado; **aguarda o token da conta** |
| Mercado Pago (Pix, boleto e cartão pelo Checkout Pro) + webhook | Implementado; **aguarda o Access Token** |
| E-mail de confirmação e de cada mudança de status | Implementado; **aguarda o SMTP** |
| WhatsApp com o número da ordem | Nos e-mails e no protótipo |

Sem as chaves, a API sobe com frete, cobrança e e-mail simulados e avisa no log. Assim dá para testar o fluxo inteiro antes de abrir as contas.

## Módulo de fotos ✅ concluído

| Item | Situação |
|---|---|
| Aceitar JPG, JPEG, PNG, WEBP, AVIF e HEIC/HEIF | Concluído |
| Correção automática da orientação (EXIF) | Concluído |
| Arquivos grandes e de alta resolução (até 60 MB) | Concluído — testado com 54 MB / 8000 × 6000 |
| Original preservado byte a byte | Concluído |
| Miniatura, catálogo e página do produto gerados automaticamente | Concluído |
| Conversão de HEIC para WebP (ou AVIF, se configurado) | Concluído |
| Compressão sem perda visível e remoção de metadados das cópias | Concluído |
| Envio com barra de progresso, sem travar a tela | Concluído no protótipo; o painel definitivo usa o mesmo desenho |
| Fotografar ou escolher arquivos pelo celular | Concluído (botões "Escolher fotos" e "Tirar foto agora") |

### Foto das categorias

| Item | Situação |
|---|---|
| Foto própria para cada categoria e subcategoria | Concluído |
| Prévia antes de salvar, trocar e excluir | Concluído |
| Recorte e ajuste do enquadramento (arrastar e aproximar) | Concluído |
| Fotos de alta resolução do celular, inclusive HEIC | Concluído |
| Otimização e redimensionamento automáticos (600 × 600 em WebP) | Concluído |
| Ilustração padrão quando não há foto | Concluído |
| Medalhões da loja usando a foto, com o mesmo formato, tamanho e borda dourada | Concluído |
| Clique no medalhão ou no nome levando aos produtos da categoria | Já funcionava e continua |

Vídeos não entraram: o catálogo atual só tem fotos. Se quiser vídeo no produto, me diga o limite de duração e onde ele aparece que eu orçamento à parte.

## Segurança do painel ✅ concluída

| Item | Situação |
|---|---|
| Painel restrito ao perfil Administrador | Concluído (configurável em `Painel:PerfisPermitidos`) |
| Clientes e vendedores recusados com "Acesso não autorizado" | Concluído |
| Botão do painel removido da loja pública | Concluído |
| Tela de entrada própria, em `/painel` (ou subdomínio) | Concluído |
| Proteção de todas as rotas administrativas no servidor | Concluído |
| Primeira conta administradora com token de instalação de uso único | Concluído |
| Troca de senha e recuperação por e-mail | Concluído |
| Registro de tentativas de acesso | Concluído |
| Bloqueio temporário após 5 senhas incorretas | Concluído |
| Sessão de 8 horas, com saída que invalida os tokens | Concluído |

### Isolamento entre clientes

| Item | Situação |
|---|---|
| Cada cliente vê apenas os próprios dados, endereços, pedidos, pagamentos, prazos, rastreio e histórico | Conferido e testado |
| Dono identificado pela conta autenticada, nunca por `clienteId` do navegador | Conferido em toda a API |
| Pedido de outra conta responde 404 e a tentativa fica registrada | Concluído |
| Somente o administrador consulta todos os clientes e pedidos | Concluído |
| 22 testes de integração com duas contas de cliente e a conta administradora | Concluído |

Detalhes em [SEGURANCA.md](SEGURANCA.md).

## Pagamentos e recebimentos ✅ concluída

| Item | Situação |
|---|---|
| Conectar a conta do Mercado Pago que recebe os pagamentos | Concluído (painel ou variável de ambiente) |
| Ativar e desativar Pix, cartão e boleto | Concluído, e a loja passa a mostrar só o que está ativo |
| Máximo de parcelas, juros e valor mínimo por parcela | Concluído |
| Ver se a integração está conectada ou desconectada | Concluído |
| Testar a conexão antes de ativar | Concluído: a credencial só é aceita se a conta responder |
| Alternar entre ambiente de teste e produção | Concluído |
| Consultar pagamentos aprovados, pendentes, recusados, cancelados e estornados | Concluído |
| Ver taxas do provedor e o líquido previsto | Concluído |
| Estorno total ou parcial | Concluído |
| Número do pedido em cada pagamento | Concluído |
| Credenciais protegidas, nunca no navegador nem no Git | Concluído |
| Modo simulado mantido até chegarem as credenciais reais | Concluído |

## Etapa 4 — Loja e painel definitivos (frontend)

- Frontend Next.js fiel ao protótipo aprovado, responsivo e instalável no celular (PWA).
- Cadastro, login, recuperação de senha por e-mail, carrinho e finalização em 3 passos.
- Painel do vendedor conectado à API.
- Ajustes de desempenho, SEO e acessibilidade.

## Etapa 5 — Publicação e homologação

- Servidor, domínio, HTTPS, backups automáticos.
- Contas de produção do Mercado Pago e Melhor Envio.
- Cadastro do catálogo real com as fotos enviadas.
- Período de testes com pedidos reais e treinamento dos vendedores.
