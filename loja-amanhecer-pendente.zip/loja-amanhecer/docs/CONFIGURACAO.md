# Configuração

As configurações ficam em `backend/src/LojaAmanhecer.Api/appsettings.json`. Em produção **não edite o arquivo**: use variáveis de ambiente (no `.env` do Docker). O separador de seções é `__` (dois sublinhados), por exemplo `Jwt__Chave`.

## Configurações da API

| Chave | Descrição | Padrão (desenvolvimento) |
|---|---|---|
| `ConnectionStrings:Banco` | Conexão com o PostgreSQL | `Host=localhost;...;Username=loja;Password=loja_dev_123` |
| `Banco:AplicarMigracoesAoIniciar` | Cria/atualiza tabelas ao subir a API | `true` |
| `Jwt:Chave` | Chave secreta dos tokens de acesso (mín. 32 caracteres) | **trocar em produção** |
| `Jwt:Emissor` / `Jwt:Publico` | Identificação do token | `loja-amanhecer` / `loja-amanhecer-web` |
| `Jwt:HorasValidade` | Duração do login | `12` |
| `AdminInicial:Nome` / `Email` / `Senha` | Administrador criado na primeira execução. **Deixe vazio em produção** e use o token de instalação | vazio (preenchido só em desenvolvimento) |
| `Painel:PerfisPermitidos` | Perfis que podem entrar no painel | `["Administrador"]` |
| `Seguranca:TentativasAteBloquear` | Senhas erradas antes do bloqueio temporário | `5` |
| `Seguranca:MinutosDeBloqueio` | Duração do bloqueio | `15` |
| `Jwt:HorasValidadePainel` | Duração da sessão do painel | `8` |
| `Seguranca:ChaveCriptografia` | Chave que cifra credenciais guardadas no banco (como o Access Token). Sem ela, é derivada da chave do JWT. **Trocar essa chave torna as credenciais guardadas ilegíveis**, e basta reconectar a conta no painel | vazio |
| `Armazenamento:Provedor` | `local` (disco) ou `s3` (serviço compatível com S3) | `local` |
| `Armazenamento:PastaLocal` | Pasta das fotos, no modo local | `uploads` |
| `Armazenamento:S3:Bucket` | Bucket das fotos | vazio |
| `Armazenamento:S3:Endpoint` | Endereço do serviço (Cloudflare R2, MinIO, Backblaze). Vazio usa a Amazon S3 com `Regiao` | vazio |
| `Armazenamento:S3:Regiao` | Região, quando for Amazon S3 | `auto` |
| `Armazenamento:S3:ChaveAcesso` / `ChaveSecreta` | Credenciais do bucket | vazio |
| `Armazenamento:S3:UrlPublica` | Endereço público dos arquivos (CDN ou domínio do bucket) | vazio |
| `Armazenamento:S3:Prefixo` | Pasta dentro do bucket | `uploads` |
| `Cors:Origens` | Endereços que podem chamar a API | `http://localhost:3000` |
| `Swagger:Habilitado` | Documentação interativa | `true` em desenvolvimento |
| `Urls:Api` / `Urls:Loja` / `Urls:Painel` | Endereços públicos usados no webhook, no retorno do checkout e no link de recuperação de senha | `localhost` |

Para gerar uma chave JWT no PowerShell:

```powershell
[Convert]::ToBase64String((1..48 | ForEach-Object { Get-Random -Maximum 256 }))
```

## Onde ficam as fotos

Em desenvolvimento, as fotos ficam em disco (`Armazenamento:Provedor = local`) e são servidas em `/uploads`. Em produção, o recomendado é um serviço compatível com S3 — Cloudflare R2, Amazon S3, MinIO ou Backblaze B2 — com `Armazenamento:Provedor = s3`.

Os dois modos fazem exatamente as mesmas operações, inclusive **apagar** os arquivos quando uma foto é excluída ou substituída no painel. Nada mais no sistema precisa mudar: as URLs continuam sendo guardadas do mesmo jeito no banco.

## Fotos dos produtos

| Chave | Descrição | Padrão |
|---|---|---|
| `Imagens:TamanhoMaximoMb` | Tamanho máximo de cada foto enviada | `60` |
| `Imagens:Formato` | Formato das versões otimizadas: `webp` ou `avif` | `webp` |
| `Imagens:Qualidade` | Compressão das versões (1 a 100) | `82` |
| `Imagens:Miniatura` | Maior lado da miniatura, em pixels | `400` |
| `Imagens:Catalogo` | Maior lado da versão dos cartões da loja | `900` |
| `Imagens:Produto` | Maior lado da versão da página do produto | `1600` |
| `Imagens:CategoriaMedalhao` | Lado do medalhão quadrado da categoria | `600` |
| `Imagens:CategoriaMiniatura` | Lado da miniatura da categoria | `200` |

O vendedor envia a foto como ela saiu do celular. A API guarda o arquivo original sem alterar nada, corrige a orientação pelo EXIF e gera as três versões otimizadas. Formatos aceitos: **JPG, JPEG, PNG, WEBP, AVIF e HEIC/HEIF** (o padrão do iPhone). Como HEIC não abre nos navegadores, as versões geradas saem sempre em WebP (ou AVIF, se você trocar `Imagens:Formato`).

`avif` comprime mais que o WebP, mas leva mais tempo para gerar e é ignorado por navegadores muito antigos. O WebP funciona em tudo que é usado hoje.

As fotos são servidas em `/uploads` com cache de um ano, porque cada versão tem nome único.

## Configurações da loja (no banco)

Tabela `configuracoes`, editáveis pelo painel na Etapa 2:

| Chave | Uso |
|---|---|
| `loja.nome` | Nome exibido na loja e nos e-mails |
| `loja.whatsapp` | Número com DDI e DDD, só dígitos (ex.: `5561999999999`) |
| `loja.email` | E-mail de contato |
| `frete.cep_origem` | CEP de onde saem os envios |
| `frete.retirada_habilitada` | `true` para oferecer retirada no local |
| `frete.retirada_endereco` | Endereço/instruções da retirada |
| `estoque.alerta_minimo` | Quantidade que dispara o alerta de estoque baixo |

## Integrações (usadas a partir da Etapa 3)

### Melhor Envio

1. Crie a conta em https://melhorenvio.com.br (e no ambiente de testes https://sandbox.melhorenvio.com.br).
2. Em **Configurações → Permissões de acesso → Tokens**, gere um token com as permissões de cotação, carrinho, compra de etiquetas e rastreio.
3. Configure `MelhorEnvio__Token` e, em produção, `MelhorEnvio__Url=https://melhorenvio.com.br`.
4. Cadastre peso e dimensões do produto **embalado** — sem isso a cotação não é feita.

### Mercado Pago

1. Acesse https://www.mercadopago.com.br/developers e crie uma aplicação ("Pagamentos on-line").
2. Copie o **Access Token** de teste e, depois, o de produção.
3. Informe o token de um destes dois jeitos:
   - **Pelo painel** (Pagamentos e recebimentos → Conta do Mercado Pago). O token é testado antes de ser aceito e guardado **cifrado** no banco. Nunca volta para o navegador: a tela só mostra a versão mascarada.
   - **Pelo servidor**, em `MercadoPago__AccessToken`. Essa forma tem prioridade sobre a do painel e é a recomendada em produção, porque a credencial nem chega ao banco.
4. Em **Webhooks**, cadastre `https://api.seudominio.com.br/api/pagamentos/webhook` com o evento *Pagamentos* e copie a assinatura secreta → `MercadoPago__ChaveWebhook`.
5. Ative a chave Pix na conta do Mercado Pago.

Sem token nenhum, a loja continua no **modo simulado**: os pedidos são criados normalmente e nada é cobrado. A troca para cobrança real não exige mexer em código nem reiniciar a API.

As formas de pagamento ativas, o máximo de parcelas, os juros, o valor mínimo da parcela, o ambiente (teste ou produção) e as taxas de referência ficam na tabela `configuracoes`, nas chaves que começam com `pagamento.`, e são editados pelo painel.

### E-mail

Qualquer provedor SMTP (Brevo, Resend, Amazon SES, Zoho). Configure `Email__Host`, `Email__Porta`, `Email__Usuario`, `Email__Senha` e `Email__Remetente`. Para boa entrega, configure SPF e DKIM do domínio no provedor.

### WhatsApp

Não precisa de chave: os botões usam links `wa.me` com o número de `loja.whatsapp` e a mensagem já contendo o número do pedido.

### Login com Google

1. Acesse https://console.cloud.google.com/apis/credentials e crie um **ID do cliente OAuth**, tipo "Aplicativo da Web".
2. Em **Origens JavaScript autorizadas**, informe a URL da loja (ex.: `https://seudominio.com.br`, e `http://localhost:3000` em desenvolvimento).
3. Copie o **Client ID** gerado e configure em `Autenticacao__Google__ClientId` (não é segredo — o mesmo valor é usado no HTML da loja para desenhar o botão "Continuar com o Google").
4. A loja (frontend) carrega o script `https://accounts.google.com/gsi/client` do Google, desenha o botão com esse Client ID e, ao usuário entrar, recebe um token de identidade (`credential`). Esse token é enviado para `POST /api/auth/google`.
5. A API confere a assinatura do token com a biblioteca oficial `Google.Apis.Auth`, sem precisar de chamada de rede. No primeiro acesso por um e-mail novo, a conta do cliente é criada automaticamente (sem senha — só entra pelo Google); nos acessos seguintes, a conta é reconhecida pelo identificador do Google, não pelo e-mail.

Sem `Autenticacao__Google__ClientId` configurado, o endpoint `/api/auth/google` recusa o login (fica só o login por e-mail e senha).
