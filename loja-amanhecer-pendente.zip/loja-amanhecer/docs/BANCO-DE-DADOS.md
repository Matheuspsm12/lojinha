# Banco de dados

PostgreSQL 16, nomes em português no padrão `snake_case`. O script completo está em [`database/schema.sql`](../database/schema.sql); a fonte da verdade são as migrações em `backend/src/LojaAmanhecer.Infrastructure/Dados/Migracoes`.

## Tabelas

| Tabela | Conteúdo |
|---|---|
| `usuarios` | Clientes, vendedores e administradores (nome, e-mail, CPF, telefone, ativo, `deve_trocar_senha`) |
| `perfis`, `usuarios_perfis` | Perfis Administrador, Vendedor, Cliente |
| `enderecos` | Endereços do cliente (um marcado como principal) |
| `categorias` | Categorias e subcategorias (`categoria_pai_id`), com slug único. `imagem_url` (medalhão), `imagem_miniatura_url` e `imagem_original_url` guardam a foto quando houver |
| `produtos` | Dados do produto, preço, estoque, peso/dimensões, disponibilidade, prazo, personalização, ativo, destaque |
| `produto_imagens` | Fotos com ordem (a primeira é a principal). Além da `url` principal (versão de catálogo), guarda `url_original`, `url_miniatura`, `url_grande`, `largura` e `altura` — todas opcionais |
| `produto_opcoes` | Tipos de opção (Tamanho, Cor, Povo, Falange) com valores em `text[]` |
| `produto_variacoes` | Combinações vendáveis: atributos em `jsonb`, preço próprio opcional, estoque |
| `pedidos` | Número sequencial, cliente, vendedor responsável, status, valores, endereço copiado, forma de entrega, prazos, rastreio |
| `pedido_itens` | Cópia do produto no momento da compra (nome, variação, personalização, preço, prazo) |
| `pagamentos` | Método, situação, id no Mercado Pago, confirmação manual, taxa do provedor, valor líquido, valor estornado e ambiente (teste, produção ou simulado) |
| `pedido_historico` | Toda mudança de status, com usuário e comentário |
| `configuracoes` | Chave/valor editáveis da loja: dados da loja, frete, estoque, token de instalação (só o hash), o banner da página inicial (`loja.banner_*`) e as chaves `pagamento.*` com formas ativas, parcelamento, taxas e o Access Token **cifrado** |
| `registros_acesso` | Toda tentativa de entrada: data, e-mail, resultado, motivo, origem, IP e navegador |
| `usuarios_claims`, `usuarios_logins`, `usuarios_tokens`, `perfis_claims` | Tabelas internas do ASP.NET Identity |

## Relacionamentos principais

```
categorias 1─N categorias (subcategorias, 2 níveis)
categorias 1─N produtos
produtos   1─N produto_imagens | produto_opcoes | produto_variacoes
usuarios   1─N enderecos
usuarios   1─N pedidos (como cliente)   ·   usuarios 1─N pedidos (como vendedor)
pedidos    1─N pedido_itens | pagamentos | pedido_historico
```

## Decisões de modelagem

- **Número do pedido:** sequência `pedido_numero_seq`, exibido como `VA-000001`. Não se repete nem é reaproveitado.
- **Cópias no pedido:** endereço, nome do produto, variação e preço são copiados para o pedido. Editar o produto ou o endereço depois não altera pedidos antigos.
- **Status e enums** gravados como texto (`EmProducao`), legíveis em consultas e relatórios.
- **Exclusões:** categoria com produtos não pode ser excluída (apenas desativada). Produtos devem ser inativados, não apagados, para preservar o histórico.
- **Busca:** extensão `unaccent` + `ILIKE`, ignorando acentos e maiúsculas.
- **Foto da categoria:** opcional. Quando está vazia, a loja mostra a ilustração padrão daquela categoria.
- **Fotos:** as colunas das versões otimizadas são opcionais e foram adicionadas sem mexer nas existentes. Fotos antigas continuam válidas e usam a `url` principal em todos os tamanhos.

## Regras de negócio (código em `LojaAmanhecer.Domain`)

- **Prazo exibido** = maior prazo de produção entre os itens + prazo de transporte (`CalculadoraPrazo`).
- **Pronta entrega** sem estoque suficiente usa o prazo de produção cadastrado (`Produto.PrazoProducaoPara`).
- **Transições de status** permitidas (`Pedido.Transicoes`):

| De | Para |
|---|---|
| Pedido recebido | Aguardando pagamento, Pagamento confirmado, Cancelado |
| Aguardando pagamento | Pagamento confirmado, Cancelado |
| Pagamento confirmado | Em produção, Pronto para envio, Cancelado |
| Em produção | Pronto para envio, Cancelado |
| Pronto para envio | Enviado, Entregue (retirada), Cancelado |
| Enviado | Entregue |
| Entregue / Cancelado | — (finais) |
