# Publicação em produção

Roteiro para um servidor VPS Linux (Ubuntu 24.04, 2 GB de RAM é suficiente para o início).

## 1. Domínio

Registre o domínio (ex.: registro.br) e crie no DNS:

| Tipo | Nome | Valor |
|---|---|---|
| A | `@` | IP do servidor |
| A | `api` | IP do servidor |
| A | `www` | IP do servidor |

## 2. Preparar o servidor

Conecte por SSH e rode um comando por vez:

```bash
sudo apt update
```
```bash
sudo apt install -y docker.io docker-compose-v2 caddy git
```
```bash
sudo usermod -aG docker $USER
```

Saia e entre de novo no SSH para o grupo valer.

## 3. Baixar o projeto

```bash
sudo mkdir -p /opt/loja
```
```bash
sudo chown $USER /opt/loja
```
```bash
git clone <url-do-repositorio> /opt/loja
```
```bash
cd /opt/loja
```

## 4. Configurar

```bash
cp .env.example .env
```
```bash
nano .env
```

Preencha senhas fortes, a chave JWT, o e-mail do administrador e os domínios. Nunca envie o `.env` para o repositório.

## 5. Subir banco e API

```bash
docker compose up -d --build
```
```bash
docker compose logs -f api
```

Procure no log a linha **"Token de instalação do painel (uso único)"** e guarde o token: é com ele que você cria a conta administradora em `/painel`. Ele também fica no arquivo `primeiro-acesso.txt` dentro do contêiner. Saia com Ctrl+C e teste:

```bash
curl http://127.0.0.1:8080/api/saude
```

## 6. HTTPS com Caddy

```bash
sudo cp infra/Caddyfile.exemplo /etc/caddy/Caddyfile
```
```bash
sudo nano /etc/caddy/Caddyfile
```

Troque os domínios e recarregue:

```bash
sudo systemctl reload caddy
```

O certificado Let's Encrypt é emitido e renovado automaticamente. Teste `https://api.seudominio.com.br/api/saude`.

## 7. Backups

```bash
chmod +x infra/backup-banco.sh
```
```bash
crontab -e
```

Adicione a linha:

```
0 3 * * * /opt/loja/infra/backup-banco.sh
```

Guarde cópias fora do servidor (ex.: rclone para Google Drive ou Cloudflare R2). Faça também backup do volume `fotos`.

Para restaurar um backup:

```bash
docker compose exec -T banco pg_restore -U loja -d loja_amanhecer --clean < backups/loja-AAAA-MM-DD.dump
```

## 8. Atualizar para uma nova versão

```bash
cd /opt/loja
```
```bash
git pull
```
```bash
docker compose up -d --build
```

As migrações do banco são aplicadas automaticamente ao subir a API. Faça um backup antes de cada atualização.

## Checklist antes de abrir a loja

- [ ] Conta administradora criada pelo token de instalação, e `primeiro-acesso.txt` apagado
- [ ] `AdminInicial` vazio no `.env` de produção
- [ ] Painel respondendo em `/painel` (ou no subdomínio) só para a conta administradora
- [ ] `Jwt__Chave` aleatória e exclusiva
- [ ] `SEGURANCA_CHAVE_CRIPTOGRAFIA` definida e guardada em lugar seguro
- [ ] Tokens de **produção** do Mercado Pago e do Melhor Envio
- [ ] Conta do Mercado Pago conectada e testada em Pagamentos e recebimentos, com o ambiente em **produção**
- [ ] Webhook do Mercado Pago apontando para o domínio com HTTPS
- [ ] SPF/DKIM do e-mail configurados
- [ ] Backup automático testado (gerar e restaurar)
- [ ] Armazenamento das fotos definido: disco do servidor (com backup do volume) ou bucket S3/R2 configurado e testado
- [ ] Pedido real de teste pago e estornado
