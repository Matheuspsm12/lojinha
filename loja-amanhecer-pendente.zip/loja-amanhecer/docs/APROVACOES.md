# Registro de aprovações

Regra do projeto: **funcionalidades aprovadas não são alteradas sem comunicação prévia.** Toda mudança proposta entra aqui como "Proposta" antes de ser implementada.

## Aprovado pelo cliente (escopo do MVP)

| Tema | Definição aprovada |
|---|---|
| Categorias iniciais | Broches de povos (princesas, pretos-velhos, demais povos); Radares, Coletes e Fitas de Doutrinador e Apará; Fotografias, imagens e quadros; Outros artigos. Admin cria novas categorias e subcategorias. |
| Produto | Nome, categoria/subcategoria, descrição, fotos, preço, estoque, peso e dimensões, pronta entrega ou sob encomenda, prazo de produção, variações (tamanho, cor, povo, falange), personalização, ativo/inativo. |
| Prazo ao cliente | Prazo de produção + prazo de transporte. |
| Status do pedido | Pedido recebido → Aguardando pagamento → Pagamento confirmado → Em produção → Pronto para envio → Enviado → Entregue; Cancelado. |
| Integrações do MVP | ViaCEP, Melhor Envio, Mercado Pago (Pix, cartão, boleto), e-mail, WhatsApp com número da ordem. |
| Identidade | Roxo/lilás, dourado, azul-celeste e branco; elegante, respeitosa e simples no celular. |
| Processo | Aprovar o visual antes das integrações; projeto em etapas, em repositório, com documentação. |

## Aguardando aprovação (Etapa 1)

| Item | O que validar |
|---|---|
| Protótipo visual | Cores, tipografia, página inicial, medalhões de categorias, página do produto, carrinho, finalização, área do cliente e painel. |
| Organização das categorias | "Radares", "Coletes" e "Fitas" como categorias principais, com Doutrinador e Apará como subcategorias. |
| Prazo com vários itens | Os itens são produzidos em paralelo: vale o **maior** prazo de produção do carrinho (e não a soma). |
| Pronta entrega sem estoque | Quando a quantidade pedida passa do estoque, o produto usa o prazo de produção cadastrado. |
| Envio exige rastreio | O pedido só vai para "Enviado" com código de rastreio (exceto retirada no local). |
| Retirada no local | "Pronto para envio" pode ir direto para "Entregue". |
| Assumir pedido | Um pedido assumido por um vendedor não pode ser tomado por outro; o administrador pode atuar em qualquer pedido. |
| Permissões | Vendedor: pedidos, produtos, estoque, clientes e relatórios. Administrador: tudo, inclusive vendedores e configurações. |

## Mudanças comunicadas (módulo de fotos)

| Mudança | O que muda para quem usa |
|---|---|
| Colunas novas em `produto_imagens` (`url_original`, `url_miniatura`, `url_grande`, `largura`, `altura`) | Migração só de acréscimo. Nenhuma coluna existente foi alterada ou removida, e as fotos já cadastradas continuam funcionando |
| `produto_imagens.url` passa a apontar para a versão de catálogo | O campo continua existindo com o mesmo nome e uso; quem já consumia a `url` não precisa mudar nada |
| Limite de envio passou de 8 MB para 60 MB por foto | Só amplia o que era aceito |
| Formatos aceitos ganharam AVIF e HEIC/HEIF | Só amplia o que era aceito |

| Colunas novas em `categorias` (`imagem_miniatura_url`, `imagem_original_url`) | Migração só de acréscimo. A coluna `imagem_url`, que já existia, continua igual — nem o tipo nem o tamanho mudaram |
| Editar a categoria pelo formulário não apaga mais a foto | Antes, salvar o formulário sem a `imagemUrl` limparia o campo. Agora a foto só muda pelos botões de foto |

| Painel restrito ao perfil Administrador | Vendedores e clientes recebem "Acesso não autorizado". O perfil Vendedor, a tela de vendedores, o "assumir pedido" e o histórico continuam no banco e na API; basta acrescentar "Vendedor" em `Painel:PerfisPermitidos` para liberar |
| Painel mudou para `/painel`, com entrada própria | O endereço antigo redireciona sozinho. A loja pública não tem mais link para o painel |
| `AdminInicial` saiu do `appsettings.json` | Em produção não há mais senha padrão: a primeira conta é criada com o token de instalação. Em desenvolvimento, a conta de sempre continua no `appsettings.Development.json` |
| Tabela nova `registros_acesso` e coluna `deve_trocar_senha` | Migração só de acréscimo; nada existente foi alterado |
| Trocar a senha ou sair encerra as sessões antigas | Quem estiver logado em outro aparelho precisa entrar de novo |

| Colunas novas em `pagamentos` (`taxa_gateway`, `valor_liquido`, `valor_estornado`, `ambiente`) | Migração só de acréscimo |
| Forma de pagamento desativada no painel é recusada no checkout | Com tudo ativo, que é o padrão, o comportamento é o mesmo de antes |
| A escolha entre Mercado Pago e modo simulado passou a ser feita a cada cobrança | Antes dependia de reiniciar a API com o token configurado. Agora conectar a conta pelo painel já vale na hora |

Fluxos, telas, regras de pedido, prazos e status ficaram exatamente como estavam.

## Pendências do cliente

- Fotografias e lista de produtos com preços, variações, peso e dimensões.
- Imagem de referência (não chegou nas mensagens até agora).
- Nome definitivo da loja, logotipo e domínio.
- CPF/CNPJ para as contas do Mercado Pago e do Melhor Envio.
- Endereço de origem dos envios e, se houver, endereço para retirada.
- Número de WhatsApp da loja.
