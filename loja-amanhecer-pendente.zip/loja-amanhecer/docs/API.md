# Endpoints da API (Etapa 1)

Base: `http://localhost:5080` em desenvolvimento. Documentação interativa em `/swagger`.
Autenticação: `Authorization: Bearer <token>` obtido em `/api/auth/login`.

## Públicos

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/saude` | Verificação de funcionamento |
| POST | `/api/auth/registrar` | Cria conta de cliente e devolve o token |
| POST | `/api/auth/login` | Login (bloqueia após 5 tentativas erradas) |
| POST | `/api/auth/google` | Login com o token do botão "Continuar com o Google"; cria a conta automaticamente no primeiro acesso |
| GET | `/api/categorias` | Árvore de categorias ativas |
| GET | `/api/produtos` | Lista com `categoria` (slug, inclui subcategorias), `busca`, `destaque`, `ordem` (`relevancia`, `menor-preco`, `maior-preco`, `novidades`), `pagina`, `tamanho` |
| GET | `/api/produtos/{slug}` | Detalhe com fotos, opções e variações |

Na listagem `/api/produtos`, cada produto traz `imagemUrl` (a foto principal, como antes) e `fotos`: todas as fotos na ordem do cadastro, usadas para navegar entre elas no card da loja.

## Aparência da loja

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/loja/aparencia` | Público. Banner da página inicial (versões para computador e celular); vazio significa usar a arte que veio na instalação |
| GET | `/api/admin/aparencia` | Somente administrador. Situação da arte em uso |
| POST | `/api/admin/aparencia/banner` | Envia a arte (`multipart/form-data`, campo `arte`). Aceita os mesmos formatos das fotos, corrige a orientação e gera as versões otimizadas mantendo a proporção |
| DELETE | `/api/admin/aparencia/banner` | Remove a arte enviada; a loja volta ao banner da instalação |

## Dados da loja

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/loja/info` | Público. Nome, WhatsApp e Instagram, para montar o cabeçalho e o rodapé |
| GET | `/api/admin/loja` | Somente administrador. Nome, WhatsApp, e-mail de contato e Instagram atuais |
| PUT | `/api/admin/loja` | Atualiza os quatro campos. Instagram vazio esconde o botão na loja |

## Pagamentos e recebimentos (somente administrador)

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/admin/pagamentos/configuracao` | Situação da conexão, ambiente, formas ativas, parcelamento e taxas. O Access Token vem apenas mascarado |
| PUT | `/api/admin/pagamentos/configuracao` | Ativa ou desativa Pix, cartão e boleto; define máximo de parcelas, juros, valor mínimo da parcela, ambiente e taxas de referência |
| PUT | `/api/admin/pagamentos/credencial` | Conecta a conta do Mercado Pago. Testa antes de gravar (`testarAntes`) e guarda o token cifrado |
| DELETE | `/api/admin/pagamentos/credencial` | Desconecta a conta; a loja volta ao modo simulado |
| POST | `/api/admin/pagamentos/testar-conexao` | Testa a conta conectada sem alterar nada |
| GET | `/api/admin/pagamentos` | Recebimentos com pedido, cliente, forma, valor, taxa, líquido, estornos e ambiente (`status`, `busca`, `dias`) |
| GET | `/api/admin/pagamentos/resumo` | Aprovados, pendentes, recusados, estornados e cancelados; bruto, taxas e líquido previsto |
| POST | `/api/admin/pagamentos/{id}/estornar` | Estorno total (sem valor) ou parcial |

Na loja, `GET /api/pagamentos/opcoes` devolve as formas ativas e as regras de parcelamento para montar o checkout.

## Painel: entrada e segurança

| Método | Rota | Descrição |
|---|---|---|
| POST | `/api/painel/auth/login` | Entrada no painel. Só perfis de `Painel:PerfisPermitidos` (hoje, Administrador) |
| GET | `/api/painel/auth/eu` | Dados da sessão atual |
| POST | `/api/painel/auth/sair` | Sai da conta e invalida os tokens emitidos |
| GET | `/api/admin/acessos` | Tentativas de acesso registradas (`dias`, `somenteRecusados`, `limite`) |
| GET | `/api/instalacao/situacao` | Informa se ainda é preciso criar o primeiro administrador |
| POST | `/api/instalacao/administrador` | Cria a primeira conta administradora com o token de instalação |
| POST | `/api/conta/senha` | Troca a senha de quem está logado |
| POST | `/api/auth/senha/esqueci` | Envia o link de recuperação por e-mail |
| POST | `/api/auth/senha/redefinir` | Redefine a senha com o token do e-mail |

Detalhes e respostas de recusa em [SEGURANCA.md](SEGURANCA.md).

## Compra (loja)

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/cep/{numero}` | Endereço pelo CEP (ViaCEP) |
| POST | `/api/frete/cotar` | Opções de entrega com valor e **prazo total = produção + transporte** |
| POST | `/api/pedidos` | Fecha o pedido e gera a cobrança (exige login). Preços, frete e prazos são recalculados no servidor |
| GET | `/api/pedidos` | Pedidos do cliente logado |
| GET | `/api/pedidos/{numero}` | Detalhe do pedido com histórico |
| POST | `/api/pagamentos/webhook` | Aviso do Mercado Pago (confirma o pagamento automaticamente) |

## Conta do cliente

| Método | Rota | Descrição |
|---|---|---|
| GET / PUT | `/api/conta/dados` | Consulta e atualiza nome, telefone e CPF |
| GET | `/api/conta/enderecos` | Endereços cadastrados |
| POST | `/api/conta/enderecos` | Novo endereço (um deles fica como principal) |
| PUT | `/api/conta/enderecos/{id}` | Atualiza |
| DELETE | `/api/conta/enderecos/{id}` | Remove |

## Painel — vendedores e administradores

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/admin/painel/resumo` | Pedidos novos, aguardando pagamento, em produção, enviados, vendas do mês, estoque baixo |
| GET | `/api/admin/categorias` | Todas as categorias, inclusive inativas |
| GET | `/api/admin/categorias/opcoes` | Lista pronta para o campo de categoria do produto: ativas, na ordem, com o caminho ("Coletes › Colete de Apará") e a contagem de produtos. `incluirId` acrescenta a categoria atual do produto mesmo desativada |
| POST | `/api/admin/categorias` | Cria categoria ou subcategoria (`categoriaPaiId`) |
| PUT | `/api/admin/categorias/{id}` | Atualiza |
| DELETE | `/api/admin/categorias/{id}` | Exclui (só sem produtos e sem subcategorias) |
| POST | `/api/admin/categorias/{id}/imagem` | Envia a foto da categoria ou subcategoria (`multipart/form-data`: `foto` + `recorteX`, `recorteY`, `recorteLargura`, `recorteAltura`) |
| DELETE | `/api/admin/categorias/{id}/imagem` | Remove a foto; a loja volta à ilustração padrão |
| GET | `/api/admin/produtos` | Lista com `busca`, `categoriaId`, `ativo` |
| GET | `/api/admin/produtos/{id}` | Detalhe para edição |
| POST | `/api/admin/produtos` | Cadastra com opções e variações |
| PUT | `/api/admin/produtos/{id}` | Atualiza (preserva o id das variações existentes) |
| PATCH | `/api/admin/produtos/{id}/ativo?ativo=false` | Ativa/inativa |
| POST | `/api/admin/produtos/{id}/imagens` | Envia fotos (`multipart/form-data`, campo `fotos`). Aceita JPG, JPEG, PNG, WEBP, AVIF e HEIC/HEIF, até 60 MB cada |
| PUT | `/api/admin/produtos/{id}/imagens/ordem` | Define a ordem das fotos |
| DELETE | `/api/admin/produtos/{id}/imagens/{imagemId}` | Exclui **uma** foto, apaga os arquivos dela do armazenamento e devolve a galeria atualizada. Se era a capa, a próxima assume |
| POST | `/api/admin/produtos/{id}/imagens/{imagemId}/substituir` | Troca o arquivo de uma foto já cadastrada, mantendo a posição (`multipart/form-data`, campo `foto`) |
| PATCH | `/api/admin/produtos/{id}/imagens/{imagemId}/principal` | Escolhe qual foto é a capa |
| GET | `/api/admin/produtos/exportar` | Planilha Excel do catálogo |
| GET | `/api/admin/usuarios/clientes` | Lista clientes |
| GET | `/api/admin/pedidos` | Lista com `filtro` (`sem-vendedor`, `meus`, `abertos`), `status`, `busca` (número ou cliente) |
| GET | `/api/admin/pedidos/{numero}` | Detalhe com cliente, itens, pagamento, histórico e próximos status possíveis |
| POST | `/api/admin/pedidos/{numero}/assumir` | O vendedor assume a ordem |
| PATCH | `/api/admin/pedidos/{numero}/status` | Muda o status e avisa o cliente por e-mail |
| PUT | `/api/admin/pedidos/{numero}/rastreio` | Grava o código de rastreamento |
| POST | `/api/admin/pedidos/{numero}/etiqueta` | Gera a etiqueta no Melhor Envio |
| POST | `/api/admin/pedidos/{numero}/confirmar-pagamento` | Confirmação manual (transferência, dinheiro, maquininha) |
| PUT | `/api/admin/pedidos/{numero}/observacao` | Anotação interna |
| GET | `/api/admin/pedidos/exportar` | Planilha Excel dos pedidos (`de`, `ate`) |
| GET | `/api/admin/relatorios/vendas?dias=30` | Faturamento, ticket médio, por dia, por categoria, mais vendidos, por vendedor |
| GET | `/api/admin/relatorios/vendas/exportar?dias=30` | Relatório de vendas em Excel |
| GET | `/api/admin/relatorios/desempenho-produtos?dias=30` | Cliques (visitas à página do produto, desde sempre) e vendas (no período) lado a lado — o "mapa de calor" do catálogo |

## Somente administradores

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/admin/usuarios/equipe` | Administradores e vendedores |
| POST | `/api/admin/usuarios/equipe` | Cadastra vendedor ou administrador |
| PATCH | `/api/admin/usuarios/{id}/ativo` | Ativa/desativa usuário |

## Respostas de erro

| Código | Quando |
|---|---|
| 400 | Dados em formato inválido |
| 401 | Sem login ou token expirado: `{"detalhe":"Faça login para continuar.","entrarEm":"/painel"}` |
| 403 | Perfil sem permissão: `{"detalhe":"Acesso não autorizado"}` |
| 404 | Registro não encontrado |
| 422 | Regra de negócio: `{"titulo":"Regra de negócio","detalhe":"Peso e dimensões são obrigatórios para o cálculo do frete."}` |

## Categorias no cadastro de produtos

O campo de categoria do produto é montado a partir de `GET /api/admin/categorias/opcoes`, então tudo que for criado ou renomeado em Categorias aparece no cadastro na mesma hora, sem recarregar o painel.

- Só entram categorias e subcategorias **ativas**; as subcategorias vêm logo abaixo da categoria principal.
- Uma categoria desativada não pode ser escolhida em produto novo nem em troca de categoria (`422`), mas continua valendo para o produto que já estava nela: ao editar, ela aparece marcada como desativada e o vínculo é preservado.
- A loja (`GET /api/categorias`, filtros e páginas de categoria) mostra apenas as ativas, e o produto aparece tanto na subcategoria quanto na categoria principal.
- Categoria com produtos ou com subcategorias não pode ser excluída (`422`); o caminho é desativar.

## Envio de fotos

`POST /api/admin/produtos/{id}/imagens` recebe os arquivos como vieram do celular. Para cada foto a API:

1. grava o **original** sem alterar nada (`-original.jpg`, `-original.heic`…);
2. corrige a **orientação** pelo EXIF (foto tirada deitada fica em pé);
3. gera **três versões** em WebP: miniatura (400 px), catálogo (900 px) e página do produto (1600 px), com os metadados removidos;
4. devolve a lista de fotos do produto já com todas as URLs.

Campos de cada foto na resposta:

| Campo | Uso |
|---|---|
| `url` | Versão de catálogo — é a URL principal, a mesma usada antes desta melhoria |
| `urlMiniatura` | Listas e painel |
| `urlGrande` | Página do produto |
| `urlOriginal` | Arquivo original, para reimpressão ou reprocessamento |
| `largura`, `altura` | Dimensões já com a orientação corrigida |

Fotos enviadas antes desta melhoria continuam funcionando: `urlMiniatura` e `urlGrande` repetem a `url` original.

### Excluir e substituir

Excluir, substituir e escolher a capa são ações **somente da conta administradora** (`403 Acesso não autorizado` para qualquer outro perfil). Em cada uma delas:

- sai apenas a foto indicada — o produto e as outras imagens ficam como estavam;
- as versões geradas e o arquivo original são apagados do armazenamento (disco local ou S3), sem deixar arquivo abandonado;
- a galeria é renumerada, então a capa é sempre a primeira foto; excluindo a capa, a próxima assume;
- quem fez a ação fica registrado em `registros_acesso` (`FotoRemovida`, `FotoSubstituida`) e no log;
- sem nenhuma foto, `imagemUrl` vem nulo e `fotos` vem vazio: a loja mostra a imagem padrão.

Uma foto de 54 MB (8000 × 6000) leva cerca de 6 segundos entre envio e processamento e resulta em 82 KB na versão de catálogo.

## Foto da categoria

Vale para categorias e subcategorias. A foto pode ir como saiu do celular, inclusive HEIC. A API corrige a orientação, recorta no enquadramento escolhido no painel (sem recorte informado, corta um quadrado no centro), redimensiona e converte para WebP:

- `imagemUrl` — medalhão de 600 × 600, usado na loja;
- `imagemMiniaturaUrl` — 200 × 200, para listas e painel;
- `imagemOriginalUrl` — arquivo original, preservado;
- `temFoto` — `false` quando a categoria não tem foto e a loja deve usar a ilustração padrão.

O recorte vai em pixels da foto já com a orientação corrigida; a API encaixa os valores dentro da imagem e força o formato quadrado. Enviar outra foto substitui a anterior e apaga os arquivos antigos.

`GET /api/categorias` continua com o mesmo formato de antes; os campos de foto vieram como acréscimo.

## Dados de cada cliente

Todas as rotas de `/api/pedidos` e `/api/conta` respondem apenas com dados da conta autenticada. O servidor identifica o cliente pelo token e ignora qualquer identificação vinda do navegador. Pedido de outra conta responde `404`, e a tentativa fica registrada. Detalhes em [SEGURANCA.md](SEGURANCA.md).

## Quem pode atualizar um pedido

Só o vendedor que assumiu a ordem, ou um administrador. Quem não assumiu recebe 422 com "Assuma o pedido antes de atualizá-lo" ou "Este pedido está com outro vendedor".

## Integrações simuladas

Sem `MelhorEnvio:Token`, `MercadoPago:AccessToken` ou `Email:Host`, a API sobe com frete, cobrança e e-mail **simulados** e registra um aviso no log a cada inicialização. Isso permite testar todo o fluxo antes das contas estarem prontas — nunca use assim em produção.

## Próximas etapas

A loja e o painel em Next.js (Etapa 2 do frontend) consomem estes endpoints.
