# Instalação do ambiente de desenvolvimento (Windows)

## 1. Instalar os programas

1. **.NET 8 SDK** — https://dotnet.microsoft.com/download/dotnet/8.0
2. **PostgreSQL 16** — https://www.postgresql.org/download/windows/ (anote a senha do usuário `postgres`)
3. **Git** — https://git-scm.com/download/win
4. (Etapa 2) **Node.js 20 LTS** — https://nodejs.org

Confira no PowerShell:

```powershell
dotnet --version
```
```powershell
psql --version
```

## 2. Criar o banco

Abra o **SQL Shell (psql)** ou o pgAdmin conectado como `postgres` e rode um comando por vez:

```sql
CREATE USER loja WITH PASSWORD 'loja_dev_123';
```
```sql
CREATE DATABASE loja_amanhecer OWNER loja;
```
```sql
\c loja_amanhecer
```
```sql
CREATE EXTENSION IF NOT EXISTS unaccent;
```

> A extensão `unaccent` permite buscar "apara" e encontrar "Apará". Ela precisa ser criada por um superusuário; depois disso o usuário `loja` não precisa de privilégios especiais.

## 3. Obter o código

```powershell
git clone <url-do-repositorio> loja-amanhecer
```
```powershell
cd loja-amanhecer
```

Se recebeu o projeto em .zip, basta extrair — o histórico Git já vem dentro.

## 4. Rodar os testes

```powershell
cd backend
```
```powershell
dotnet test
```

Resultado esperado: 13 testes aprovados.

## 5. Subir a API

```powershell
cd src\LojaAmanhecer.Api
```
```powershell
dotnet run --urls http://localhost:5080
```

Na primeira execução a API:
- aplica as migrações (cria as tabelas);
- cria os perfis, o administrador inicial e as categorias iniciais;
- cria as configurações padrão da loja.

Acesse:
- Documentação interativa: http://localhost:5080/swagger
- Verificação: http://localhost:5080/api/saude

## 6. Testar pelo Swagger

1. Em `POST /api/painel/auth/login`, envie `{"email":"admin@loja.local","senha":"Admin@12345"}`.
2. Copie o `token` da resposta.
3. Clique em **Authorize** e cole o token.
4. Use os endpoints `/api/admin/...` para cadastrar produtos e categorias.

## 7. Ver o protótipo

Abra `prototipo\index.html` direto no navegador (duplo clique). Não precisa de servidor.

## Alternativa: Docker

Com o Docker Desktop instalado, na raiz do projeto:

```powershell
copy .env.example .env
```
```powershell
docker compose up -d --build
```

A API fica em http://localhost:8080. O Swagger vem desligado em produção; para ligar, defina `Swagger__Habilitado=true`.

## Comandos úteis do banco (Entity Framework)

Instalar a ferramenta (uma vez):

```powershell
dotnet tool install --global dotnet-ef --version 8.0.11
```

Criar uma nova migração depois de alterar entidades (na pasta `backend`):

```powershell
dotnet ef migrations add NomeDaMudanca -p src/LojaAmanhecer.Infrastructure -s src/LojaAmanhecer.Api -o Dados/Migracoes
```

Gerar o script SQL atualizado:

```powershell
dotnet ef migrations script --idempotent -p src/LojaAmanhecer.Infrastructure -s src/LojaAmanhecer.Api -o ../database/schema.sql
```
